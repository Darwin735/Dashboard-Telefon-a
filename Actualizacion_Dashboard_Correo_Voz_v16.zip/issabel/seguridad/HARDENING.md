# Hardening de Issabel/Asterisk

Antes de aplicar reglas, sustituya las redes por las de su laboratorio y mantenga una consola abierta para evitar perder acceso. Pruebe en una VM clonada o con snapshot.

## Controles y amenazas mitigadas

| Medida | Configuracion | Amenaza mitigada | Evidencia |
|---|---|---|---|
| Secretos robustos | 20+ caracteres aleatorios, un secreto por extension/troncal | Registro fraudulento y toll fraud | Pantalla con el valor oculto |
| Fail2ban | 5 intentos/10 min, bloqueo 1 h | Fuerza bruta automatizada | `fail2ban-client status asterisk` |
| Firewall allowlist | SIP/RTP solo desde VLAN de voz; IAX solo entre dos IP | Escaneo y acceso no autorizado | `firewall-cmd --list-all` o `nft list ruleset` |
| Invitados desactivados | `allowguest=no`, anonymous SIP = No | Llamadas sin autenticacion | Intento rechazado en CLI/log |
| ACL IAX | `deny` global y `permit` del peer /32 | Suplantacion de una sede | Peer details y regla UDP/4569 |
| CALLTOKEN IAX2 | `requirecalltoken=yes` | Agotamiento de call numbers/DoS | `iax2 show peer` |
| DB local | 3306 no publicado; usuario SELECT limitado | Exfiltracion o alteracion de CDR | grants y firewall |
| HTTPS/reverse proxy | Nginx termina TLS; API no se expone directamente | Intercepcion y ataques HTTP basicos | URL HTTPS y cabeceras |
| Copias y logs | respaldo de configuracion/BD; logs rotados | Perdida de configuracion y falta de trazabilidad | fecha del respaldo |

## Asterisk SIP general

Combinar `sip_general_custom.conf` con el archivo correspondiente del sistema. En PJSIP, aplique equivalentes desde la GUI y ACLs del endpoint.

## Fail2ban

Copiar `jail.local` a `/etc/fail2ban/jail.d/asterisk.local`. Verificar la ruta real del log (`/var/log/asterisk/full`) y el filtro disponible antes de reiniciar.

```bash
fail2ban-client -t
systemctl restart fail2ban
fail2ban-client status asterisk
```

## Firewall minimo

- SSH/22: solo red administrativa del laboratorio `192.168.0.0/24`.
- HTTPS/443: solo red administrativa/usuarios autorizados.
- SIP/5060 y RTP/10000-20000: solo red de voz `192.168.0.0/24` en este laboratorio.
- IAX2/4569: solo IP de la otra PBX.
- MariaDB/3306: localhost; no abrir a la LAN.
- Todo lo demas: denegar por defecto.

Use `firewall_ejemplo.sh` como lista reproducible, no como script ciego: adapte la zona e interfaz de cada VM.

## Prueba de anonimos

1. En Issabel, Settings > Asterisk SIP Settings: Allow Anonymous Inbound SIP Calls = No.
2. Confirmar `allowguest=no` con `asterisk -rx "sip show settings"`.
3. Desde un softphone sin usuario/clave, intente marcar 2000.
4. Resultado esperado: 401/403 o rechazo; ninguna llamada debe timbrar.
5. Conserve CLI/log como evidencia sin exponer credenciales.

## Recomendaciones adicionales

- Cambiar las claves por defecto de Issabel, MariaDB y correo de voz.
- Usar VPN sitio a sitio para cualquier enlace que atraviese Internet.
- Sincronizar NTP en las dos VMs para que CDR, CEL y dashboard coincidan.
- Deshabilitar servicios, puertos y codecs no utilizados.
- Ejecutar `npm audit` antes de la demo y actualizar dependencias compatibles.
- Programar respaldo de `/etc/asterisk`, configuracion Issabel y `asteriskcdrdb`.
