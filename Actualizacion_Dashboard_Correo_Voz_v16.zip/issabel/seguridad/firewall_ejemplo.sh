#!/usr/bin/env bash
set -euo pipefail

# EJEMPLO PARA PBX PRINCIPAL. No contiene direcciones predeterminadas porque
# las VMs usan DHCP. Obtenga la red actual con: ip -br -4 addr
# Mantenga consola local/snapshot disponible antes de aplicar reglas.
ZONE=${ZONE:-public}
ADMIN_NET=${ADMIN_NET:-}
VOICE_NET=${VOICE_NET:-}
REMOTE_PBX=${REMOTE_PBX:-$VOICE_NET}

if [[ -z "$ADMIN_NET" || -z "$VOICE_NET" || -z "$REMOTE_PBX" ]]; then
  echo "ERROR: indique las redes actuales; no se usan IP antiguas automaticamente." >&2
  echo "Ejemplo: ADMIN_NET=10.11.9.0/24 VOICE_NET=10.11.9.0/24 REMOTE_PBX=10.11.9.0/24 $0" >&2
  exit 2
fi

if [[ ${CONFIRM_FIREWALL:-NO} != "SI" ]]; then
  echo "MODO SEGURO: no se aplicaron reglas." >&2
  echo "Revise ZONE=$ZONE ADMIN_NET=$ADMIN_NET VOICE_NET=$VOICE_NET REMOTE_PBX=$REMOTE_PBX" >&2
  echo "Repita agregando CONFIRM_FIREWALL=SI solo despues de abrir una consola local o snapshot." >&2
  exit 2
fi

firewall-cmd --permanent --zone="$ZONE" --set-target=DROP

firewall-cmd --permanent --zone="$ZONE" \
  --add-rich-rule="rule family=ipv4 source address=$ADMIN_NET port port=22 protocol=tcp accept"
firewall-cmd --permanent --zone="$ZONE" \
  --add-rich-rule="rule family=ipv4 source address=$ADMIN_NET port port=443 protocol=tcp accept"
firewall-cmd --permanent --zone="$ZONE" \
  --add-rich-rule="rule family=ipv4 source address=$VOICE_NET port port=5060 protocol=udp accept"
firewall-cmd --permanent --zone="$ZONE" \
  --add-rich-rule="rule family=ipv4 source address=$VOICE_NET port port=10000-20000 protocol=udp accept"
firewall-cmd --permanent --zone="$ZONE" \
  --add-rich-rule="rule family=ipv4 source address=$REMOTE_PBX port port=4569 protocol=udp accept"

# MariaDB permanece en 127.0.0.1; no se abre 3306.
firewall-cmd --reload
firewall-cmd --zone="$ZONE" --list-all
