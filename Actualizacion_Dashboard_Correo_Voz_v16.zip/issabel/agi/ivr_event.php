#!/usr/bin/php -q
<?php
declare(strict_types=1);

// AGI: registra decisiones del IVR en la misma MariaDB utilizada por Issabel.
// Instalar como /var/lib/asterisk/agi-bin/ivr_event.php, propietario asterisk.

$agi = [];
while (($line = fgets(STDIN)) !== false) {
    $line = trim($line);
    if ($line === '') {
        break;
    }
    [$key, $value] = array_pad(explode(':', $line, 2), 2, '');
    $agi[trim($key)] = trim($value);
}

$option = preg_replace('/[^A-Z0-9_-]/i', '', $argv[1] ?? 'UNKNOWN');
$label = preg_replace('/[^A-Z0-9_ -]/i', '', $argv[2] ?? 'DESCONOCIDO');
$menu = preg_replace('/[^0-9]/', '', $argv[3] ?? '7000');
$uniqueId = substr($agi['agi_uniqueid'] ?? '', 0, 64);
$caller = substr($agi['agi_callerid'] ?? 'anonymous', 0, 40);
$linkedIdArgument = preg_replace('/[^A-Za-z0-9_.:-]/', '', $argv[4] ?? '');
$linkedId = substr($linkedIdArgument !== '' ? $linkedIdArgument : $uniqueId, 0, 64);

$configPath = '/etc/asterisk/dashboard-db.php';
if (!is_readable($configPath)) {
    error_log('ivr_event.php: falta ' . $configPath);
    exit(0); // Nunca interrumpir la llamada por un fallo de reportería.
}

$db = require $configPath;

try {
    $pdo = new PDO(
        sprintf('mysql:host=%s;dbname=%s;charset=utf8mb4', $db['host'], $db['database']),
        $db['user'],
        $db['password'],
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
    $stmt = $pdo->prepare(
        'INSERT INTO ivr_events (event_time, uniqueid, linkedid, caller, menu_id, option_code, option_label) '
        . 'VALUES (NOW(), ?, ?, ?, ?, ?, ?)'
    );
    $stmt->execute([$uniqueId, $linkedId, $caller, $menu, $option, $label]);
} catch (Throwable $error) {
    error_log('ivr_event.php: ' . $error->getMessage());
}

exit(0);
