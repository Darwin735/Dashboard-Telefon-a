# Guia de configuracion Issabel

Los nombres de menus pueden variar ligeramente segun la version de Issabel. Aplique los cambios en PBX > PBX Configuration y pulse Apply Config despues de cada bloque.

## 1. Extensiones

Crear extensiones Generic CHAN_SIP o PJSIP segun el controlador instalado. Use el archivo `plan_numeracion.csv`.

- Display name: departamento y rol.
- Secret: minimo 20 caracteres aleatorios; nunca igual al numero de extension.
- NAT: No dentro de la LAN; Yes/Force rport solo si el escenario lo requiere.
- Codecs permitidos: `ulaw` y `alaw`; `g722` opcional dentro de la LAN.
- Desactivar codecs que no se usen.
- Voicemail: habilitado con PIN diferente de la extension.
- `qualify=yes` para poder observar disponibilidad.

Las extensiones 2901 y 2902 son buzones departamentales sin telefono registrado. Genere igualmente secretos robustos.

## 2. Grupos de timbrado

### 6100 - Ventas

- Descripcion: Ventas.
- Ring strategy: `ringall`.
- Ring time: 25 segundos.
- Extension list: `2001-2002-2003-2004` (una por linea en la GUI).
- Destination if no answer: Voicemail 2901, modo unavailable.

### 6200 - Soporte

- Descripcion: Soporte.
- Ring strategy: `hunt` o `rrmemory` si la version lo ofrece.
- Ring time: 25 segundos.
- Extension list: 2005, 2006, 2007.
- Destination if no answer: Voicemail 2902, modo unavailable.

### 6300 y 6400

- 6300 Finanzas: `ringall`, miembros 2008 y 2009.
- 6400 Logistica: `ringall`, miembros 2011 y 2012.

## 3. Destinos personalizados para registrar el IVR

Copie `extensions_custom.conf` a `/etc/asterisk/extensions_custom.conf` conservando cualquier contenido existente. Copie `agi/ivr_event.php` a `/var/lib/asterisk/agi-bin/` y ajuste propietario/permisos.

Crear los siguientes Custom Destinations:

- `corp-ivr-sales,s,1`
- `corp-ivr-support,s,1`
- `corp-ivr-finance,s,1`
- `corp-ivr-more,s,1`
- `corp-ivr-management,s,1`
- `corp-ivr-logistics,s,1`
- `corp-ivr-reception,s,1`
- `corp-ivr-timeout,s,1`

Se usa el prefijo `corp-ivr-` para evitar la colision con el prefijo interno
`ivr-` que Issabel reserva para los contextos generados por su modulo IVR.

## 4. IVR de dos niveles

Grabe audios propios desde System Recordings.

Antes de asignar la opcion 4, cree dos **Misc Applications**:

- Codigo `7000`, descripcion `Acceso IVR Principal`, destino: IVR Principal.
- Codigo `7001`, descripcion `Acceso IVR Segundo Nivel`, destino: IVR Mas opciones.

Esto permite probar ambos menus desde una extension y hace que
`corp-ivr-more,s,1` llegue al segundo nivel sin depender del contexto interno
`ivr-N` que Issabel genera automaticamente.

### IVR 7000 - Principal

Mensaje sugerido: "Gracias por llamar a Corporacion Litoral. Marque 1 para Ventas, 2 para Soporte, 3 para Finanzas, 4 para mas opciones o 0 para Recepcion."

- Opcion 1 -> `corp-ivr-sales,s,1` -> grupo 6100.
- Opcion 2 -> `corp-ivr-support,s,1` -> grupo 6200.
- Opcion 3 -> `corp-ivr-finance,s,1` -> grupo 6300.
- Opcion 4 -> `corp-ivr-more,s,1` -> IVR 7001.
- Opcion 0 -> `corp-ivr-reception,s,1` -> extension 2000.
- Timeout -> `corp-ivr-timeout,s,1` -> extension 2000.
- Invalid: repetir una vez; luego Recepcion.
- Timeout: 5 s; intentos: 2.

### IVR 7001 - Mas opciones

Mensaje sugerido: "Marque 1 para Gerencia, 2 para Logistica, 9 para volver al menu anterior o 0 para Recepcion."

- Opcion 1 -> `corp-ivr-management,s,1` -> 2010.
- Opcion 2 -> `corp-ivr-logistics,s,1` -> 6400.
- Opcion 9 -> IVR 7000.
- Opcion 0/timeout -> Recepcion 2000.

La ruta entrante del numero principal debe terminar en IVR 7000.

## 5. Troncal IAX2

Crear una troncal IAX2 en cada PBX con los parametros de `iax_trunks.conf`. Reemplace `REEMPLAZAR_CON_SECRETO_ALEATORIO` por el mismo valor en ambos extremos; no deje el secreto en capturas.

- En PBX principal, ruta saliente `A_BODEGA`: patron `3XXX`, troncal `BODEGA-IAX`.
- En PBX bodega, ruta saliente `A_PRINCIPAL`: patron `2XXX`, troncal `PRINCIPAL-IAX`.
- En la PBX principal, el bloque entrante de la bodega debe usar `context=from-bodega`.
- En la PBX bodega, el bloque entrante de la sede principal debe usar `context=from-sede`.
- No use manipulacion de digitos; envie los cuatro digitos completos.

Pruebas:

```bash
asterisk -rx "iax2 show peers"
asterisk -rx "dialplan show from-bodega"
asterisk -rx "dialplan show from-sede"
```

## 6. Recarga y validacion

```bash
asterisk -rx "dialplan reload"
asterisk -rx "sip show peers"       # chan_sip
asterisk -rx "pjsip show endpoints" # pjsip
asterisk -rx "iax2 show peers"
```

No edite archivos autogenerados como `extensions_additional.conf`, porque Issabel puede sobrescribirlos. Use siempre los archivos `*_custom.conf` o la GUI.
