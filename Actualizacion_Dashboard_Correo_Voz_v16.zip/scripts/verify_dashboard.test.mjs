import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { createServer } from 'node:http';
import { dirname, resolve } from 'node:path';
import test from 'node:test';
import { fileURLToPath } from 'node:url';

const SCRIPT_DIR = dirname(fileURLToPath(import.meta.url));
const PROJECT_ROOT = resolve(SCRIPT_DIR, '..');

function responseFor(pathname) {
  const departments = ['Recepcion', 'Ventas', 'Soporte', 'Finanzas', 'Gerencia', 'Logistica', 'Bodega remota'];
  const responses = {
    '/api/health': { status: 'ok', database: true, version: '1.6.0', timestamp: '2026-08-08T09:00:00Z' },
    '/api/system-status': { status: 'ok', checks: Array.from({ length: 10 }, (_, id) => ({ id, status: 'ok' })) },
    '/api/security': { status: 'ok', controls: Array.from({ length: 7 }, (_, id) => ({ id, status: 'active' })) },
    '/api/summary': { total: 3, answered: 2, answerRate: 66.7, avgDuration: 20 },
    '/api/calls': { total: 3, items: [{ id: 'call-1', department: 'Ventas', direction: 'INTERNA' }] },
    '/api/departments': { items: departments.map((department, index) => ({ department, calls: index < 3 ? 1 : 0 })) },
    '/api/ring-groups': { items: [
      { groupName: 'Ventas', total: 1, answered: 1, answerRate: 100, avgWaitSeconds: 3, voicemail: 0 },
      { groupName: 'Soporte', total: 1, answered: 0, answerRate: 0, avgWaitSeconds: 25, voicemail: 1 },
    ] },
    '/api/hourly': { items: Array.from({ length: 24 }, (_, hour) => ({ hour, calls: hour === 9 ? 3 : 0 })) },
    '/api/daily': { items: [{ day: '2026-08-08', calls: 3 }] },
    '/api/ivr': { items: [
      { menuId: '7000', optionCode: '1', selections: 1 },
      { menuId: '7001', optionCode: '1', selections: 1 },
    ] },
    '/api/trends': { previousRange: { from: '2026-08-07', to: '2026-08-07' }, changes: { total: 1, answered: 1, answerRate: 1, avgDuration: 1 } },
    '/api/trunk': { trunkName: 'BODEGA-IAX', localIp: '192.168.0.11', peerIp: '192.168.0.10', status: 'UP', stale: false, source: 'asterisk', checkedAt: '2026-08-08T09:00:00Z' },
    '/api/trunks': { items: [{ name: 'BODEGA-IAX', address: '192.168.0.10', state: 'UP', expectedName: true, legacyName: false, duplicateAddress: false }] },
    '/api/trunk-history': { summary: { samples: 10, uptimePercent: 100 } },
    '/api/live-calls': { status: 'ok', updatedAt: '2026-08-08T09:00:00Z', total: 0, items: [] },
    '/api/quality': { availabilityPercent: 100, iaxLatencyMs: 1, rtp: { available: false, detail: 'Habilite RTCP para medir RTP.' } },
    '/api/evidence': { version: '1.6.0', generatedAt: '2026-08-08T09:00:00Z', declaration: 'Datos reales', summary: {}, system: {}, security: {}, voicemail: {} },
    '/api/voicemail': { status: 'ok', totals: { total: 2, playable: 2 }, mailboxes: [{ mailbox: '2901' }, { mailbox: '2902' }], items: [{ id: 'default:2901:INBOX:msg0001' }] },
  };
  return responses[pathname];
}

function runVerifier(apiUrl) {
  return new Promise((resolvePromise, reject) => {
    const child = spawn(process.execPath, [resolve(SCRIPT_DIR, 'verify_dashboard.mjs')], {
      cwd: PROJECT_ROOT,
      env: { ...process.env, API_URL: apiUrl, FROM: '2026-08-08', TO: '2026-08-08' },
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    let stdout = ''; let stderr = '';
    child.stdout.on('data', (chunk) => { stdout += chunk; });
    child.stderr.on('data', (chunk) => { stderr += chunk; });
    child.on('error', reject);
    child.on('close', (code) => resolvePromise({ code, stdout, stderr }));
  });
}

test('el verificador aprueba los 24 controles con evidencia', async (context) => {
  const server = createServer((request, response) => {
    const pathname = new URL(request.url, 'http://127.0.0.1').pathname;
    if (pathname === '/api/export/calls.csv') {
      response.writeHead(200, { 'content-type': 'text/csv' });
      response.end('Fecha y hora,Origen\n2026-08-08,2001\n');
      return;
    }
    const body = responseFor(pathname);
    response.writeHead(body ? 200 : 404, { 'content-type': 'application/json' });
    response.end(JSON.stringify(body ?? { error: 'not found' }));
  });
  await new Promise((resolvePromise) => server.listen(0, '127.0.0.1', resolvePromise));
  context.after(() => new Promise((resolvePromise) => server.close(resolvePromise)));
  const { port } = server.address();
  const result = await runVerifier(`http://127.0.0.1:${port}/api`);
  assert.equal(result.code, 0, result.stderr || result.stdout);
  assert.match(result.stdout, /Resultado: 24\/24 controles con evidencia\./);
  assert.match(result.stdout, /Dashboard v16 verificado completamente con datos en vivo\./);
});

test('el verificador mantiene 24 controles si la API no responde', async () => {
  const result = await runVerifier('http://127.0.0.1:1/api');
  assert.equal(result.code, 1, result.stderr || result.stdout);
  assert.equal(result.stdout.match(/\[(?:OK|PENDIENTE)\]/g)?.length, 24, result.stdout);
  assert.match(result.stdout, /\[PENDIENTE\] Conexion en vivo a MariaDB/);
  assert.match(result.stdout, /\[PENDIENTE\] Estado actualizado de la troncal IAX2/);
});
