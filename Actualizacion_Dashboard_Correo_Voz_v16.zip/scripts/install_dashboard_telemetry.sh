#!/usr/bin/env bash
set -euo pipefail

# Instala las fuentes auxiliares de datos del dashboard en la PBX principal.
# No crea eventos de prueba: ivr_events solo se llena mediante llamadas reales.

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERROR: ejecute este script como root." >&2
  exit 1
fi

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd -- "$SCRIPT_DIR/.." && pwd)"
ROOT_CNF="$(mktemp /tmp/dashboard-mariadb-root.XXXXXX.cnf)"
trap 'rm -f "$ROOT_CNF"' EXIT
chmod 600 "$ROOT_CNF"

for command in mysql openssl php asterisk install; do
  if ! command -v "$command" >/dev/null 2>&1; then
    echo "ERROR: falta el comando requerido: $command" >&2
    exit 1
  fi
done

if ! id asterisk >/dev/null 2>&1 || ! getent group asterisk >/dev/null 2>&1; then
  echo "ERROR: no existe el usuario/grupo asterisk esperado en Issabel." >&2
  exit 1
fi

if [[ ! -d /etc/asterisk || ! -d /var/lib/asterisk/agi-bin ]]; then
  echo "ERROR: no se encontraron los directorios de configuracion de Asterisk." >&2
  exit 1
fi

if ! php -m | grep -Eiq '^pdo_mysql$'; then
  echo "ERROR: PHP no tiene habilitado pdo_mysql; el AGI no puede escribir eventos." >&2
  exit 1
fi

read -r -s -p "Contrasena de MariaDB para root: " MYSQL_ROOT_PASSWORD
printf '\n'
if [[ -z "$MYSQL_ROOT_PASSWORD" ]]; then
  echo "ERROR: la contrasena de MariaDB no puede quedar vacia." >&2
  exit 1
fi

cat >"$ROOT_CNF" <<EOF
[client]
host=localhost
user=root
password="$MYSQL_ROOT_PASSWORD"
EOF
unset MYSQL_ROOT_PASSWORD

if ! mysql --defaults-extra-file="$ROOT_CNF" -Nse 'SELECT 1' >/dev/null; then
  echo "ERROR: MariaDB rechazo las credenciales de root." >&2
  exit 1
fi

LINKEDID_EXISTS="$(mysql --defaults-extra-file="$ROOT_CNF" -Nse \
  "SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA='asteriskcdrdb' AND TABLE_NAME='cdr' AND COLUMN_NAME='linkedid'")"
if [[ "$LINKEDID_EXISTS" != "1" ]]; then
  echo "ERROR: asteriskcdrdb.cdr no contiene linkedid; no se puede contar llamadas logicas con precision." >&2
  exit 1
fi

mysql --defaults-extra-file="$ROOT_CNF" < "$PROJECT_DIR/database/schema.sql"

WRITER_PASSWORD="$(openssl rand -hex 24)"
mysql --defaults-extra-file="$ROOT_CNF" <<SQL
CREATE USER IF NOT EXISTS 'dashboard_writer'@'127.0.0.1' IDENTIFIED BY '$WRITER_PASSWORD';
ALTER USER 'dashboard_writer'@'127.0.0.1' IDENTIFIED BY '$WRITER_PASSWORD';
REVOKE ALL PRIVILEGES, GRANT OPTION FROM 'dashboard_writer'@'127.0.0.1';
GRANT INSERT ON asteriskcdrdb.ivr_events TO 'dashboard_writer'@'127.0.0.1';
GRANT INSERT ON asteriskcdrdb.trunk_status TO 'dashboard_writer'@'127.0.0.1';
FLUSH PRIVILEGES;
SQL

READER_EXISTS="$(mysql --defaults-extra-file="$ROOT_CNF" -Nse \
  "SELECT COUNT(*) FROM mysql.user WHERE User='dashboard_reader' AND Host='127.0.0.1'")"
if [[ "$READER_EXISTS" == "1" ]]; then
  mysql --defaults-extra-file="$ROOT_CNF" <<'SQL'
GRANT SELECT ON asteriskcdrdb.cdr TO 'dashboard_reader'@'127.0.0.1';
GRANT SELECT ON asteriskcdrdb.ivr_events TO 'dashboard_reader'@'127.0.0.1';
GRANT SELECT ON asteriskcdrdb.trunk_status TO 'dashboard_reader'@'127.0.0.1';
FLUSH PRIVILEGES;
SQL
else
  echo "AVISO: dashboard_reader@127.0.0.1 no existe; no se modificaron permisos de lectura." >&2
fi

cat >/etc/asterisk/dashboard-writer.cnf <<EOF
[client]
host=127.0.0.1
user=dashboard_writer
password=$WRITER_PASSWORD
database=asteriskcdrdb
EOF
chown root:asterisk /etc/asterisk/dashboard-writer.cnf
chmod 0640 /etc/asterisk/dashboard-writer.cnf

cat >/etc/asterisk/dashboard-db.php <<EOF
<?php
return [
    'host' => '127.0.0.1',
    'database' => 'asteriskcdrdb',
    'user' => 'dashboard_writer',
    'password' => '$WRITER_PASSWORD',
];
EOF
chown root:asterisk /etc/asterisk/dashboard-db.php
chmod 0640 /etc/asterisk/dashboard-db.php

install -o asterisk -g asterisk -m 0750 \
  "$PROJECT_DIR/issabel/agi/ivr_event.php" /var/lib/asterisk/agi-bin/ivr_event.php

install -o root -g asterisk -m 0640 \
  "$PROJECT_DIR/issabel/extensions_custom.conf" /etc/asterisk/extensions_dashboard_custom.conf

touch /etc/asterisk/extensions_custom.conf
if ! grep -Fqx '#include extensions_dashboard_custom.conf' /etc/asterisk/extensions_custom.conf; then
  printf '\n#include extensions_dashboard_custom.conf\n' >> /etc/asterisk/extensions_custom.conf
fi

install -o root -g root -m 0750 \
  "$PROJECT_DIR/database/update_trunk_status.sh" /usr/local/sbin/update_trunk_status.sh

cat >/etc/cron.d/dashboard-trunk-monitor <<'EOF'
* * * * * root /usr/local/sbin/update_trunk_status.sh >/dev/null 2>&1
EOF
chown root:root /etc/cron.d/dashboard-trunk-monitor
chmod 0644 /etc/cron.d/dashboard-trunk-monitor
systemctl enable --now crond >/dev/null

asterisk -rx 'dialplan reload' >/dev/null
/usr/local/sbin/update_trunk_status.sh

echo
echo "Telemetria instalada correctamente."
echo "- AGI: /var/lib/asterisk/agi-bin/ivr_event.php"
echo "- Contextos: /etc/asterisk/extensions_dashboard_custom.conf"
echo "- Monitor: /usr/local/sbin/update_trunk_status.sh (cada minuto)"
echo "- Peer esperado: BODEGA-IAX / IP detectada por Asterisk"
echo
echo "SIGUIENTE PASO: cree los Custom Destinations e IVR descritos en"
echo "$PROJECT_DIR/issabel/GUIA_CONFIGURACION_ISSABEL.md y realice una llamada real."
echo "No se insertaron eventos IVR artificiales."
