#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR=/opt/corporacion-litoral-v16
NGINX_CONF=/etc/nginx/conf.d/dashboard.conf
HTPASSWD_FILE=/etc/nginx/.dashboard.htpasswd
STAMP=$(date +%Y%m%d-%H%M%S)
BACKUP_CONF="${NGINX_CONF}.before-v16-auth-${STAMP}"

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERROR: ejecute como root." >&2
  exit 1
fi
if [[ $# -ne 1 ]]; then
  echo "Uso: $0 USUARIO" >&2
  exit 2
fi
if [[ ! "$1" =~ ^[A-Za-z0-9_.-]{3,40}$ ]]; then
  echo "ERROR: usuario invalido." >&2
  exit 2
fi
if [[ ! -f "$NGINX_CONF" ]]; then
  echo "ERROR: no existe $NGINX_CONF." >&2
  exit 1
fi
if [[ ! -f /etc/pki/tls/certs/dashboard.crt || ! -f /etc/pki/tls/private/dashboard.key ]]; then
  echo "ERROR: faltan los certificados TLS configurados para el dashboard." >&2
  exit 1
fi

read -rsp "Contrasena para $1: " password
printf '\n'
if [[ ${#password} -lt 12 ]]; then
  echo "ERROR: use al menos 12 caracteres." >&2
  exit 2
fi

hash=$(openssl passwd -6 "$password")
unset password
printf '%s:%s\n' "$1" "$hash" >"$HTPASSWD_FILE"
chown root:nginx "$HTPASSWD_FILE" 2>/dev/null || chown root:root "$HTPASSWD_FILE"
chmod 0640 "$HTPASSWD_FILE"

install -o root -g root -m 0644 "$PROJECT_DIR/issabel/seguridad/nginx-dashboard-auth.conf" \
  /etc/nginx/dashboard-auth.inc
cp -a "$NGINX_CONF" "$BACKUP_CONF"
install -o root -g root -m 0644 "$PROJECT_DIR/issabel/seguridad/nginx-dashboard.conf" "$NGINX_CONF"
if ! nginx -t; then
  cp -a "$BACKUP_CONF" "$NGINX_CONF"
  install -o root -g root -m 0644 "$PROJECT_DIR/issabel/seguridad/nginx-dashboard-auth-disabled.conf" /etc/nginx/dashboard-auth.inc
  echo "ERROR: Nginx rechazo la configuracion; se restauro $BACKUP_CONF." >&2
  exit 1
fi

ENV_FILE="$PROJECT_DIR/dashboard/backend/.env"
if grep -q '^AUTH_MODE=' "$ENV_FILE"; then
  sed -i 's/^AUTH_MODE=.*/AUTH_MODE=proxy/' "$ENV_FILE"
else
  printf '%s\n' 'AUTH_MODE=proxy' >>"$ENV_FILE"
fi
systemctl reload nginx
systemctl restart voip-api.service
echo "Autenticacion habilitada. Respaldo de Nginx: $BACKUP_CONF"
