#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR=/opt/corporacion-litoral-v16
BACKUP_ROOT=/opt/backups
STAMP=$(date +%Y%m%d-%H%M%S)
BACKUP_DIR="$BACKUP_ROOT/corporacion-litoral-before-v16-$STAMP"

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERROR: ejecute como root." >&2
  exit 1
fi

for command in tar install systemctl useradd usermod groupadd getent curl grep; do
  command -v "$command" >/dev/null 2>&1 || { echo "ERROR: falta el comando $command." >&2; exit 1; }
done
if [[ ! -x /usr/local/bin/node || ! -x /usr/local/bin/npm ]]; then
  echo "ERROR: Node.js y npm deben existir en /usr/local/bin." >&2
  exit 1
fi
if [[ ! -d "$PROJECT_DIR/dashboard/backend" || ! -d "$PROJECT_DIR/dashboard/frontend" ]]; then
  echo "ERROR: extraiga primero la v16 en $PROJECT_DIR." >&2
  exit 1
fi

# La version instalada y su configuracion se respaldan antes de cambiar servicios.
install -d -o root -g root -m 0700 "$BACKUP_DIR"
for old_dir in /opt/corporacion-litoral /opt/corporacion-litoral-v11 /opt/corporacion-litoral-v12 /opt/corporacion-litoral-v13 /opt/corporacion-litoral-v14 /opt/corporacion-litoral-v15; do
  if [[ -d "$old_dir" ]]; then
    archive="$BACKUP_DIR/$(basename "$old_dir").tar.gz"
    tar -czf "$archive" -C "$(dirname "$old_dir")" "$(basename "$old_dir")"
    chmod 0600 "$archive"
  fi
done

install -d -o root -g root -m 0700 "$BACKUP_DIR/systemd" "$BACKUP_DIR/asterisk" "$BACKUP_DIR/agi-bin" "$BACKUP_DIR/nginx" "$BACKUP_DIR/local-sbin"
for unit in voip-api.service voip-frontend.service voip-live-monitor.service voip-system-monitor.service; do
  [[ -f "/etc/systemd/system/$unit" ]] && cp -a "/etc/systemd/system/$unit" "$BACKUP_DIR/systemd/"
done
for config in extensions_custom.conf extensions_dashboard_custom.conf dashboard-db.php dashboard-writer.cnf; do
  [[ -f "/etc/asterisk/$config" ]] && cp -a "/etc/asterisk/$config" "$BACKUP_DIR/asterisk/"
done
[[ -f /var/lib/asterisk/agi-bin/ivr_event.php ]] && cp -a /var/lib/asterisk/agi-bin/ivr_event.php "$BACKUP_DIR/agi-bin/"
[[ -f /etc/nginx/dashboard-auth.inc ]] && cp -a /etc/nginx/dashboard-auth.inc "$BACKUP_DIR/nginx/"
[[ -f /etc/nginx/conf.d/dashboard.conf ]] && cp -a /etc/nginx/conf.d/dashboard.conf "$BACKUP_DIR/nginx/"
for script in voip-live-snapshot.sh voip-system-snapshot.sh update_trunk_status.sh; do
  [[ -f "/usr/local/sbin/$script" ]] && cp -a "/usr/local/sbin/$script" "$BACKUP_DIR/local-sbin/"
done
printf '%s\n' "$BACKUP_DIR" >/root/ULTIMO_RESPALDO_DASHBOARD
chmod 0600 /root/ULTIMO_RESPALDO_DASHBOARD

if ! getent group dashboard >/dev/null; then groupadd --system dashboard; fi
if ! id dashboard >/dev/null 2>&1; then
  useradd --system --gid dashboard --groups asterisk --home-dir /nonexistent --shell /sbin/nologin dashboard
else
  usermod -aG asterisk dashboard
fi

# Conserva credenciales y configuracion de la version mas reciente disponible.
for old_dir in /opt/corporacion-litoral-v15 /opt/corporacion-litoral-v14 /opt/corporacion-litoral-v13 /opt/corporacion-litoral-v12 /opt/corporacion-litoral-v11 /opt/corporacion-litoral; do
  if [[ ! -f "$PROJECT_DIR/dashboard/backend/.env" && -f "$old_dir/dashboard/backend/.env" ]]; then
    cp -a "$old_dir/dashboard/backend/.env" "$PROJECT_DIR/dashboard/backend/.env"
  fi
  if [[ ! -f "$PROJECT_DIR/dashboard/frontend/.env.local" && -f "$old_dir/dashboard/frontend/.env.local" ]]; then
    cp -a "$old_dir/dashboard/frontend/.env.local" "$PROJECT_DIR/dashboard/frontend/.env.local"
  fi
done

if [[ ! -f "$PROJECT_DIR/dashboard/backend/.env" ]]; then
  cp "$PROJECT_DIR/dashboard/backend/.env.example" "$PROJECT_DIR/dashboard/backend/.env"
  chmod 0640 "$PROJECT_DIR/dashboard/backend/.env"
  echo "ERROR: se creo .env. Reemplace DB_PASSWORD y vuelva a ejecutar." >&2
  exit 2
fi
if grep -q 'REEMPLAZAR_CON_CLAVE_REAL' "$PROJECT_DIR/dashboard/backend/.env"; then
  echo "ERROR: configure la clave real de dashboard_reader en .env." >&2
  exit 2
fi

# La IP local se detecta de forma automatica. La IP del peer se lee del peer
# BODEGA-IAX en Asterisk, incluso cuando el administrador la cambia en Issabel.
if grep -q '^PBX_LOCAL_IP=' "$PROJECT_DIR/dashboard/backend/.env"; then
  sed -i 's/^PBX_LOCAL_IP=.*/PBX_LOCAL_IP=auto/' "$PROJECT_DIR/dashboard/backend/.env"
else
  printf '%s\n' 'PBX_LOCAL_IP=auto' >>"$PROJECT_DIR/dashboard/backend/.env"
fi

cd "$PROJECT_DIR/dashboard/backend"
if [[ -f package-lock.json ]]; then /usr/local/bin/npm ci --omit=dev; else /usr/local/bin/npm install --omit=dev; fi
/usr/local/bin/npm run check
/usr/local/bin/npm test

cd "$PROJECT_DIR/dashboard/frontend"
/usr/local/bin/npm ci
/usr/local/bin/npm test
/usr/local/bin/npm run build
/usr/local/bin/node --test "$PROJECT_DIR/scripts/"*.test.mjs

chown -R dashboard:dashboard "$PROJECT_DIR/dashboard/backend" "$PROJECT_DIR/dashboard/frontend"
chown root:dashboard "$PROJECT_DIR/dashboard/backend/.env"
chmod 0640 "$PROJECT_DIR/dashboard/backend/.env"

install -o root -g root -m 0644 "$PROJECT_DIR/issabel/systemd/voip-api.service" /etc/systemd/system/voip-api.service
install -o root -g root -m 0644 "$PROJECT_DIR/issabel/systemd/voip-frontend.service" /etc/systemd/system/voip-frontend.service
install -o root -g root -m 0644 "$PROJECT_DIR/issabel/systemd/voip-live-monitor.service" /etc/systemd/system/voip-live-monitor.service
install -o root -g root -m 0644 "$PROJECT_DIR/issabel/systemd/voip-system-monitor.service" /etc/systemd/system/voip-system-monitor.service
install -o root -g root -m 0755 "$PROJECT_DIR/scripts/voip_live_snapshot.sh" /usr/local/sbin/voip-live-snapshot.sh
install -o root -g root -m 0755 "$PROJECT_DIR/scripts/voip_system_snapshot.sh" /usr/local/sbin/voip-system-snapshot.sh

# Actualiza la correlacion IVR -> CDR sin cambiar credenciales. Si la
# telemetria aun no existe, el instalador principal no pide la clave root de
# MariaDB: se mantiene el flujo explicito install_dashboard_telemetry.sh.
if [[ -r /etc/asterisk/dashboard-db.php ]]; then
  install -o asterisk -g asterisk -m 0750 "$PROJECT_DIR/issabel/agi/ivr_event.php" /var/lib/asterisk/agi-bin/ivr_event.php
  install -o root -g asterisk -m 0640 "$PROJECT_DIR/issabel/extensions_custom.conf" /etc/asterisk/extensions_dashboard_custom.conf
  touch /etc/asterisk/extensions_custom.conf
  if ! grep -Fqx '#include extensions_dashboard_custom.conf' /etc/asterisk/extensions_custom.conf; then
    printf '\n#include extensions_dashboard_custom.conf\n' >>/etc/asterisk/extensions_custom.conf
  fi
else
  echo "AVISO: telemetria IVR no instalada; ejecute scripts/install_dashboard_telemetry.sh despues." >&2
fi

# La autenticacion web queda preparada, pero desactivada para no bloquear el
# acceso actual. Se habilita despues con enable_dashboard_auth.sh.
if [[ -d /etc/nginx && ! -f /etc/nginx/dashboard-auth.inc ]]; then
  install -o root -g root -m 0644 "$PROJECT_DIR/issabel/seguridad/nginx-dashboard-auth-disabled.conf" /etc/nginx/dashboard-auth.inc
fi

systemctl daemon-reload
asterisk -rx 'dialplan reload' >/dev/null || true
systemctl enable voip-api.service voip-frontend.service voip-live-monitor.service voip-system-monitor.service
bash "$PROJECT_DIR/scripts/activate_live_trunk_monitor.sh"
systemctl restart voip-system-monitor.service voip-frontend.service

for _ in {1..20}; do
  if curl -fsS http://127.0.0.1:4000/api/health >/dev/null \
    && curl -fsS http://127.0.0.1:4000/api/system-status >/dev/null \
    && curl -fsS http://127.0.0.1:4000/api/voicemail >/dev/null \
    && curl -fsS http://127.0.0.1:3000 >/dev/null; then
    echo "Dashboard v16 instalado correctamente."
    echo "Respaldo anterior: $BACKUP_DIR"
    echo "Verificacion: node $PROJECT_DIR/scripts/verify_dashboard.mjs"
    exit 0
  fi
  sleep 1
done

echo "ERROR: los servicios no respondieron. La copia anterior sigue en $BACKUP_DIR." >&2
systemctl --no-pager --full status voip-api.service voip-frontend.service voip-live-monitor.service voip-system-monitor.service >&2 || true
exit 1
