#!/usr/bin/env bash
set -uo pipefail

OUTPUT_FILE=${SYSTEM_STATUS_FILE:-/run/voip-dashboard/system-status.env}
INTERVAL=${SYSTEM_STATUS_INTERVAL_SECONDS:-30}
umask 027

safe_value() {
  printf '%s' "${1:-}" | tr '\r\n=' '   ' | tr -cd '[:alnum:]_.:@/+ -' | cut -c1-120
}

service_state() {
  systemctl is-active "$1" 2>/dev/null || printf 'inactive'
}

write_snapshot() {
  local temp="${OUTPUT_FILE}.tmp.$$"
  local fail2ban_state firewall_state firewall_zone firewall_ports anonymous mariadb_local https backup_path auth banned
  local fail2ban_maxretry fail2ban_bantime fail2ban_findtime password_min_length

  fail2ban_state=$(service_state fail2ban.service)
  banned=0
  fail2ban_maxretry=''
  fail2ban_bantime=''
  fail2ban_findtime=''
  if [[ "$fail2ban_state" == active ]] && command -v fail2ban-client >/dev/null 2>&1; then
    banned=$(fail2ban-client status asterisk 2>/dev/null | awk -F: '/Currently banned/ {gsub(/ /,"",$2); print $2; exit}')
    [[ "$banned" =~ ^[0-9]+$ ]] || banned=0
    fail2ban_maxretry=$(fail2ban-client get asterisk maxretry 2>/dev/null || true)
    fail2ban_bantime=$(fail2ban-client get asterisk bantime 2>/dev/null || true)
    fail2ban_findtime=$(fail2ban-client get asterisk findtime 2>/dev/null || true)
  fi

  firewall_state=unknown
  firewall_zone=''
  firewall_ports=''
  if command -v firewall-cmd >/dev/null 2>&1; then
    firewall_state=$(firewall-cmd --state 2>/dev/null || printf 'inactive')
    firewall_zone=$(firewall-cmd --get-active-zones 2>/dev/null | awk 'NR==1 {print $1}')
    [[ -n "$firewall_zone" ]] && firewall_ports=$(firewall-cmd --zone="$firewall_zone" --list-ports 2>/dev/null || true)
  fi

  anonymous=unknown
  if /usr/sbin/asterisk -rx 'sip show settings' 2>/dev/null | grep -Eiq 'Allow SIP Guests[[:space:]]*:[[:space:]]*No'; then
    anonymous=disabled
  elif grep -Eiq '^[[:space:]]*allowguest[[:space:]]*=[[:space:]]*no' /etc/asterisk/sip_general_custom.conf 2>/dev/null; then
    anonymous=disabled
  elif /usr/sbin/asterisk -rx 'sip show settings' 2>/dev/null | grep -Eiq 'Allow SIP Guests[[:space:]]*:[[:space:]]*Yes'; then
    anonymous=enabled
  fi

  mariadb_local=unknown
  if command -v ss >/dev/null 2>&1; then
    if ss -lntH 2>/dev/null | awk '{print $4}' | grep -Eq '^(0\.0\.0\.0:|\*:|\[::\]:)3306$'; then
      mariadb_local=exposed
    elif ss -lntH 2>/dev/null | awk '{print $4}' | grep -Eq '(^127\.0\.0\.1:|^\[::1\]:)3306$'; then
      mariadb_local=local
    fi
  fi

  https=inactive
  if command -v ss >/dev/null 2>&1 && ss -lntH 2>/dev/null | awk '{print $4}' | grep -Eq ':443$'; then
    https=active
  fi

  backup_path=''
  if [[ -r /root/ULTIMO_RESPALDO_DASHBOARD ]]; then
    backup_path=$(head -n 1 /root/ULTIMO_RESPALDO_DASHBOARD)
  fi

  auth=disabled
  if grep -qsE '^[[:space:]]*auth_basic[[:space:]]+' /etc/nginx/dashboard-auth.inc 2>/dev/null; then
    auth=active
  fi

  password_min_length=$(awk -F= '/^[[:space:]]*minlen[[:space:]]*=/ {gsub(/[[:space:]]/,"",$2); print $2; exit}' /etc/security/pwquality.conf 2>/dev/null || true)
  if [[ ! "$password_min_length" =~ ^[0-9]+$ ]]; then
    password_min_length=$(awk '/^[[:space:]]*PASS_MIN_LEN[[:space:]]+/ {print $2; exit}' /etc/login.defs 2>/dev/null || true)
  fi
  [[ "$password_min_length" =~ ^[0-9]+$ ]] || password_min_length=unknown

  {
    printf 'checked_at=%s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    printf 'asterisk=%s\n' "$(safe_value "$(service_state asterisk.service)")"
    printf 'mariadb=%s\n' "$(safe_value "$(service_state mariadb.service)")"
    printf 'nginx=%s\n' "$(safe_value "$(service_state nginx.service)")"
    printf 'voip_api=%s\n' "$(safe_value "$(service_state voip-api.service)")"
    printf 'voip_frontend=%s\n' "$(safe_value "$(service_state voip-frontend.service)")"
    printf 'voip_live_monitor=%s\n' "$(safe_value "$(service_state voip-live-monitor.service)")"
    printf 'voip_system_monitor=%s\n' "$(safe_value "$(service_state voip-system-monitor.service)")"
    printf 'fail2ban_asterisk=%s\n' "$(safe_value "$fail2ban_state")"
    printf 'fail2ban_banned=%s\n' "$(safe_value "$banned")"
    printf 'fail2ban_maxretry=%s\n' "$(safe_value "$fail2ban_maxretry")"
    printf 'fail2ban_bantime=%s\n' "$(safe_value "$fail2ban_bantime")"
    printf 'fail2ban_findtime=%s\n' "$(safe_value "$fail2ban_findtime")"
    printf 'firewall=%s\n' "$(safe_value "$firewall_state")"
    printf 'firewall_zone=%s\n' "$(safe_value "$firewall_zone")"
    printf 'firewall_ports=%s\n' "$(safe_value "$firewall_ports")"
    printf 'anonymous_sip=%s\n' "$(safe_value "$anonymous")"
    printf 'mariadb_local=%s\n' "$(safe_value "$mariadb_local")"
    printf 'https=%s\n' "$(safe_value "$https")"
    printf 'dashboard_auth=%s\n' "$(safe_value "$auth")"
    printf 'password_min_length=%s\n' "$(safe_value "$password_min_length")"
    printf 'backup_path=%s\n' "$(safe_value "$backup_path")"
  } >"$temp"
  chown root:dashboard "$temp"
  chmod 0640 "$temp"
  mv -f "$temp" "$OUTPUT_FILE"
}

cleanup() {
  rm -f "${OUTPUT_FILE}.tmp.$$"
}
trap cleanup EXIT INT TERM

while true; do
  write_snapshot
  sleep "$INTERVAL"
done
