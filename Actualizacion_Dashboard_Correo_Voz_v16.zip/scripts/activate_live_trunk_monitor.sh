#!/usr/bin/env bash
set -euo pipefail

# Habilita a la API para consultar el socket local de Asterisk sin ejecutar
# todo el dashboard como root. Ejecutar en la PBX principal.

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERROR: ejecute este script como root." >&2
  exit 1
fi

if ! systemctl cat voip-api.service >/dev/null 2>&1; then
  echo "ERROR: voip-api.service no esta instalado." >&2
  exit 1
fi

if ! getent group asterisk >/dev/null 2>&1; then
  echo "ERROR: no existe el grupo asterisk." >&2
  exit 1
fi

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd -- "$SCRIPT_DIR/.." && pwd)"
ENV_FILE="$PROJECT_DIR/dashboard/backend/.env"

if [[ ! -f "$ENV_FILE" ]]; then
  echo "ERROR: no existe $ENV_FILE; configure primero las credenciales de la API." >&2
  exit 1
fi

set_env_value() {
  local key="$1"
  local value="$2"
  if grep -qE "^${key}=" "$ENV_FILE"; then
    sed -i "s|^${key}=.*|${key}=${value}|" "$ENV_FILE"
  else
    printf '%s=%s\n' "$key" "$value" >>"$ENV_FILE"
  fi
}

ensure_env_default() {
  local key="$1"
  local value="$2"
  grep -qE "^${key}=" "$ENV_FILE" || printf '%s=%s\n' "$key" "$value" >>"$ENV_FILE"
}

if [[ -n "${IAX_PEER_IP_VALUE:-}" ]]; then
  set_env_value IAX_PEER_IP "$IAX_PEER_IP_VALUE"
else
  set_env_value IAX_PEER_IP auto
fi
set_env_value IAX_CONNECTION_MODE internal
set_env_value IAX_REGISTRATION_REQUIRED false
if [[ -n "${PBX_INTERFACE_VALUE:-}" ]]; then
  set_env_value PBX_INTERFACE "$PBX_INTERFACE_VALUE"
else
  ensure_env_default PBX_INTERFACE eth2
fi
set_env_value PBX_LOCAL_IP "${PBX_LOCAL_IP_VALUE:-auto}"
set_env_value ASTERISK_CHANNELS_FILE /run/voip-dashboard/channels.concise
set_env_value LIVE_CALLS_MAX_AGE_SECONDS 8
set_env_value ASTERISK_PEERS_FILE /run/voip-dashboard/iax-peers.txt
set_env_value ASTERISK_PEERS_MAX_AGE_SECONDS 8

if [[ -f "$PROJECT_DIR/database/update_trunk_status.sh" ]]; then
  install -o root -g root -m 0750 \
    "$PROJECT_DIR/database/update_trunk_status.sh" /usr/local/sbin/update_trunk_status.sh
fi

install -o root -g root -m 0755 \
  "$PROJECT_DIR/scripts/voip_live_snapshot.sh" /usr/local/sbin/voip-live-snapshot.sh
install -o root -g root -m 0644 \
  "$PROJECT_DIR/issabel/systemd/voip-live-monitor.service" \
  /etc/systemd/system/voip-live-monitor.service

install -d -o root -g root -m 0755 /etc/systemd/system/voip-api.service.d
cat >/etc/systemd/system/voip-api.service.d/asterisk-access.conf <<'EOF'
[Service]
SupplementaryGroups=asterisk
EOF
chmod 0644 /etc/systemd/system/voip-api.service.d/asterisk-access.conf

systemctl daemon-reload
systemctl enable voip-live-monitor.service
systemctl restart voip-live-monitor.service
systemctl restart voip-api.service
/usr/local/sbin/update_trunk_status.sh || true

for _ in {1..10}; do
  if curl -fsS http://127.0.0.1:4000/api/trunk \
    && printf '\n' \
    && curl -fsS http://127.0.0.1:4000/api/live-calls; then
    printf '\n'
    echo "Monitores de troncal y llamadas activas habilitados."
    exit 0
  fi
  sleep 1
done

echo "ERROR: la API no respondio despues de reiniciar." >&2
systemctl --no-pager --full status voip-api.service >&2 || true
exit 1
