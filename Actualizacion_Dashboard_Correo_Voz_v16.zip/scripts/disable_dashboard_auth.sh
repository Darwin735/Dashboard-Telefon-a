#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR=/opt/corporacion-litoral-v16
ENV_FILE="$PROJECT_DIR/dashboard/backend/.env"

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERROR: ejecute como root." >&2
  exit 1
fi

install -o root -g root -m 0644 \
  "$PROJECT_DIR/issabel/seguridad/nginx-dashboard-auth-disabled.conf" \
  /etc/nginx/dashboard-auth.inc
if grep -q '^AUTH_MODE=' "$ENV_FILE"; then
  sed -i 's/^AUTH_MODE=.*/AUTH_MODE=off/' "$ENV_FILE"
else
  printf '%s\n' 'AUTH_MODE=off' >>"$ENV_FILE"
fi
nginx -t
systemctl reload nginx
systemctl restart voip-api.service
echo "Autenticacion del dashboard deshabilitada."
