import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import test from 'node:test';

const root = new URL('../', import.meta.url);
const text = (path) => readFile(new URL(path, root), 'utf8');

test('el instalador v16 respalda v15 y configuraciones antes de instalar', async () => {
  const installer = await text('scripts/install_v16.sh');
  const backup = installer.indexOf('tar -czf "$archive"');
  const dependencies = installer.indexOf('cd "$PROJECT_DIR/dashboard/backend"');
  assert.ok(backup >= 0 && backup < dependencies);
  assert.match(installer, /\/opt\/corporacion-litoral-v12/);
  assert.match(installer, /\/opt\/corporacion-litoral-v13/);
  assert.match(installer, /\/opt\/corporacion-litoral-v14/);
  assert.match(installer, /\/opt\/corporacion-litoral-v15/);
  assert.match(installer, /corporacion-litoral-before-v16-\$STAMP/);
  assert.match(installer, /\/root\/ULTIMO_RESPALDO_DASHBOARD/);
  assert.match(installer, /voip-system-monitor\.service/);
  assert.match(installer, /\$BACKUP_DIR\/agi-bin/);
  assert.match(installer, /CHANNEL\(linkedid\)|issabel\/agi\/ivr_event\.php/);
  assert.doesNotMatch(installer, /rm\s+-rf/);
});

test('la restauracion repone servicios, Asterisk, Nginx y scripts', async () => {
  const restore = await text('scripts/restore_previous_version.sh');
  assert.match(restore, /tar -xzf "\$archive" -C \/opt/);
  assert.match(restore, /\$BACKUP_DIR\/systemd/);
  assert.match(restore, /\$BACKUP_DIR\/nginx/);
  assert.match(restore, /\$BACKUP_DIR\/local-sbin/);
  assert.match(restore, /\$BACKUP_DIR\/agi-bin/);
  assert.doesNotMatch(restore, /rm\s+-rf/);
});

test('los servicios ejecutan exclusivamente el arbol v16', async () => {
  const api = await text('issabel/systemd/voip-api.service');
  const frontend = await text('issabel/systemd/voip-frontend.service');
  assert.match(api, /\/opt\/corporacion-litoral-v16\/dashboard\/backend/);
  assert.match(frontend, /\/opt\/corporacion-litoral-v16\/dashboard\/frontend/);
  assert.match(api, /\/var\/spool\/asterisk\/voicemail/);
});

test('versiones y lock del frontend son coherentes', async () => {
  const backend = JSON.parse(await text('dashboard/backend/package.json'));
  const frontend = JSON.parse(await text('dashboard/frontend/package.json'));
  const lock = JSON.parse(await text('dashboard/frontend/package-lock.json'));
  assert.equal(backend.version, '1.6.0');
  assert.equal(frontend.version, '1.6.0');
  assert.equal(lock.version, frontend.version);
  assert.equal(lock.packages[''].version, frontend.version);
  assert.equal(lock.packages['node_modules/postcss'].version, '8.5.23');
  assert.ok(Number(lock.packages['node_modules/nanoid'].version.split('.')[2]) >= 17);
  const backendLock = JSON.parse(await text('dashboard/backend/package-lock.json'));
  assert.equal(backendLock.packages[''].version, backend.version);
});

test('la IP local es automatica y el peer se identifica por nombre', async () => {
  const env = await text('dashboard/backend/.env.example');
  const activation = await text('scripts/activate_live_trunk_monitor.sh');
  const asterisk = await text('dashboard/backend/src/asterisk.js');
  assert.match(env, /PBX_LOCAL_IP=auto/);
  assert.match(env, /IAX_PEER_IP=auto/);
  assert.match(env, /IAX_TRUNK_NAME=BODEGA-IAX/);
  assert.match(activation, /PBX_LOCAL_IP_VALUE:-auto/);
  assert.match(asterisk, /peer\.name === trunkName/);
});

test('los eventos IVR reciben linkedid explicito para correlacion con CDR', async () => {
  const dialplan = await text('issabel/extensions_custom.conf');
  const agi = await text('issabel/agi/ivr_event.php');
  assert.match(dialplan, /AGI\(ivr_event\.php,1,VENTAS,7000,\$\{CHANNEL\(linkedid\)\}\)/);
  assert.match(agi, /\$argv\[4\]/);
  assert.doesNotMatch(agi, /agi_threadid/);
});

test('seguridad y autenticacion opcional quedan preparadas', async () => {
  const installer = await text('scripts/install_v16.sh');
  const nginx = await text('issabel/seguridad/nginx-dashboard.conf');
  const auth = await text('scripts/enable_dashboard_auth.sh');
  assert.match(installer, /nginx-dashboard-auth-disabled\.conf/);
  assert.match(nginx, /include \/etc\/nginx\/dashboard-auth\.inc/);
  assert.match(auth, /openssl passwd -6/);
  assert.match(auth, /al menos 12 caracteres/);
});
