#!/usr/bin/env bash
set -euo pipefail

BACKUP_DIR=${1:-}

if [[ ${EUID:-$(id -u)} -ne 0 ]]; then
  echo "ERROR: ejecute como root." >&2
  exit 1
fi
if [[ -z "$BACKUP_DIR" || ! -d "$BACKUP_DIR" ]]; then
  echo "Uso: $0 /opt/backups/corporacion-litoral-before-v16-FECHA" >&2
  exit 2
fi

systemctl stop voip-frontend.service voip-api.service voip-live-monitor.service voip-system-monitor.service || true

if [[ ! -f "$BACKUP_DIR/systemd/voip-system-monitor.service" ]]; then
  systemctl disable voip-system-monitor.service >/dev/null 2>&1 || true
  rm -f /etc/systemd/system/voip-system-monitor.service
fi

for archive in "$BACKUP_DIR"/corporacion-litoral*.tar.gz; do
  [[ -f "$archive" ]] || continue
  tar -xzf "$archive" -C /opt
done

if [[ -d "$BACKUP_DIR/systemd" ]]; then
  cp -a "$BACKUP_DIR/systemd"/*.service /etc/systemd/system/ 2>/dev/null || true
fi
if [[ -d "$BACKUP_DIR/asterisk" ]]; then
  cp -a "$BACKUP_DIR/asterisk"/* /etc/asterisk/ 2>/dev/null || true
fi
if [[ -d "$BACKUP_DIR/agi-bin" ]]; then
  cp -a "$BACKUP_DIR/agi-bin"/* /var/lib/asterisk/agi-bin/ 2>/dev/null || true
fi
if [[ -d "$BACKUP_DIR/nginx" ]]; then
  [[ -f "$BACKUP_DIR/nginx/dashboard-auth.inc" ]] && cp -a "$BACKUP_DIR/nginx/dashboard-auth.inc" /etc/nginx/dashboard-auth.inc
  [[ -f "$BACKUP_DIR/nginx/dashboard.conf" ]] && cp -a "$BACKUP_DIR/nginx/dashboard.conf" /etc/nginx/conf.d/dashboard.conf
fi
if [[ -d "$BACKUP_DIR/local-sbin" ]]; then
  cp -a "$BACKUP_DIR/local-sbin"/* /usr/local/sbin/ 2>/dev/null || true
fi

systemctl daemon-reload
asterisk -rx 'dialplan reload' || true
if command -v nginx >/dev/null 2>&1 && nginx -t; then systemctl reload nginx || true; fi
systemctl restart voip-live-monitor.service voip-api.service voip-frontend.service
[[ -f /etc/systemd/system/voip-system-monitor.service ]] && systemctl restart voip-system-monitor.service || true
echo "Version anterior restaurada desde $BACKUP_DIR."
