#!/usr/bin/env node

import { readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const API = (process.env.API_URL ?? 'http://127.0.0.1:4000/api').replace(/\/$/, '');
const PROJECT_ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const isoDate = (date) => date.toISOString().slice(0, 10);
const to = process.env.TO ?? isoDate(new Date());
const fromDate = new Date(`${to}T12:00:00Z`);
fromDate.setUTCDate(fromDate.getUTCDate() - 29);
const from = process.env.FROM ?? isoDate(fromDate);
const query = new URLSearchParams({ from, to }).toString();

async function get(name, ranged = true) {
  const response = await fetch(`${API}/${name}${ranged ? `?${query}` : ''}`);
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(`${name}: ${body.error ?? `HTTP ${response.status}`}`);
  return body;
}

const definitions = [
  ['health', false], ['system-status', false], ['security', false],
  ['summary', true], ['departments', true], ['ring-groups', true],
  ['hourly', true], ['daily', true], ['ivr', true], ['trends', true],
  ['trunk', false], ['trunks', false], ['trunk-history', true],
  ['live-calls', false], ['calls', true], ['quality', true],
  ['evidence', true], ['voicemail', false],
];
const settled = await Promise.allSettled(definitions.map(([name, ranged]) => get(name, ranged)));
const endpoints = Object.fromEntries(definitions.map(([name], index) => [name, settled[index].status === 'fulfilled'
  ? { ok: true, value: settled[index].value }
  : { ok: false, error: settled[index].reason?.message ?? 'consulta fallida' }]));

const checks = [];
const check = (requirement, pass, evidence) => checks.push({ requirement, pass: Boolean(pass), evidence });
const value = (name) => endpoints[name]?.value ?? {};
const error = (name) => endpoints[name]?.ok ? '' : `No disponible: ${endpoints[name]?.error}`;
const finite = (candidate) => Number.isFinite(Number(candidate));
const items = (name) => Array.isArray(value(name).items) ? value(name).items : [];

const health = value('health');
check('Conexion en vivo a MariaDB', endpoints.health.ok && health.status === 'ok' && health.database === true,
  error('health') || `API v${health.version}; database=${health.database}`);

const system = value('system-status');
check('Centro de diagnostico de servicios y fuentes', endpoints['system-status'].ok && Array.isArray(system.checks) && system.checks.length >= 8,
  error('system-status') || `${system.checks?.length ?? 0} comprobaciones; estado=${system.status}`);

const security = value('security');
check('Lectura de hardening para evidencia', endpoints.security.ok && Array.isArray(security.controls) && security.controls.length >= 7,
  error('security') || `${security.controls?.length ?? 0} controles leidos sin modificar la PBX`);

const summary = value('summary');
const total = Number(summary.total);
check('KPIs obligatorios del periodo', endpoints.summary.ok && [summary.total, summary.answered, summary.answerRate, summary.avgDuration].every(finite)
  && total >= 0 && Number(summary.answerRate) >= 0 && Number(summary.answerRate) <= 100,
error('summary') || `total=${summary.total}; contestadas=${summary.answered}; respuesta=${summary.answerRate}%; promedio=${summary.avgDuration}s`);

const calls = value('calls');
check('Explorador de llamadas CDR con LinkedID', endpoints.calls.ok && Number(calls.total) > 0 && items('calls').every((call) => call.id && call.department && call.direction),
  error('calls') || `${calls.total ?? 0} llamadas; ${items('calls').length} filas consultadas`);

const departments = items('departments');
const expectedDepartments = ['Recepcion', 'Ventas', 'Soporte', 'Finanzas', 'Gerencia', 'Logistica', 'Bodega remota'];
check('Demanda por todos los departamentos', endpoints.departments.ok && expectedDepartments.every((name) => departments.some((row) => row.department === name))
  && departments.reduce((sum, row) => sum + Number(row.calls ?? 0), 0) > 0,
error('departments') || departments.map((row) => `${row.department}=${row.calls}`).join(', '));

const groups = items('ring-groups');
check('Ventas y Soporte con respuesta, espera y voicemail', endpoints['ring-groups'].ok && ['Ventas', 'Soporte'].every((name) => groups.some((row) => row.groupName === name))
  && groups.every((row) => ['answerRate', 'avgWaitSeconds', 'voicemail'].every((field) => finite(row[field]))),
error('ring-groups') || groups.map((row) => `${row.groupName}: ${row.answerRate}% / VM ${row.voicemail}`).join(', '));

const hourly = items('hourly');
check('Distribucion por hora consistente', endpoints.hourly.ok && hourly.length === 24 && hourly.reduce((sum, row) => sum + Number(row.calls), 0) === total,
  error('hourly') || `${hourly.length} horas; suma=${hourly.reduce((sum, row) => sum + Number(row.calls), 0)}`);

const daily = items('daily');
check('Evolucion diaria consistente', endpoints.daily.ok && daily.length > 0 && daily.reduce((sum, row) => sum + Number(row.calls), 0) === total,
  error('daily') || `${daily.length} dias; suma=${daily.reduce((sum, row) => sum + Number(row.calls), 0)}`);

const ivr = items('ivr');
const menus = new Set(ivr.map((row) => String(row.menuId)));
check('Uso real de IVR en dos niveles', endpoints.ivr.ok && menus.has('7000') && menus.has('7001') && ivr.every((row) => Number(row.selections) > 0),
  error('ivr') || ivr.map((row) => `${row.menuId}/${row.optionCode}=${row.selections}`).join(', '));

const trunk = value('trunk');
check('Estado actualizado de la troncal IAX2', endpoints.trunk.ok && ['UP', 'DOWN'].includes(trunk.status) && trunk.stale !== true && trunk.checkedAt,
  error('trunk') || `${trunk.trunkName} ${trunk.peerIp}: ${trunk.status}; fuente=${trunk.source}`);
const ipv4 = /^\d{1,3}(?:\.\d{1,3}){3}$/;
check('Deteccion dinamica de IP por peer y red activa', endpoints.trunk.ok && trunk.trunkName === 'BODEGA-IAX' && ipv4.test(String(trunk.localIp)) && ipv4.test(String(trunk.peerIp)),
  error('trunk') || `local detectada=${trunk.localIp}; peer obtenido de Asterisk=${trunk.peerIp}`);

const peers = items('trunks');
const unwanted = peers.filter((peer) => peer.legacyName || peer.duplicateAddress);
check('Inventario IAX2 sin peers heredados o duplicados', endpoints.trunks.ok && peers.some((peer) => peer.expectedName) && unwanted.length === 0,
  error('trunks') || (unwanted.length ? `Revisar: ${unwanted.map((peer) => peer.name).join(', ')}` : `${peers.length} peer(s), sin duplicados`));

const history = value('trunk-history');
check('Historial y disponibilidad de la troncal', endpoints['trunk-history'].ok && Number(history.summary?.samples) > 0 && finite(history.summary?.uptimePercent),
  error('trunk-history') || `${history.summary?.samples ?? 0} muestras; disponibilidad=${history.summary?.uptimePercent ?? '—'}%`);

const live = value('live-calls');
check('Monitor de llamadas en curso operativo', endpoints['live-calls'].ok && live.status === 'ok' && live.updatedAt && Array.isArray(live.items),
  error('live-calls') || `${live.total ?? 0} en curso; lectura=${live.updatedAt}`);

const trends = value('trends');
check('Comparacion contra el periodo anterior', endpoints.trends.ok && trends.previousRange && ['total', 'answered', 'answerRate', 'avgDuration'].every((field) => finite(trends.changes?.[field])),
  error('trends') || `cambio volumen=${trends.changes?.total}%`);

const quality = value('quality');
check('Calidad IAX2 y limitacion RTP documentada', endpoints.quality.ok && 'availabilityPercent' in quality && quality.rtp?.available === false && /RTCP|RTP/i.test(quality.rtp?.detail ?? ''),
  error('quality') || `IAX=${quality.iaxLatencyMs ?? '—'}ms; ${quality.rtp?.detail}`);

const evidence = value('evidence');
check('Reporte de evidencia consolidado', endpoints.evidence.ok && evidence.version === '1.6.0' && evidence.declaration && evidence.summary && evidence.system && evidence.security && evidence.voicemail,
  error('evidence') || `v${evidence.version}; generado=${evidence.generatedAt}`);

try {
  const response = await fetch(`${API}/export/calls.csv?${query}`);
  const body = await response.text();
  check('Exportacion CSV de llamadas', response.ok && /Fecha y hora/.test(body) && body.split(/\r?\n/).length > 1,
    response.ok ? `${body.split(/\r?\n/).length - 1} lineas exportadas` : `HTTP ${response.status}`);
} catch (exportError) {
  check('Exportacion CSV de llamadas', false, exportError.message);
}

const voicemail = value('voicemail');
check('Bandeja de correo de voz de solo lectura', endpoints.voicemail.ok && voicemail.status === 'ok'
  && Array.isArray(voicemail.items) && Array.isArray(voicemail.mailboxes) && finite(voicemail.totals?.total),
error('voicemail') || `${voicemail.totals?.total ?? 0} mensajes; ${voicemail.totals?.playable ?? 0} reproducibles`);

try {
  const files = ['dashboard/backend/package.json', 'dashboard/frontend/package.json', 'dashboard/backend/src/server.js',
    'dashboard/frontend/app/page.js', 'scripts/install_v16.sh', 'MANUAL_DASHBOARD.md'];
  const [backendText, frontendText, serverSource, pageSource, installer, manual] = await Promise.all(files.map((file) => readFile(resolve(PROJECT_ROOT, file), 'utf8')));
  const backend = JSON.parse(backendText); const frontend = JSON.parse(frontendText);
  check('Tecnologias y version v16', backend.version === '1.6.0' && frontend.version === '1.6.0'
    && backend.dependencies?.express && backend.dependencies?.mariadb && frontend.dependencies?.next,
  `backend=${backend.version}; frontend=${frontend.version}; Express/Next/MariaDB presentes`);
  check('Fuentes reales y ausencia de modo simulado', /FROM cdr/i.test(serverSource) && /FROM ivr_events/i.test(serverSource)
    && /getLiveIaxTrunkStatus/.test(serverSource) && /fetch\(`/i.test(pageSource) && !/mockData|demoData|Math\.random\s*\(/i.test(`${serverSource}\n${pageSource}`),
  'CDR, IVR, Asterisk y snapshots reales; no se encontro modo mock');
  check('Instalacion reversible con respaldo v15', /corporacion-litoral-v15/.test(installer) && /before-v16/.test(installer) && /ULTIMO_RESPALDO_DASHBOARD/.test(installer),
    'install_v16.sh respalda v15, systemd, Asterisk, Nginx y scripts locales');
  check('Manual operativo incluido', /diagnostico|diagnóstico/i.test(manual) && /correo de voz/i.test(manual) && /evidencia/i.test(manual),
    resolve(PROJECT_ROOT, 'MANUAL_DASHBOARD.md'));
} catch (sourceError) {
  check('Archivos fuente, instalador y manual', false, sourceError.message);
}

console.log(`\nVerificacion dashboard v16 Corporacion Litoral (${from} a ${to})\n`);
for (const item of checks) {
  console.log(`${item.pass ? '[OK]' : '[PENDIENTE]'} ${item.requirement}`);
  console.log(`    ${item.evidence}`);
}
const failed = checks.filter((item) => !item.pass);
console.log(`\nResultado: ${checks.length - failed.length}/${checks.length} controles con evidencia.`);
if (failed.length) {
  console.log('Revise los elementos PENDIENTE antes de capturar la evidencia final.');
  process.exitCode = 1;
} else {
  console.log('Dashboard v16 verificado completamente con datos en vivo.');
}
