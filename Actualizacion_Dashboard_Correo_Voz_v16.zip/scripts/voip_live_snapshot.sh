#!/usr/bin/env bash
set -uo pipefail

OUTPUT_FILE=${ASTERISK_CHANNELS_FILE:-/run/voip-dashboard/channels.concise}
PEERS_FILE=${ASTERISK_PEERS_FILE:-/run/voip-dashboard/iax-peers.txt}
INTERVAL=${LIVE_CALLS_INTERVAL_SECONDS:-2}
umask 027

cleanup() {
  rm -f "${OUTPUT_FILE}.tmp.$$"
  rm -f "${PEERS_FILE}.tmp.$$"
}
trap cleanup EXIT INT TERM

while true; do
  TEMP_FILE="${OUTPUT_FILE}.tmp.$$"
  if /usr/sbin/asterisk -rx 'core show channels concise' >"$TEMP_FILE" 2>/dev/null; then
    chmod 0640 "$TEMP_FILE"
    mv -f "$TEMP_FILE" "$OUTPUT_FILE"
  else
    rm -f "$TEMP_FILE"
  fi

  PEERS_TEMP_FILE="${PEERS_FILE}.tmp.$$"
  if /usr/sbin/asterisk -rx 'iax2 show peers' >"$PEERS_TEMP_FILE" 2>/dev/null; then
    chmod 0640 "$PEERS_TEMP_FILE"
    mv -f "$PEERS_TEMP_FILE" "$PEERS_FILE"
  else
    rm -f "$PEERS_TEMP_FILE"
  fi
  sleep "$INTERVAL"
done
