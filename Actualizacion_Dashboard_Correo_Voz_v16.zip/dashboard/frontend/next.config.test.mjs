import assert from 'node:assert/strict';
import test from 'node:test';
import nextConfig from './next.config.mjs';

test('reenvia /api al backend local de Express', async () => {
  const rewrites = await nextConfig.rewrites();
  assert.deepEqual(rewrites, [
    {
      source: '/api/:path*',
      destination: 'http://127.0.0.1:4000/api/:path*',
    },
  ]);
});
