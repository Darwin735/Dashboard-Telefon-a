import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import test from 'node:test';

const source = await readFile(new URL('./app/page.js', import.meta.url), 'utf8');

test('retira los paneles solicitados y consulta correo de voz', () => {
  const endpointBlock = source.slice(source.indexOf('const ENDPOINTS'), source.indexOf('const MAX_RANGE_DAYS'));
  assert.match(endpointBlock, /'voicemail'/);
  assert.doesNotMatch(endpointBlock, /'security'|'remote-site'/);
  assert.doesNotMatch(source, /function SecurityPanel|function RemoteSitePanel/);
});

test('la bandeja de voz es la ultima seccion analitica e incluye reproductor', () => {
  const render = source.indexOf('<VoicemailPanel voicemail={data?.voicemail} />');
  const analyticsClose = source.indexOf('</section>', render);
  assert.ok(render > 0 && analyticsClose > render);
  assert.doesNotMatch(source.slice(render, analyticsClose), /<article/);
  assert.match(source, /<audio controls preload="none"/);
  assert.match(source, /solo lectura/i);
});
