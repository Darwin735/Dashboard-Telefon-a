# Frontend Next.js

Interfaz del dashboard. Todos los indicadores se cargan desde la API Express; no existe arreglo de llamadas de ejemplo ni fallback con datos simulados.

```bash
cp .env.local.example .env.local
npm install
npm run build
npm start
```

`NEXT_PUBLIC_API_URL=/api` es suficiente tanto detras de Nginx como al entrar directamente por `127.0.0.1:3000`: `next.config.mjs` reenvia esa ruta al backend local en `127.0.0.1:4000`. Para desarrollo con la API expuesta en otro host puede indicar la URL completa y agregar el origen del navegador a `CORS_ORIGIN` del backend.
