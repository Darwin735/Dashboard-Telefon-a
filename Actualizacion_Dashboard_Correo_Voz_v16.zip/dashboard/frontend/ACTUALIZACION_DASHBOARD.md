# Actualizacion del dashboard

Este paquete reemplaza solamente la interfaz del dashboard. No modifica MariaDB, Issabel, Asterisk, extensiones ni registros de llamadas.

## Mejoras incluidas

- Rangos rapidos de hoy, 7, 30 y 90 dias.
- Validacion local del limite de 93 dias.
- Actualizacion automatica opcional cada 60 segundos.
- Indicadores de llamadas contestadas y no contestadas.
- Hora y dia de mayor demanda.
- Graficos de actividad horaria y evolucion diaria.
- Distribucion por departamentos, grupos e IVR.
- Busqueda y filtro de llamadas recientes.
- Lectura explicativa del estado de la troncal.
- Soporte de actualizaciones parciales si una consulta secundaria falla.
- Diseno adaptable para computadora, tableta y telefono.

## Instalacion en Issabel

Descomprima el paquete dentro de:

`/opt/corporacion-litoral-v16/dashboard/frontend`

Despues ejecute:

```bash
cd /opt/corporacion-litoral-v16/dashboard/frontend
/usr/local/bin/npm install
/usr/local/bin/npm run build
fuser -k 3000/tcp 2>/dev/null || true
nohup /usr/local/bin/npm start >/tmp/dashboard-frontend.log 2>&1 &
```

La API y la base de datos no necesitan reiniciarse.
