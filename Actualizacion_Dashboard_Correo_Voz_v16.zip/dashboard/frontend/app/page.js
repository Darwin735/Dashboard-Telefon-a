'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';

const API = process.env.NEXT_PUBLIC_API_URL ?? '/api';
const ENDPOINTS = [
  'health', 'system-status', 'summary', 'departments', 'ring-groups',
  'hourly', 'daily', 'ivr', 'trends', 'trunk', 'trunks', 'trunk-history',
  'quality', 'calls', 'voicemail',
];
const UNRANGED_ENDPOINTS = new Set(['health', 'system-status', 'trunk', 'trunks', 'voicemail']);
const MAX_RANGE_DAYS = 93;
const CALLS_PAGE_SIZE = 25;
const PRESETS = [
  { label: 'Hoy', days: 1 },
  { label: '7 dias', days: 7 },
  { label: '30 dias', days: 30 },
  { label: '90 dias', days: 90 },
];

function isoDate(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function rangeForDays(days) {
  const to = new Date();
  const from = new Date();
  from.setDate(to.getDate() - (days - 1));
  return { from: isoDate(from), to: isoDate(to) };
}

function rangeLength(range) {
  const start = new Date(`${range.from}T12:00:00Z`);
  const end = new Date(`${range.to}T12:00:00Z`);
  return Math.round((end - start) / 86400000) + 1;
}

function validateRange(range) {
  if (!range.from || !range.to) return 'Selecciona las dos fechas.';
  const days = rangeLength(range);
  if (!Number.isFinite(days) || days < 1) return 'La fecha inicial no puede ser posterior a la fecha final.';
  if (days > MAX_RANGE_DAYS) return `Selecciona un periodo de ${MAX_RANGE_DAYS} dias o menos.`;
  return '';
}

function seconds(value) {
  const total = Math.max(0, Math.round(Number(value ?? 0)));
  const minutes = Math.floor(total / 60);
  const rest = total % 60;
  return minutes ? `${minutes}m ${rest}s` : `${rest}s`;
}

function formatDay(value, options = { day: '2-digit', month: 'short' }) {
  if (!value) return '—';
  return new Intl.DateTimeFormat('es-HN', options).format(new Date(`${String(value).slice(0, 10)}T12:00:00`));
}

function formatDateTime(value) {
  if (!value) return 'Sin lectura';
  return new Intl.DateTimeFormat('es-HN', {
    day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit',
  }).format(new Date(value));
}

function dispositionLabel(value) {
  return ({ ANSWERED: 'Contestada', 'NO ANSWER': 'No contestada', BUSY: 'Ocupado', FAILED: 'Fallida' })[value] ?? value;
}

function trunkStatusLabel(status) {
  return ({ UP: 'OPERATIVA', DOWN: 'SIN RESPUESTA', UNKNOWN: 'SIN LECTURA' })[status] ?? 'SIN LECTURA';
}

function trunkSourceLabel(source) {
  return ({
    asterisk: 'Asterisk en vivo',
    history: 'Monitor historico',
    'history-stale': 'Lectura vencida',
    'asterisk-unavailable': 'Consulta no disponible',
  })[source] ?? 'Origen desconocido';
}

function networkModeLabel(trunk) {
  if (trunk.connectionMode === 'internal') return 'Misma LAN VMware · IP detectada';
  if (trunk.connectionMode === 'vpn') return 'VPN · direcciones privadas estables';
  if (trunk.connectionMode === 'dhcp') return 'DHCP · direcciones detectadas';
  if (trunk.registrationRequired === true) return 'Red variable · registro IAX habilitado';
  return 'Red variable · direcciones detectadas';
}

function liveStatusLabel(status) {
  return ({ CONNECTED: 'Conectada', RINGING: 'Timbrando', DIALING: 'Marcando' })[status] ?? status;
}

function liveDirectionLabel(direction) {
  return ({
    PRINCIPAL_A_BODEGA: 'Principal → Bodega',
    BODEGA_A_PRINCIPAL: 'Bodega → Principal',
    ENTRE_SEDES: 'Entre sedes',
    INTERNA: 'Llamada interna',
  })[direction] ?? 'Llamada interna';
}

function sourceStatusLabel(status) {
  return ({
    ok: 'DISPONIBLE', active: 'ACTIVO', running: 'ACTIVO', local: 'LOCAL',
    disabled: 'DESHABILITADO', down: 'CAIDO', stale: 'VENCIDO', warning: 'REVISAR',
    unavailable: 'NO DISPONIBLE', inactive: 'INACTIVO', unknown: 'SIN LECTURA',
    exposed: 'EXPUESTO', enabled: 'HABILITADO', partial: 'PARCIAL',
  })[String(status).toLowerCase()] ?? String(status || 'SIN LECTURA').toUpperCase();
}

function changeLabel(value, suffix = '%') {
  if (value == null) return 'Sin base anterior';
  const number = Number(value);
  return `${number > 0 ? '+' : ''}${number}${suffix}`;
}

function queryString(range, filters = {}) {
  return new URLSearchParams(Object.fromEntries(Object.entries({ ...range, ...filters })
    .filter(([, value]) => value !== '' && value != null && value !== 'ALL'))).toString();
}

function EmptyState({ children }) {
  return <div className="empty-state"><span>•••</span><p>{children}</p></div>;
}

function MetricCard({ label, value, detail, tone = 'neutral', progress }) {
  return (
    <article className={`metric-card ${tone}`}>
      <div className="metric-top"><span>{label}</span><i aria-hidden="true" /></div>
      <strong>{value}</strong>
      <small>{detail}</small>
      {progress != null && (
        <div className="metric-progress" role="progressbar" aria-label={label} aria-valuemin="0" aria-valuemax="100" aria-valuenow={progress}>
          <span style={{ width: `${Math.min(100, Math.max(0, progress))}%` }} />
        </div>
      )}
    </article>
  );
}

function BarList({ items, labelKey, valueKey, suffix = '', empty = 'No hay datos para este periodo.' }) {
  const max = Math.max(1, ...items.map((item) => Number(item[valueKey] ?? 0)));
  if (!items.length) return <EmptyState>{empty}</EmptyState>;
  return (
    <div className="bars">
      {items.map((item, index) => {
        const value = Number(item[valueKey] ?? 0);
        return (
          <div className="bar-row" key={`${item[labelKey]}`}>
            <div className="bar-label"><span>{item[labelKey]}</span><small>{suffix === '%' ? `${item.answered ?? 0}/${item.total ?? 0}` : `#${index + 1}`}</small></div>
            <div className="track"><i style={{ width: `${(value / max) * 100}%` }} /></div>
            <strong>{value}{suffix}</strong>
          </div>
        );
      })}
    </div>
  );
}

function HourChart({ items }) {
  const max = Math.max(1, ...items.map((item) => Number(item.calls ?? 0)));
  if (!items.length) return <EmptyState>No hay actividad por hora para mostrar.</EmptyState>;
  return (
    <div className="chart-frame">
      <div className="hour-chart" aria-label="Grafico de llamadas por hora">
        {items.map((item) => {
          const calls = Number(item.calls ?? 0);
          return (
            <div className="hour" key={item.hour} title={`${String(item.hour).padStart(2, '0')}:00 · ${calls} llamadas`}>
              <b>{calls > 0 ? calls : ''}</b>
              <span style={{ height: `${Math.max(2, (calls / max) * 100)}%` }} />
              <small>{item.hour % 3 === 0 ? `${String(item.hour).padStart(2, '0')}h` : ''}</small>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function DailyChart({ items }) {
  const max = Math.max(1, ...items.map((item) => Number(item.calls ?? 0)));
  if (!items.length) return <EmptyState>No hay actividad diaria para mostrar.</EmptyState>;
  const labelEvery = Math.max(1, Math.ceil(items.length / 9));
  return (
    <div className="daily-scroll">
      <div className="daily-chart" style={{ gridTemplateColumns: `repeat(${items.length}, minmax(24px, 1fr))` }} aria-label="Grafico de evolucion diaria">
        {items.map((item, index) => {
          const calls = Number(item.calls ?? 0);
          return (
            <div className="day-column" key={item.day} title={`${formatDay(item.day, { weekday: 'long', day: '2-digit', month: 'long' })} · ${calls} llamadas`}>
              <b>{calls}</b>
              <div><span style={{ height: `${Math.max(3, (calls / max) * 100)}%` }} /></div>
              <small>{index % labelEvery === 0 || index === items.length - 1 ? formatDay(item.day) : ''}</small>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function PanelHeading({ kicker, title, note }) {
  return (
    <div className="panel-heading">
      <div><span>{kicker}</span><h2>{title}</h2></div>
      {note && <p>{note}</p>}
    </div>
  );
}

function SystemStatusPanel({ status }) {
  const checks = status?.checks ?? [];
  return (
    <article className="panel span-12 system-panel">
      <PanelHeading kicker="DIAGNOSTICO" title="Estado de las fuentes y servicios" note={`API v${status?.version ?? '16'} · ${formatDateTime(status?.checkedAt)}`} />
      <div className="system-grid">
        {checks.map((check) => (
          <div className={`system-check ${String(check.status).toLowerCase()}`} key={check.id}>
            <span><i />{check.label}</span>
            <strong>{sourceStatusLabel(check.status)}</strong>
            <small>{check.detail ?? (check.total != null ? `${check.total} registros` : formatDateTime(check.updatedAt))}</small>
          </div>
        ))}
        {!checks.length && <EmptyState>Esperando la primera lectura de diagnostico.</EmptyState>}
      </div>
    </article>
  );
}

function TrendsPanel({ trends }) {
  const changes = trends?.changes ?? {};
  const items = [
    ['Volumen total', trends?.current?.total ?? 0, changes.total],
    ['Contestadas', trends?.current?.answered ?? 0, changes.answered],
    ['Tasa de respuesta', `${trends?.current?.answerRate ?? 0}%`, changes.answerRate],
    ['Duracion promedio', seconds(trends?.current?.avgDuration ?? 0), changes.avgDuration],
  ];
  return (
    <article className="panel span-12 trends-panel">
      <PanelHeading kicker="COMPARATIVO" title="Periodo anterior" note={trends?.previousRange ? `${formatDay(trends.previousRange.from)} — ${formatDay(trends.previousRange.to)}` : 'Sin comparacion'} />
      <div className="trend-grid">
        {items.map(([label, value, change]) => (
          <div key={label}>
            <span>{label}</span><strong>{value}</strong>
            <small className={Number(change) > 0 ? 'positive' : Number(change) < 0 ? 'negative' : ''}>{changeLabel(change, label === 'Tasa de respuesta' ? ' pp' : '%')}</small>
          </div>
        ))}
      </div>
      <div className="group-comparison">
        {(trends?.groups ?? []).map((group) => (
          <div key={group.groupName}><span>{group.groupName}</span><b>{group.answerRate}%</b><small>{changeLabel(group.answerRateChange, ' pp')}</small></div>
        ))}
      </div>
    </article>
  );
}

function RingGroupsPanel({ items = [] }) {
  if (!items.length) return <EmptyState>No hay datos de grupos para el periodo.</EmptyState>;
  return (
    <div className="ring-group-cards">
      {items.map((group) => (
        <article key={group.groupName}>
          <header><span>{group.groupName}</span><strong>{group.answerRate}%</strong></header>
          <div className="ring-progress"><i style={{ width: `${Math.min(100, Number(group.answerRate ?? 0))}%` }} /></div>
          <dl>
            <div><dt>Total</dt><dd>{group.total}</dd></div>
            <div><dt>Contestadas</dt><dd>{group.answered}</dd></div>
            <div><dt>Perdidas</dt><dd>{group.missed}</dd></div>
            <div><dt>Voicemail</dt><dd>{group.voicemail}</dd></div>
            <div><dt>Espera prom.</dt><dd>{seconds(group.avgWaitSeconds)}</dd></div>
            <div><dt>Conversacion</dt><dd>{seconds(group.avgTalkSeconds)}</dd></div>
          </dl>
        </article>
      ))}
    </div>
  );
}

function TrunkOperationsPanel({ peers, history, quality }) {
  const items = peers?.items ?? [];
  const summary = history?.summary ?? {};
  return (
    <article className="panel span-12 trunk-operations">
      <PanelHeading kicker="OBSERVABILIDAD IAX2" title="Peers, disponibilidad y calidad" note="Detecta troncales heredadas y cambios de IP" />
      <div className="trunk-summary-grid">
        <div><span>Disponibilidad</span><strong>{summary.uptimePercent == null ? '—' : `${summary.uptimePercent}%`}</strong><small>{summary.samples ?? 0} muestras</small></div>
        <div><span>Caidas</span><strong>{summary.outages ?? 0}</strong><small>Transiciones a DOWN</small></div>
        <div><span>Latencia IAX2</span><strong>{summary.averageLatencyMs == null ? '—' : `${summary.averageLatencyMs} ms`}</strong><small>Promedio del periodo</small></div>
        <div><span>Cambios de IP</span><strong>{summary.ipChanges ?? 0}</strong><small>{(summary.addresses ?? []).join(' → ') || 'Sin historial'}</small></div>
        <div><span>Calidad RTP</span><strong>{quality?.rtp?.available ? 'ACTIVA' : 'PENDIENTE'}</strong><small>{quality?.rtp?.detail ?? 'Sin lectura RTCP'}</small></div>
      </div>
      <div className="peer-table">
        <table>
          <thead><tr><th>Peer</th><th>Direccion</th><th>Estado</th><th>Latencia</th><th>Diagnostico</th></tr></thead>
          <tbody>{items.map((peer) => (
            <tr key={`${peer.name}-${peer.address}`}>
              <td><b>{peer.name}</b></td><td>{peer.address}</td>
              <td><span className={`badge ${peer.state === 'UP' ? 'answered' : 'failed'}`}>{peer.state}</span></td>
              <td>{peer.latencyMs == null ? '—' : `${peer.latencyMs} ms`}</td>
              <td>{peer.legacyName ? 'Nombre heredado; eliminar si esta duplicado' : peer.duplicateAddress ? 'Comparte IP con otro peer' : peer.expectedName ? 'Peer principal del dashboard' : 'Peer adicional'}</td>
            </tr>
          ))}</tbody>
        </table>
        {!items.length && <EmptyState>No se encontraron peers en el snapshot de Asterisk.</EmptyState>}
      </div>
    </article>
  );
}

function VoicemailPanel({ voicemail }) {
  const totals = voicemail?.totals ?? {};
  const messages = voicemail?.items ?? [];
  const statusLabel = (status) => ({ NEW: 'Nuevo', OLD: 'Escuchado', URGENT: 'Urgente' })[status] ?? status;
  return (
    <article className="panel span-12 voicemail-panel">
      <PanelHeading kicker="CORREO DE VOZ" title="Mensajes de Ventas y Soporte" note={`Solo lectura · ${formatDateTime(voicemail?.updatedAt)}`} />
      <div className="voicemail-summary" aria-label="Resumen de correo de voz">
        <div><span>Total</span><strong>{totals.total ?? 0}</strong><small>mensajes guardados</small></div>
        <div className="new"><span>Nuevos</span><strong>{totals.new ?? 0}</strong><small>pendientes de escuchar</small></div>
        <div className="urgent"><span>Urgentes</span><strong>{totals.urgent ?? 0}</strong><small>marcados en Issabel</small></div>
        <div><span>Reproducibles</span><strong>{totals.playable ?? 0}</strong><small>audio WAV o MP3</small></div>
      </div>
      <div className="voicemail-mailboxes">
        {(voicemail?.mailboxes ?? []).map((mailbox) => (
          <div key={mailbox.mailbox}>
            <span><b>{mailbox.label}</b><small>Extension {mailbox.mailbox}</small></span>
            <strong>{mailbox.new} nuevos</strong>
            <small>{mailbox.total} en total</small>
          </div>
        ))}
      </div>
      {voicemail?.status === 'unavailable' && <EmptyState>{voicemail.detail}</EmptyState>}
      {voicemail?.status !== 'unavailable' && !messages.length && <EmptyState>No hay mensajes de voz guardados en los buzones 2901 y 2902.</EmptyState>}
      {messages.length > 0 && (
        <div className="voicemail-list">
          {messages.map((message) => (
            <article key={message.id} className={message.urgent ? 'urgent' : ''}>
              <div className="voicemail-message-copy">
                <span className={`voicemail-badge ${String(message.status).toLowerCase()}`}>{statusLabel(message.status)}</span>
                <strong>{message.callerId || 'Llamante desconocido'}</strong>
                <small>{message.callerNumber || 'Numero no disponible'} · {message.mailboxLabel} ({message.mailbox})</small>
              </div>
              <div className="voicemail-time">
                <time dateTime={message.receivedAt}>{formatDateTime(message.receivedAt)}</time>
                <small>{seconds(message.durationSeconds)}</small>
              </div>
              <div className="voicemail-player">
                {message.audioAvailable
                  ? <audio controls preload="none" src={message.audioUrl} aria-label={`Reproducir mensaje de ${message.callerId || 'llamante desconocido'}`}>El navegador no puede reproducir este audio.</audio>
                  : <span>Audio no disponible en WAV/MP3</span>}
              </div>
            </article>
          ))}
        </div>
      )}
      <p className="voicemail-note">La bandeja es de solo lectura: reproducir aquí no borra, mueve ni marca el mensaje como escuchado en Issabel.</p>
    </article>
  );
}

function useAccessibleDialog(open, onClose) {
  const closeButton = useRef(null);
  const closeHandler = useRef(onClose);
  useEffect(() => { closeHandler.current = onClose; }, [onClose]);
  useEffect(() => {
    if (!open) return undefined;
    const previousFocus = document.activeElement;
    const previousOverflow = document.body.style.overflow;
    const handleKey = (event) => {
      if (event.key === 'Escape') closeHandler.current?.();
    };
    document.body.style.overflow = 'hidden';
    document.addEventListener('keydown', handleKey);
    closeButton.current?.focus();
    return () => {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener('keydown', handleKey);
      previousFocus?.focus?.();
    };
  }, [open]);
  return closeButton;
}

function EvidenceModal({ evidence, onClose, onPrint }) {
  const closeButton = useAccessibleDialog(Boolean(evidence), onClose);
  if (!evidence) return null;
  const securityValues = evidence.security?.values ?? {};
  return (
    <section className="evidence-modal" role="dialog" aria-modal="true" aria-labelledby="evidence-title" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <div className="evidence-sheet">
        <header><div><span>PROYECTO SIP-0620</span><h2 id="evidence-title">Evidencia del dashboard VoIP</h2><p>Corporacion Litoral · version {evidence.version}</p></div><button ref={closeButton} type="button" onClick={onClose} aria-label="Cerrar evidencia">×</button></header>
        <div className="evidence-meta"><span>Generado: {formatDateTime(evidence.generatedAt)}</span><span>Periodo: {evidence.range?.from} a {evidence.range?.to}</span><span>Fuente: Issabel / Asterisk / MariaDB</span></div>
        <div className="evidence-kpis"><div><span>Total</span><b>{evidence.summary?.total ?? 0}</b></div><div><span>Contestadas</span><b>{evidence.summary?.answerRate ?? 0}%</b></div><div><span>Promedio</span><b>{seconds(evidence.summary?.avgDuration ?? 0)}</b></div><div><span>IVR</span><b>{(evidence.ivr?.items ?? []).reduce((sum, item) => sum + Number(item.selections ?? 0), 0)}</b></div></div>
        <table><thead><tr><th>Criterio</th><th>Resultado</th><th>Estado</th></tr></thead><tbody>
          {(evidence.groups?.items ?? []).map((group) => <tr key={group.groupName}><td>Respuesta {group.groupName}</td><td>{group.answered}/{group.total} · {group.answerRate}%</td><td>DATOS REALES</td></tr>)}
          <tr><td>Troncal entre sedes</td><td>{evidence.trunk?.trunkName} · {evidence.trunk?.peerIp}</td><td>{evidence.trunk?.status}</td></tr>
          <tr><td>Llamadas en curso</td><td>{evidence.live?.total ?? 0}</td><td>{evidence.live?.status}</td></tr>
          <tr><td>Fail2ban</td><td>{securityValues.fail2ban_banned ?? 0} bloqueadas</td><td>{securityValues.fail2ban_asterisk ?? 'unknown'}</td></tr>
          <tr><td>Firewall</td><td>{securityValues.firewall_zone ?? 'sin zona'}</td><td>{securityValues.firewall ?? 'unknown'}</td></tr>
          <tr><td>SIP anonimo</td><td>Control de invitados</td><td>{securityValues.anonymous_sip ?? 'unknown'}</td></tr>
          <tr><td>Politica de contrasenas</td><td>Longitud minima {securityValues.password_min_length ?? 'sin lectura'}</td><td>{Number(securityValues.password_min_length) >= 12 ? 'OK' : 'REVISAR'}</td></tr>
          <tr><td>Acceso al dashboard</td><td>Autenticacion web</td><td>{securityValues.dashboard_auth ?? 'unknown'}</td></tr>
        </tbody></table>
        <p className="evidence-declaration">{evidence.declaration}</p>
        <footer><button type="button" onClick={onPrint}>Imprimir / guardar PDF</button><a href={`${API}/export/evidence.csv?${new URLSearchParams(evidence.range).toString()}`}>Descargar CSV</a></footer>
      </div>
    </section>
  );
}

function CallDetailModal({ detail, onClose }) {
  const closeButton = useAccessibleDialog(Boolean(detail), onClose);
  if (!detail) return null;
  return (
    <section className="call-detail-modal" role="dialog" aria-modal="true" aria-labelledby="call-detail-title" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <div><header><span><small id="call-detail-title">LINKEDID</small><strong>{detail.id}</strong></span><button ref={closeButton} type="button" onClick={onClose} aria-label="Cerrar detalle de llamada">×</button></header>
        <h3>Recorrido de la llamada</h3>
        <div className="legs">{(detail.legs ?? []).map((leg) => <article key={leg.uniqueid}><span>{formatDateTime(leg.calldate)}</span><b>{leg.src} → {leg.dst}</b><small>{leg.channel} · {leg.lastapp} · {leg.disposition} · {seconds(leg.billsec)}</small></article>)}</div>
        <h3>Eventos IVR relacionados</h3>
        <div className="ivr-events">{(detail.ivr ?? []).map((event, index) => <span key={`${event.eventTime}-${index}`}>{event.menuId} · {event.optionCode} · {event.optionLabel}</span>)}{!(detail.ivr ?? []).length && <small>Esta llamada no tiene eventos IVR correlacionados.</small>}</div>
      </div>
    </section>
  );
}

function LiveCallsPanel({ live, now, refreshing, onRefresh }) {
  const items = live?.items ?? [];
  const snapshotTime = live?.updatedAt ? new Date(live.updatedAt).getTime() : null;
  const elapsed = snapshotTime && live.status === 'ok'
    ? Math.max(0, Math.floor((now - snapshotTime) / 1000))
    : 0;
  const available = live?.status === 'ok';

  return (
    <article className="panel span-12 live-calls-panel">
      <div className="live-panel-header">
        <div>
          <span className="live-kicker"><i /> OPERACION EN VIVO</span>
          <h2>Llamadas en curso</h2>
          <p>Actividad actual de Asterisk, agrupada por conversacion</p>
        </div>
        <button type="button" onClick={onRefresh} disabled={refreshing}>
          {refreshing ? 'Comprobando…' : 'Actualizar ahora'}
        </button>
      </div>

      <div className="live-counters">
        <div><span>En curso</span><strong>{live?.total ?? 0}</strong></div>
        <div><span>Conectadas</span><strong>{live?.connected ?? 0}</strong></div>
        <div><span>Timbrando</span><strong>{live?.ringing ?? 0}</strong></div>
        <div><span>Entre sedes</span><strong>{live?.intersite ?? 0}</strong></div>
        <small>{live?.updatedAt ? `Lectura ${formatDateTime(live.updatedAt)}` : 'Esperando primera lectura'}</small>
      </div>

      {!available && (
        <div className="live-empty unavailable">
          <span>Monitor pendiente</span>
          <p>{live?.detail ?? 'Instala el monitor de canales activos para comenzar.'}</p>
        </div>
      )}

      {available && !items.length && (
        <div className="live-empty">
          <span className="calm-dot" />
          <strong>Sin llamadas activas</strong>
          <p>El monitor esta disponible y esperando la proxima llamada.</p>
        </div>
      )}

      {available && items.length > 0 && (
        <div className="live-call-grid">
          {items.map((call) => (
            <article className={`live-call ${String(call.status).toLowerCase()}`} key={call.id}>
              <div className="call-state">
                <span><i />{liveStatusLabel(call.status)}</span>
                <time>{seconds(Number(call.durationSeconds ?? 0) + elapsed)}</time>
              </div>
              <div className="call-participants">
                <div><small>Origen</small><strong>{call.from}</strong></div>
                <span aria-hidden="true">→</span>
                <div><small>Destino</small><strong>{call.to}</strong></div>
              </div>
              <div className="call-meta">
                <span>{liveDirectionLabel(call.direction)}</span>
                <span>{call.department ?? 'Otros'}</span>
                <span>{(call.technologies ?? []).join(' + ') || 'Asterisk'}</span>
                <span>{call.channelCount} canales</span>
              </div>
              {call.waitAlert && <div className="call-alert">Lleva mas de 20 segundos timbrando</div>}
              <div className="call-signal"><span /></div>
            </article>
          ))}
        </div>
      )}
    </article>
  );
}

export default function Dashboard() {
  const defaults = useMemo(() => rangeForDays(7), []);
  const [range, setRange] = useState(defaults);
  const [appliedRange, setAppliedRange] = useState(defaults);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [notice, setNotice] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [checkingTrunk, setCheckingTrunk] = useState(false);
  const [liveCalls, setLiveCalls] = useState({ status: 'loading', total: 0, connected: 0, ringing: 0, intersite: 0, items: [] });
  const [checkingCalls, setCheckingCalls] = useState(false);
  const [clock, setClock] = useState(() => Date.now());
  const [callSearch, setCallSearch] = useState('');
  const [callStatus, setCallStatus] = useState('ALL');
  const [callDepartment, setCallDepartment] = useState('ALL');
  const [callDirection, setCallDirection] = useState('ALL');
  const [minDuration, setMinDuration] = useState('');
  const [callPage, setCallPage] = useState(0);
  const [evidence, setEvidence] = useState(null);
  const [loadingEvidence, setLoadingEvidence] = useState(false);
  const [callDetail, setCallDetail] = useState(null);

  const load = useCallback(async (targetRange) => {
    setLoading(true);
    setNotice(null);
    const query = new URLSearchParams(targetRange).toString();

    try {
      const results = await Promise.allSettled(ENDPOINTS.map(async (name) => {
        const url = `${API}/${name}${UNRANGED_ENDPOINTS.has(name) ? '' : `?${query}`}`;
        const response = await fetch(url, { cache: 'no-store' });
        const payload = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(payload.error ?? `Error ${response.status}`);
        return [name, payload];
      }));

      const successful = results.filter((result) => result.status === 'fulfilled').map((result) => result.value);
      const failed = results.filter((result) => result.status === 'rejected');
      const failedNames = results.flatMap((result, index) => result.status === 'rejected' ? [ENDPOINTS[index]] : []);
      const health = successful.find(([name]) => name === 'health')?.[1];

      if (successful.length) {
        setData((current) => ({ ...(current ?? {}), ...Object.fromEntries(successful) }));
        setLastUpdated(new Date());
      }

      if (failedNames.includes('health')) {
        setData((current) => ({
          ...(current ?? {}),
          health: { status: 'degraded', database: false },
        }));
      }

      if (failed.length === ENDPOINTS.length) {
        throw new Error(failed[0]?.reason?.message ?? 'No fue posible consultar Issabel.');
      }
      if (failed.length) {
        setNotice({ type: 'warning', text: `No se actualizaron: ${failedNames.join(', ')}. Los demas datos siguen disponibles.` });
      } else if (health && (health.status !== 'ok' || health.database !== true)) {
        setNotice({ type: 'warning', text: 'La interfaz responde, pero MariaDB de Issabel no esta disponible.' });
      }
    } catch (reason) {
      setNotice({ type: 'error', text: reason.message ?? 'No fue posible consultar Issabel.' });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(appliedRange); }, [appliedRange, load]);

  useEffect(() => {
    if (!autoRefresh) return undefined;
    const timer = window.setInterval(() => load(appliedRange), 60000);
    return () => window.clearInterval(timer);
  }, [appliedRange, autoRefresh, load]);

  const refreshTrunk = useCallback(async () => {
    setCheckingTrunk(true);
    try {
      const response = await fetch(`${API}/trunk`, { cache: 'no-store' });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(payload.error ?? `Error ${response.status}`);
      setData((current) => ({ ...(current ?? {}), trunk: payload }));
    } catch (reason) {
      setNotice({ type: 'warning', text: reason.message ?? 'No se pudo comprobar la troncal.' });
    } finally {
      setCheckingTrunk(false);
    }
  }, []);

  useEffect(() => {
    if (!autoRefresh) return undefined;
    const timer = window.setInterval(refreshTrunk, 15000);
    return () => window.clearInterval(timer);
  }, [autoRefresh, refreshTrunk]);

  const refreshLiveCalls = useCallback(async () => {
    setCheckingCalls(true);
    try {
      const response = await fetch(`${API}/live-calls`, { cache: 'no-store' });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(payload.error ?? `Error ${response.status}`);
      setLiveCalls(payload);
    } catch (reason) {
      setLiveCalls((current) => ({
        ...current,
        status: 'unavailable',
        detail: reason.message ?? 'No se pudo consultar las llamadas activas.',
      }));
    } finally {
      setCheckingCalls(false);
    }
  }, []);

  const openEvidence = useCallback(async () => {
    setLoadingEvidence(true);
    try {
      const response = await fetch(`${API}/evidence?${queryString(appliedRange)}`, { cache: 'no-store' });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(payload.error ?? `Error ${response.status}`);
      setEvidence(payload);
    } catch (reason) {
      setNotice({ type: 'error', text: reason.message ?? 'No fue posible generar la evidencia.' });
    } finally {
      setLoadingEvidence(false);
    }
  }, [appliedRange]);

  const openCallDetails = useCallback(async (id) => {
    try {
      const response = await fetch(`${API}/calls/${encodeURIComponent(id)}`, { cache: 'no-store' });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(payload.error ?? `Error ${response.status}`);
      setCallDetail(payload);
    } catch (reason) {
      setNotice({ type: 'warning', text: reason.message ?? 'No se pudo abrir el detalle de la llamada.' });
    }
  }, []);

  useEffect(() => { refreshLiveCalls(); }, [refreshLiveCalls]);

  useEffect(() => {
    if (!autoRefresh) return undefined;
    const timer = window.setInterval(refreshLiveCalls, 3000);
    return () => window.clearInterval(timer);
  }, [autoRefresh, refreshLiveCalls]);

  useEffect(() => {
    const timer = window.setInterval(() => setClock(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  const applyRange = () => {
    const validation = validateRange(range);
    if (validation) {
      setNotice({ type: 'error', text: validation });
      return;
    }
    if (range.from === appliedRange.from && range.to === appliedRange.to) load(range);
    else setAppliedRange({ ...range });
  };

  const applyPreset = (days) => {
    const next = rangeForDays(days);
    setRange(next);
    setAppliedRange(next);
  };

  const summary = data?.summary ?? {};
  const total = Number(summary.total ?? 0);
  const answered = Number(summary.answered ?? 0);
  const missed = Math.max(0, total - answered);
  const answerRate = Number(summary.answerRate ?? 0);
  const hourly = data?.hourly?.items ?? [];
  const daily = data?.daily?.items ?? [];
  const peakHour = hourly.reduce((best, item) => Number(item.calls) > Number(best?.calls ?? -1) ? item : best, null);
  const peakDay = daily.reduce((best, item) => Number(item.calls) > Number(best?.calls ?? -1) ? item : best, null);
  const ivrTotal = (data?.ivr?.items ?? []).reduce((sum, item) => sum + Number(item.selections ?? 0), 0);
  const trunk = data?.trunk ?? { status: 'UNKNOWN' };
  const statusClass = trunk.status === 'UP' ? 'up' : trunk.status === 'DOWN' ? 'down' : 'unknown';
  const hasData = Boolean(data?.summary);
  const databaseLive = data?.health?.status === 'ok' && data?.health?.database === true;
  const connectionLabel = !data ? 'Conectando' : databaseLive ? 'Datos en vivo' : 'BD sin conexion';

  const recentCalls = useMemo(() => {
    const search = callSearch.trim().toLowerCase();
    return (data?.calls?.items ?? []).filter((call) => {
      const matchesStatus = callStatus === 'ALL' || call.disposition === callStatus;
      const matchesDepartment = callDepartment === 'ALL' || call.department === callDepartment;
      const matchesDirection = callDirection === 'ALL' || call.direction === callDirection;
      const matchesDuration = !minDuration || Number(call.billsec ?? 0) >= Number(minDuration);
      const matchesSearch = !search || `${call.src} ${call.dst} ${call.department} ${call.id}`.toLowerCase().includes(search);
      return matchesStatus && matchesDepartment && matchesDirection && matchesDuration && matchesSearch;
    });
  }, [callDepartment, callDirection, callSearch, callStatus, data, minDuration]);

  const callPageCount = Math.max(1, Math.ceil(recentCalls.length / CALLS_PAGE_SIZE));
  const visibleCalls = recentCalls.slice(callPage * CALLS_PAGE_SIZE, (callPage + 1) * CALLS_PAGE_SIZE);
  useEffect(() => { setCallPage(0); }, [callDepartment, callDirection, callSearch, callStatus, minDuration, appliedRange]);
  useEffect(() => {
    if (callPage >= callPageCount) setCallPage(callPageCount - 1);
  }, [callPage, callPageCount]);

  const exportFilters = { search: callSearch, status: callStatus, department: callDepartment, direction: callDirection, minDuration };

  return (
    <main className="dashboard-shell">
      <nav className="topbar" aria-label="Cabecera del sistema">
        <div className="brand-mark" aria-hidden="true"><span /><span /><span /><span /></div>
        <div className="brand-copy"><strong>Corporacion Litoral</strong><span>Telefonia empresarial</span></div>
        <div className="topbar-meta">
          <span className={`active-call-chip ${liveCalls.total ? 'busy' : ''}`}><i />{liveCalls.total ?? 0} en curso</span>
          <span className={`live-chip ${data && !databaseLive ? 'offline' : ''}`}><i />{connectionLabel}</span>
          <span className="server-label">Issabel PBX · {trunk.localIp ?? 'detectando IP'}</span>
        </div>
      </nav>

      <header className="hero">
        <div>
          <p className="eyebrow">PANEL DE CONTROL OPERATIVO</p>
          <h1>Centro de llamadas</h1>
          <p className="subtitle">Rendimiento, demanda y trazabilidad de la operacion telefonica.</p>
        </div>
        <aside className={`trunk-card ${statusClass}`} aria-label={`Estado de troncal: ${trunkStatusLabel(trunk.status)}`}>
          <div className="trunk-heading"><span className="status-dot" /><small>ENLACE ENTRE SEDES</small></div>
          <div className="trunk-value"><strong>{trunkStatusLabel(trunk.status)}</strong><em>{trunk.latencyMs != null ? `${trunk.latencyMs} ms` : 'IAX2'}</em></div>
          <p>{trunk.detail ?? (trunk.status === 'UP' ? 'Troncal Bodega disponible' : trunk.status === 'DOWN' ? 'Troncal Bodega sin respuesta' : 'Comprobacion pendiente')}</p>
          <div className="trunk-footer">
            <time>{formatDateTime(trunk.checkedAt)}</time>
            <button type="button" onClick={refreshTrunk} disabled={checkingTrunk}>{checkingTrunk ? 'Comprobando…' : 'Comprobar ahora'}</button>
          </div>
        </aside>
      </header>

      <section className="control-center" aria-label="Filtros de consulta">
        <div className="presets" aria-label="Rangos rapidos">
          {PRESETS.map((preset) => {
            const active = rangeLength(appliedRange) === preset.days;
            return <button type="button" className={active ? 'active' : ''} key={preset.days} onClick={() => applyPreset(preset.days)}>{preset.label}</button>;
          })}
        </div>
        <div className="date-fields">
          <label><span>Desde</span><input type="date" value={range.from} max={range.to} onChange={(event) => setRange({ ...range, from: event.target.value })} /></label>
          <label><span>Hasta</span><input type="date" value={range.to} min={range.from} max={isoDate(new Date())} onChange={(event) => setRange({ ...range, to: event.target.value })} /></label>
          <button type="button" className="primary-button" onClick={applyRange} disabled={loading}><span className={loading ? 'spinner' : ''} />{loading ? 'Consultando' : 'Aplicar periodo'}</button>
        </div>
        <label className="auto-refresh">
          <input type="checkbox" checked={autoRefresh} onChange={(event) => setAutoRefresh(event.target.checked)} />
          <span aria-hidden="true" /> Actualizar cada 60 s
        </label>
      </section>

      <div className="context-strip">
        <p><b>{formatDay(appliedRange.from, { day: '2-digit', month: 'long' })}</b> — <b>{formatDay(appliedRange.to, { day: '2-digit', month: 'long', year: 'numeric' })}</b><span>{rangeLength(appliedRange)} dias analizados</span></p>
        <p>Ultima sincronizacion <b>{lastUpdated ? lastUpdated.toLocaleTimeString('es-HN', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : 'pendiente'}</b></p>
      </div>

      <section className="report-actions" aria-label="Exportacion y evidencias">
        <div><span>REPORTE Y EVIDENCIAS</span><p>Todos los archivos se generan con datos reales del periodo seleccionado.</p></div>
        <button type="button" onClick={openEvidence} disabled={loadingEvidence}>{loadingEvidence ? 'Preparando…' : 'Generar evidencia'}</button>
        <a href={`${API}/export/calls.csv?${queryString(appliedRange, exportFilters)}`}>Exportar llamadas CSV</a>
        <a href={`${API}/export/ivr.csv?${queryString(appliedRange)}`}>Exportar IVR CSV</a>
      </section>

      {notice && <div className={`notice ${notice.type}`} role="alert"><i>{notice.type === 'warning' ? '!' : '×'}</i><div><strong>{notice.type === 'warning' ? 'Actualizacion parcial' : 'No se pudo completar la consulta'}</strong><span>{notice.text}</span></div><button type="button" aria-label="Cerrar aviso" onClick={() => setNotice(null)}>×</button></div>}

      <section className="metrics" aria-label="Indicadores principales">
        <MetricCard label="Total de llamadas" value={hasData ? total.toLocaleString('es-HN') : '—'} detail={`${rangeLength(appliedRange)} dias del periodo`} tone="blue" />
        <MetricCard label="Contestadas" value={hasData ? `${answerRate}%` : '—'} detail={hasData ? `${answered} llamadas atendidas` : 'Esperando datos'} tone="green" progress={hasData ? answerRate : 0} />
        <MetricCard label="No contestadas" value={hasData ? missed.toLocaleString('es-HN') : '—'} detail={hasData && total ? `${Math.round((missed / total) * 100)}% del volumen` : 'Sin llamadas perdidas'} tone={missed ? 'orange' : 'green'} />
        <MetricCard label="Duracion promedio" value={hasData ? seconds(summary.avgDuration) : '—'} detail="Solo llamadas contestadas" tone="purple" />
      </section>

      <section className="insights" aria-label="Resumen del periodo">
        <article><span>Hora de mayor demanda</span><strong>{peakHour && Number(peakHour.calls) > 0 ? `${String(peakHour.hour).padStart(2, '0')}:00` : '—'}</strong><small>{peakHour ? `${peakHour.calls} llamadas` : 'Sin actividad'}</small></article>
        <article><span>Dia con mayor volumen</span><strong>{peakDay ? formatDay(peakDay.day, { day: '2-digit', month: 'short' }) : '—'}</strong><small>{peakDay ? `${peakDay.calls} llamadas` : 'Sin actividad'}</small></article>
        <article><span>Interacciones con IVR</span><strong>{ivrTotal}</strong><small>{ivrTotal ? 'Opciones seleccionadas' : 'Registro pendiente'}</small></article>
        <article><span>Calidad de respuesta</span><strong>{!hasData ? '—' : answerRate >= 80 ? 'Alta' : answerRate >= 60 ? 'Media' : 'Baja'}</strong><small>{hasData ? `${answerRate}% de efectividad` : 'Esperando datos'}</small></article>
      </section>

      <section className="analytics-grid">
        <LiveCallsPanel live={liveCalls} now={clock} refreshing={checkingCalls} onRefresh={refreshLiveCalls} />

        <SystemStatusPanel status={data?.['system-status']} />
        <TrendsPanel trends={data?.trends} />

        <article className={`panel span-12 link-panel ${statusClass}`}>
          <PanelHeading kicker="CONECTIVIDAD IAX2" title="Estado del enlace entre sedes" note="Comprobacion automatica cada 15 segundos" />
          <div className="link-topology">
            <div className="pbx-node local">
              <span>SEDE PRINCIPAL</span>
              <strong>Issabel PBX</strong>
              <small>{trunk.localIp ?? 'Detectando direccion'}</small>
              <i>IP detectada</i>
            </div>
            <div className="link-path">
              <div className="path-label"><b>{trunk.protocol ?? 'IAX2'}</b><span>UDP {trunk.port ?? 4569}</span></div>
              <div className="path-line"><span /><i /></div>
              <small>{networkModeLabel(trunk)}</small>
            </div>
            <div className={`pbx-node remote ${statusClass}`}>
              <span>BODEGA</span>
              <strong>{trunk.trunkName ?? 'BODEGA-IAX'}</strong>
              <small>{trunk.peerIp ?? 'Detectando direccion'}</small>
              <i>{trunkStatusLabel(trunk.status)}</i>
            </div>
          </div>
          <div className="link-diagnostics">
            <div><span>Estado técnico</span><strong>{trunk.status ?? 'UNKNOWN'}</strong></div>
            <div><span>Origen de lectura</span><strong>{trunkSourceLabel(trunk.source)}</strong></div>
            <div><span>Última comprobación</span><strong>{formatDateTime(trunk.checkedAt)}</strong></div>
            <div className="diagnostic-action"><span>Diagnóstico</span><strong>{trunk.recommendation ?? 'Esperando la primera comprobación de la troncal.'}</strong></div>
          </div>
        </article>

        <TrunkOperationsPanel peers={data?.trunks} history={data?.['trunk-history']} quality={data?.quality} />

        <article className="panel span-8">
          <PanelHeading kicker="VOLUMEN" title="Llamadas por hora" note="Distribucion acumulada del periodo" />
          <HourChart items={hourly} />
        </article>

        <article className="panel span-4 peak-panel">
          <PanelHeading kicker="LECTURA RAPIDA" title="Actividad principal" />
          <div className="peak-clock"><span>{peakHour && Number(peakHour.calls) > 0 ? String(peakHour.hour).padStart(2, '0') : '—'}</span><small>{peakHour && Number(peakHour.calls) > 0 ? '00 horas' : 'sin actividad'}</small></div>
          <p>La mayor concentracion del periodo fue de <b>{peakHour?.calls ?? 0} llamadas</b>. Utiliza este dato para organizar la disponibilidad del personal.</p>
        </article>

        <article className="panel span-12 daily-panel">
          <PanelHeading kicker="TENDENCIA" title="Evolucion diaria" note={`${daily.length} dias con registros`} />
          <DailyChart items={daily} />
        </article>

        <article className="panel span-5">
          <PanelHeading kicker="DEPARTAMENTOS" title="Distribucion de demanda" note="Llamadas por destino" />
          <BarList items={data?.departments?.items ?? []} labelKey="department" valueKey="calls" />
        </article>

        <article className="panel span-4">
          <PanelHeading kicker="GRUPOS DE TIMBRADO" title="Tasa de respuesta" note="Ventas y soporte" />
          <RingGroupsPanel items={data?.['ring-groups']?.items ?? []} />
        </article>

        <article className="panel span-3">
          <PanelHeading kicker="AUTOSERVICIO" title="Uso del IVR" note={`${ivrTotal} selecciones`} />
          <BarList items={data?.ivr?.items ?? []} labelKey="optionLabel" valueKey="selections" empty="El registro del IVR aun no tiene eventos." />
        </article>

        <article className="panel span-12 recent-panel">
          <PanelHeading kicker="TRAZABILIDAD" title="Explorador de llamadas" note={`${data?.calls?.total ?? 0} llamadas disponibles en el periodo`} />
          <div className="table-controls">
            <label className="search-field"><span aria-hidden="true">⌕</span><input type="search" placeholder="Buscar origen o destino" value={callSearch} onChange={(event) => setCallSearch(event.target.value)} /></label>
            <select aria-label="Filtrar por estado" value={callStatus} onChange={(event) => setCallStatus(event.target.value)}>
              <option value="ALL">Todos los estados</option>
              <option value="ANSWERED">Contestadas</option>
              <option value="NO ANSWER">No contestadas</option>
              <option value="BUSY">Ocupadas</option>
              <option value="FAILED">Fallidas</option>
            </select>
            <select aria-label="Filtrar por departamento" value={callDepartment} onChange={(event) => setCallDepartment(event.target.value)}>
              <option value="ALL">Todos los departamentos</option>
              {(data?.departments?.items ?? []).map((item) => <option value={item.department} key={item.department}>{item.department}</option>)}
            </select>
            <select aria-label="Filtrar por direccion" value={callDirection} onChange={(event) => setCallDirection(event.target.value)}>
              <option value="ALL">Todas las direcciones</option>
              <option value="INTERNA">Internas</option>
              <option value="PRINCIPAL_A_BODEGA">Principal a bodega</option>
              <option value="BODEGA_A_PRINCIPAL">Bodega a principal</option>
              <option value="ENTRE_SEDES">Entre sedes</option>
            </select>
            <label className="duration-filter"><span>Min. segundos</span><input type="number" min="0" max="86400" value={minDuration} onChange={(event) => setMinDuration(event.target.value)} /></label>
            <span className="result-count">{recentCalls.length} resultados · pagina {callPage + 1}/{callPageCount}</span>
          </div>
          <div className="table-wrap">
            <table>
              <thead><tr><th>Fecha y hora</th><th>Origen</th><th>Destino</th><th>Departamento</th><th>Estado</th><th>Conversacion</th><th>Tecnologia</th><th /></tr></thead>
              <tbody>
                {visibleCalls.map((call) => (
                  <tr key={call.id}>
                    <td><b>{formatDay(String(call.calldate).slice(0, 10), { day: '2-digit', month: 'short' })}</b><small>{new Date(call.calldate).toLocaleTimeString('es-HN', { hour: '2-digit', minute: '2-digit' })}</small></td>
                    <td><span className="extension">{call.src || '—'}</span></td>
                    <td><span className="extension">{call.dst || '—'}</span></td>
                    <td><b>{call.department}</b><small>{liveDirectionLabel(call.direction)}</small></td>
                    <td><span className={`badge ${String(call.disposition).toLowerCase().replaceAll(' ', '-')}`}>{dispositionLabel(call.disposition)}</span></td>
                    <td>{seconds(call.billsec)}</td>
                    <td>{(call.technologies ?? []).join(' + ') || 'Asterisk'}{call.voicemail && <small>Voicemail</small>}</td>
                    <td><button type="button" className="detail-button" onClick={() => openCallDetails(call.id)}>Ver detalle</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
            {!recentCalls.length && <EmptyState>No hay llamadas que coincidan con el filtro.</EmptyState>}
          </div>
          {recentCalls.length > CALLS_PAGE_SIZE && <div className="table-pagination" aria-label="Paginacion de llamadas"><button type="button" onClick={() => setCallPage((page) => Math.max(0, page - 1))} disabled={callPage === 0}>Anterior</button><span>Mostrando {callPage * CALLS_PAGE_SIZE + 1}–{Math.min((callPage + 1) * CALLS_PAGE_SIZE, recentCalls.length)} de {recentCalls.length}</span><button type="button" onClick={() => setCallPage((page) => Math.min(callPageCount - 1, page + 1))} disabled={callPage + 1 >= callPageCount}>Siguiente</button></div>}
        </article>

        <VoicemailPanel voicemail={data?.voicemail} />
      </section>

      <EvidenceModal evidence={evidence} onClose={() => setEvidence(null)} onPrint={() => window.print()} />
      <CallDetailModal detail={callDetail} onClose={() => setCallDetail(null)} />

      <footer><span>Corporacion Litoral · Reporteria VoIP</span><span>Fuente: asteriskcdrdb · Zona horaria America/Tegucigalpa</span></footer>
    </main>
  );
}
