import './globals.css';

export const metadata = {
  title: 'Centro de llamadas v14 | Corporacion Litoral',
  description: 'Observabilidad, seguridad, evidencias y trazabilidad de Issabel PBX',
};

export default function RootLayout({ children }) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
