# API Express

La API consulta directamente `asteriskcdrdb.cdr`, `ivr_events` y `trunk_status`. No incluye un modo de datos simulados. Los indicadores CDR agrupan por `linkedid` con fallback a `uniqueid`, porque una llamada puede producir varias piernas y varios registros.

## Endpoints

- `GET /api/health`
- `GET /api/summary?from=YYYY-MM-DD&to=YYYY-MM-DD`
- `GET /api/departments`
- `GET /api/ring-groups`
- `GET /api/hourly`
- `GET /api/daily`
- `GET /api/ivr`
- `GET /api/trunk`
- `GET /api/live-calls`
- `GET /api/calls`
- `GET /api/voicemail`
- `GET /api/voicemail/audio/:context/:mailbox/:folder/:message`

El rango maximo es de 93 dias. Las consultas usan parametros y el conector tiene `multipleStatements` y `permitLocalInfile` desactivados.

`GET /api/trunk` consulta primero `iax2 show peer BODEGA-IAX` en el Asterisk
local. Si la API no puede acceder al socket, usa la lectura mas reciente de
`trunk_status`; una lectura con mas de 150 segundos se marca como vencida y no
se presenta como un enlace operativo.

`GET /api/live-calls` lee una instantanea de `core show channels concise`,
agrupa los canales conectados por el identificador del puente para mostrar una
conversacion en lugar de cada pierna y
distingue llamadas conectadas, timbrando o marcando. El servicio
`voip-live-monitor.service` renueva la instantanea cada dos segundos.

`GET /api/voicemail` lee de forma segura los metadatos de los buzones 2901 y
2902. La ruta de audio solo acepta contextos, buzones y carpetas configurados;
sirve WAV/MP3 en linea y no permite borrar ni mover mensajes.

## Puesta en marcha

```bash
cp .env.example .env
# editar .env
npm install
npm run check
npm start
curl http://127.0.0.1:4000/api/health
```

En produccion, mantenga el proceso en `127.0.0.1` y publiquelo unicamente a traves de Nginx/HTTPS.

Para permitir la comprobacion en vivo sin ejecutar Node como `root`, el servicio
debe conservar `User=dashboard` y agregar `SupplementaryGroups=asterisk`. El
script siguiente crea un drop-in de systemd y reinicia solamente la API:

```bash
chmod +x /opt/corporacion-litoral-v16/scripts/activate_live_trunk_monitor.sh
/opt/corporacion-litoral-v16/scripts/activate_live_trunk_monitor.sh
```
