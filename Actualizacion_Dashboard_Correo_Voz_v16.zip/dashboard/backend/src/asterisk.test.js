import assert from 'node:assert/strict';
import test from 'node:test';
import { parseAllIaxPeersOutput, parseIaxPeerOutput, parseIaxPeersOutput, selectLocalIp } from './asterisk.js';

test('detecta un peer IAX2 disponible y obtiene su latencia', () => {
  const result = parseIaxPeerOutput(`
  * Name       : BODEGA-IAX
  Addr->IP     : 192.168.0.10 Port 4569
  Status       : OK (12 ms)
  `, { peerIp: '192.168.0.10' });

  assert.equal(result.status, 'UP');
  assert.equal(result.peerIp, '192.168.0.10');
  assert.equal(result.latencyMs, 12);
  assert.equal(result.configured, true);
});

test('detecta un peer configurado pero sin respuesta', () => {
  const result = parseIaxPeerOutput(`
  * Name       : BODEGA-IAX
  Addr->IP     : 192.168.0.10 Port 4569
  Status       : UNREACHABLE
  `);

  assert.equal(result.status, 'DOWN');
  assert.equal(result.reachable, false);
  assert.equal(result.configured, true);
});

test('distingue un peer inexistente de una troncal caida', () => {
  const result = parseIaxPeerOutput('Unable to find peer BODEGA-IAX.');

  assert.equal(result.status, 'UNKNOWN');
  assert.equal(result.configured, false);
});

test('selecciona la IP de la interfaz preferida cuando la red cambia', () => {
  const interfaces = {
    eth0: [{ family: 'IPv4', internal: false, address: '192.168.50.20' }],
    tailscale0: [{ family: 'IPv4', internal: false, address: '100.80.10.2' }],
  };

  assert.equal(selectLocalIp(interfaces, 'tailscale0'), '100.80.10.2');
  assert.equal(selectLocalIp(interfaces), '192.168.50.20');
});

test('no oculta la caida del peer esperado con una troncal heredada', () => {
  const result = parseIaxPeersOutput(`
Name/Username    Host                                           Mask                                      Port           Status
BODEGA-IAX/BODE  192.168.0.10                             (S)  255.255.255.255                           4569  (T)      UNREACHABLE
IAX2-trunk2/IAX  192.168.0.10                             (S)  255.255.255.255                           4569  (T)      OK (3 ms)
2 iax2 peers [1 online, 1 offline, 0 unmonitored]
  `, { peerIp: '192.168.0.10' });

  assert.equal(result.status, 'DOWN');
  assert.equal(result.reachable, false);
  assert.match(result.detail, /BODEGA-IAX/);
});

test('sigue por nombre la nueva IP que Asterisk informa despues de cambiar DHCP', () => {
  const result = parseIaxPeersOutput(`
BODEGA-IAX/BODE  10.11.9.31  (S) 255.255.255.255 4569 (T) OK (4 ms)
1 iax2 peers [1 online, 0 offline, 0 unmonitored]
  `, { trunkName: 'BODEGA-IAX', peerIp: 'auto' });

  assert.equal(result.status, 'UP');
  assert.equal(result.peerIp, '10.11.9.31');
  assert.equal(result.latencyMs, 4);
});

test('enumera peers y marca troncales heredadas o duplicadas', () => {
  const peers = parseAllIaxPeersOutput(`
BODEGA-IAX/BODE  10.11.9.31  (S) 255.255.255.255 4569 (T) OK (2 ms)
IAX2-trunk2/IAX  10.11.9.31  (S) 255.255.255.255 4569 (T) UNREACHABLE
`, { trunkName: 'BODEGA-IAX', peerIp: '10.11.9.31' });
  assert.equal(peers.length, 2);
  assert.equal(peers[0].expectedName, true);
  assert.equal(peers[0].duplicateAddress, true);
  assert.equal(peers[1].legacyName, true);
});
