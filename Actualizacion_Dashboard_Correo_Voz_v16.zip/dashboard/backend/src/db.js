import mariadb from 'mariadb';

const pool = mariadb.createPool({
  host: process.env.DB_HOST ?? '127.0.0.1',
  port: Number(process.env.DB_PORT ?? 3306),
  database: process.env.DB_NAME ?? 'asteriskcdrdb',
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  connectionLimit: Number(process.env.DB_CONNECTION_LIMIT ?? 5),
  connectTimeout: 3000,
  socketTimeout: 5000,
  bigIntAsNumber: true,
  decimalAsNumber: true,
  multipleStatements: false,
  permitLocalInfile: false,
  timezone: 'local',
});

export async function query(sql, values = []) {
  return pool.query(sql, values);
}

export async function checkDatabase() {
  const rows = await pool.query('SELECT 1 AS ok');
  return rows[0]?.ok === 1;
}

export async function closeDatabase() {
  await pool.end();
}
