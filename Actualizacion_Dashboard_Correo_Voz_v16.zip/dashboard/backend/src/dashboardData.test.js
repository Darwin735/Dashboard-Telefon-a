import assert from 'node:assert/strict';
import test from 'node:test';
import { completeDepartmentRows } from './dashboardData.js';

test('muestra todos los departamentos aunque alguno no tenga llamadas', () => {
  const items = completeDepartmentRows([{ department: 'Ventas', calls: 7 }]);
  const byName = new Map(items.map((item) => [item.department, item.calls]));

  assert.equal(byName.get('Ventas'), 7);
  assert.equal(byName.get('Soporte'), 0);
  assert.equal(byName.get('Finanzas'), 0);
  assert.equal(byName.get('Bodega remota'), 0);
});

test('normaliza los conteos devueltos por MariaDB', () => {
  const items = completeDepartmentRows([
    { department: 'Recepcion', calls: '3' },
    { department: 'Otro destino', calls: '2' },
  ]);
  const byName = new Map(items.map((item) => [item.department, item.calls]));

  assert.equal(byName.get('Recepcion'), 3);
  assert.equal(byName.get('Otro destino'), 2);
});
