import assert from 'node:assert/strict';
import test from 'node:test';
import { parseRange, previousRangeFor } from './range.js';

test('convierte un periodo valido a limites completos de MariaDB', () => {
  const range = parseRange({ from: '2026-07-01', to: '2026-07-22' });
  assert.deepEqual(range, {
    from: '2026-07-01',
    to: '2026-07-22',
    sqlFrom: '2026-07-01 00:00:00',
    sqlTo: '2026-07-22 23:59:59',
  });
});

test('acepta consultar un solo dia', () => {
  const range = parseRange({ from: '2026-07-28', to: '2026-07-28' });
  assert.equal(range.sqlFrom, '2026-07-28 00:00:00');
  assert.equal(range.sqlTo, '2026-07-28 23:59:59');
});

test('rechaza fechas mal formadas', () => {
  assert.throws(
    () => parseRange({ from: '28/07/2026', to: '2026-07-28' }),
    /formato YYYY-MM-DD/,
  );
});

test('rechaza un periodo invertido o mayor de 93 dias', () => {
  assert.throws(
    () => parseRange({ from: '2026-07-29', to: '2026-07-28' }),
    /rango debe estar/,
  );
  assert.throws(
    () => parseRange({ from: '2026-01-01', to: '2026-07-28' }),
    /rango debe estar/,
  );
});

test('calcula el periodo anterior con la misma cantidad de dias', () => {
  const previous = previousRangeFor(parseRange({ from: '2026-08-02', to: '2026-08-08' }));
  assert.equal(previous.from, '2026-07-26');
  assert.equal(previous.to, '2026-08-01');
});
