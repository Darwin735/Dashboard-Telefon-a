const SAFE_VALUE = /^[A-Za-z0-9_.:@/+ -]{0,120}$/;

export function departmentForNumber(value) {
  const number = String(value ?? '').trim();
  if (number === '2000') return 'Recepcion';
  if (/^200[1-4]$/.test(number) || number === '6100' || number === '2901') return 'Ventas';
  if (/^200[5-7]$/.test(number) || number === '6200' || number === '2902') return 'Soporte';
  if (/^200[89]$/.test(number) || number === '6300') return 'Finanzas';
  if (number === '2010') return 'Gerencia';
  if (/^201[12]$/.test(number) || number === '6400') return 'Logistica';
  if (/^3\d{3}$/.test(number)) return 'Bodega remota';
  return 'Otros';
}

export function directionForCall(source, destination, technologies = []) {
  const from = String(source ?? '');
  const to = String(destination ?? '');
  const usesIax = technologies.includes('IAX2');
  if (/^2\d{3}$/.test(from) && /^3\d{3}$/.test(to)) return 'PRINCIPAL_A_BODEGA';
  if (/^3\d{3}$/.test(from) && /^2\d{3}$/.test(to)) return 'BODEGA_A_PRINCIPAL';
  if (usesIax) return 'ENTRE_SEDES';
  return 'INTERNA';
}

export function escapeCsv(value) {
  const raw = value == null ? '' : String(value);
  const text = /^[=+\-@]/.test(raw) ? `'${raw}` : raw;
  return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

export function rowsToCsv(headers, rows) {
  const lines = [headers.map((item) => escapeCsv(item.label)).join(',')];
  rows.forEach((row) => {
    lines.push(headers.map((item) => escapeCsv(row[item.key])).join(','));
  });
  return `\uFEFF${lines.join('\r\n')}\r\n`;
}

export function parseKeyValueSnapshot(contents) {
  return Object.fromEntries(String(contents ?? '')
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => line && !line.startsWith('#') && line.includes('='))
    .map((line) => {
      const index = line.indexOf('=');
      const key = line.slice(0, index).trim();
      const value = line.slice(index + 1).trim();
      return [key, SAFE_VALUE.test(value) ? value : value.replace(/[^A-Za-z0-9_.:@/+ -]/g, '').slice(0, 120)];
    }));
}

export function percentChange(current, previous) {
  const now = Number(current ?? 0);
  const before = Number(previous ?? 0);
  if (before === 0) return now === 0 ? 0 : null;
  return Math.round(((now - before) / before) * 1000) / 10;
}

export function summarizeTrunkHistory(rows) {
  const items = [...rows].sort((a, b) => new Date(a.checkedAt) - new Date(b.checkedAt));
  const known = items.filter((item) => ['UP', 'DOWN'].includes(item.status));
  const up = known.filter((item) => item.status === 'UP');
  let outages = 0;
  let previous = null;
  known.forEach((item) => {
    if (item.status === 'DOWN' && previous !== 'DOWN') outages += 1;
    previous = item.status;
  });
  const latencies = up.map((item) => Number(item.latencyMs)).filter(Number.isFinite);
  const addresses = [...new Set(items.map((item) => item.peerIp).filter(Boolean))];
  return {
    samples: items.length,
    uptimePercent: known.length ? Math.round((up.length / known.length) * 1000) / 10 : null,
    outages,
    averageLatencyMs: latencies.length
      ? Math.round((latencies.reduce((sum, value) => sum + value, 0) / latencies.length) * 10) / 10
      : null,
    lastUpAt: [...up].reverse()[0]?.checkedAt ?? null,
    addresses,
    ipChanges: Math.max(0, addresses.length - 1),
  };
}
