import assert from 'node:assert/strict';
import test from 'node:test';
import {
  departmentForNumber,
  directionForCall,
  parseKeyValueSnapshot,
  percentChange,
  rowsToCsv,
  summarizeTrunkHistory,
} from './operations.js';

test('clasifica extensiones y grupos por departamento', () => {
  assert.equal(departmentForNumber('6100'), 'Ventas');
  assert.equal(departmentForNumber('2006'), 'Soporte');
  assert.equal(departmentForNumber('3001'), 'Bodega remota');
});

test('identifica llamadas entre sedes', () => {
  assert.equal(directionForCall('2000', '3001', ['IAX2']), 'PRINCIPAL_A_BODEGA');
  assert.equal(directionForCall('3001', '2000', ['IAX2']), 'BODEGA_A_PRINCIPAL');
  assert.equal(directionForCall('2000', '2001', ['PJSIP']), 'INTERNA');
});

test('genera CSV seguro y compatible con Excel', () => {
  const csv = rowsToCsv([{ key: 'name', label: 'Nombre' }], [{ name: 'Ventas, Norte' }]);
  assert.match(csv, /^\uFEFFNombre/);
  assert.match(csv, /"Ventas, Norte"/);
  assert.match(rowsToCsv([{ key: 'name', label: 'Nombre' }], [{ name: '=HYPERLINK("x")' }]), /'=HYPERLINK/);
});

test('analiza snapshot sin aceptar metacaracteres', () => {
  const snapshot = parseKeyValueSnapshot('firewall=running\nbackup=/opt/backups/ok;rm -rf /\n');
  assert.equal(snapshot.firewall, 'running');
  assert.equal(snapshot.backup, '/opt/backups/okrm -rf /');
});

test('calcula tendencias y disponibilidad de troncal', () => {
  assert.equal(percentChange(120, 100), 20);
  assert.equal(percentChange(5, 0), null);
  const summary = summarizeTrunkHistory([
    { status: 'UP', latencyMs: 2, peerIp: '10.0.0.2', checkedAt: '2026-08-01T00:00:00Z' },
    { status: 'DOWN', latencyMs: null, peerIp: '10.0.0.2', checkedAt: '2026-08-01T00:01:00Z' },
    { status: 'UP', latencyMs: 4, peerIp: '10.0.0.3', checkedAt: '2026-08-01T00:02:00Z' },
  ]);
  assert.equal(summary.uptimePercent, 66.7);
  assert.equal(summary.outages, 1);
  assert.equal(summary.averageLatencyMs, 3);
  assert.equal(summary.ipChanges, 1);
});
