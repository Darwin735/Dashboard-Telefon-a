import 'dotenv/config';
import { timingSafeEqual } from 'node:crypto';
import cors from 'cors';
import express from 'express';
import helmet from 'helmet';
import { getAllIaxPeers, getLiveIaxTrunkStatus } from './asterisk.js';
import { checkDatabase, closeDatabase, query } from './db.js';
import { getLiveCalls } from './liveCalls.js';
import { rowsToCsv } from './operations.js';
import {
  getCallDetails,
  getCalls,
  getDaily,
  getDepartments,
  getHourly,
  getIvr,
  getRingGroups,
  getSummary,
  getTrends,
  getTrunkHistory,
} from './reporting.js';
import { parseRange, previousRangeFor } from './range.js';
import { getMonitorFilesStatus, getSystemSnapshot } from './systemStatus.js';
import { getVoicemailMessages, resolveVoicemailAudio } from './voicemail.js';

const app = express();
const port = Number(process.env.PORT ?? 4000);
const corsOrigin = process.env.CORS_ORIGIN ?? 'http://localhost:3000';
const version = '1.6.0';
const requestCounters = new Map();
let lastCounterSweepAt = 0;

app.disable('x-powered-by');
app.set('trust proxy', 'loopback');
app.use(helmet());
app.use(cors({ origin: corsOrigin.split(',').map((item) => item.trim()), methods: ['GET'] }));
app.use(express.json({ limit: '16kb' }));

app.use((req, res, next) => {
  const now = Date.now();
  const key = req.ip ?? 'local';
  const current = requestCounters.get(key);
  const windowMs = 60_000;
  const limit = Number(process.env.API_RATE_LIMIT_PER_MINUTE ?? 600);
  if (now - lastCounterSweepAt > windowMs || requestCounters.size > 2_000) {
    for (const [address, counter] of requestCounters) {
      if (now - counter.startedAt > windowMs) requestCounters.delete(address);
    }
    lastCounterSweepAt = now;
  }
  const state = !current || now - current.startedAt > windowMs
    ? { startedAt: now, count: 1 }
    : { ...current, count: current.count + 1 };
  requestCounters.set(key, state);
  if (state.count > limit) {
    res.status(429).json({ error: 'Demasiadas consultas; intente nuevamente en un minuto.' });
    return;
  }
  next();
});

app.use((req, res, next) => {
  const mode = String(process.env.AUTH_MODE ?? 'off').toLowerCase();
  if (mode === 'off') {
    next();
    return;
  }
  const user = String(req.get('x-authenticated-user') ?? '').trim();
  if ((mode === 'proxy' || mode === 'hybrid') && user) {
    res.setHeader('X-Dashboard-User', user.slice(0, 80));
    next();
    return;
  }
  if (mode === 'token' || mode === 'hybrid') {
    const expected = String(process.env.API_TOKEN ?? '');
    const provided = String(req.get('authorization') ?? '').replace(/^Bearer\s+/i, '');
    const matches = expected && provided && expected.length === provided.length
      && timingSafeEqual(Buffer.from(expected), Buffer.from(provided));
    if (matches) {
      next();
      return;
    }
  }
  res.status(401).json({ error: 'Autenticacion requerida.' });
});

function asyncRoute(handler) {
  return (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next);
}

function dateStamp() {
  return new Date().toISOString().replaceAll(':', '-').slice(0, 19);
}

function csv(res, name, contents) {
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="${name}"`);
  res.send(contents);
}

async function databaseSourceStatus() {
  try {
    const [cdr, ivr, trunk] = await Promise.all([
      query('SELECT COUNT(*) AS total, MAX(calldate) AS latest FROM cdr'),
      query('SELECT COUNT(*) AS total, MAX(event_time) AS latest FROM ivr_events'),
      query('SELECT COUNT(*) AS total, MAX(checked_at) AS latest FROM trunk_status'),
    ]);
    return {
      cdr: { status: 'ok', total: Number(cdr[0]?.total ?? 0), updatedAt: cdr[0]?.latest ?? null },
      ivr: { status: 'ok', total: Number(ivr[0]?.total ?? 0), updatedAt: ivr[0]?.latest ?? null },
      trunkHistory: { status: 'ok', total: Number(trunk[0]?.total ?? 0), updatedAt: trunk[0]?.latest ?? null },
    };
  } catch (error) {
    return {
      cdr: { status: 'unavailable', detail: error.message },
      ivr: { status: 'unavailable', detail: error.message },
      trunkHistory: { status: 'unavailable', detail: error.message },
    };
  }
}

async function resolvedTrunkStatus() {
  const live = await getLiveIaxTrunkStatus();
  if (live.source === 'asterisk') return live;
  let rows = [];
  try {
    rows = await query(
      `SELECT trunk_name AS trunkName, peer_ip AS peerIp, status, latency_ms AS latencyMs,
              detail, checked_at AS checkedAt
       FROM trunk_status WHERE trunk_name = ? ORDER BY checked_at DESC LIMIT 1`,
      [live.trunkName],
    );
  } catch (_error) {
    return { ...live, detail: `${live.detail} Tampoco fue posible consultar el historial trunk_status.` };
  }
  const stored = rows[0];
  if (!stored) return live;
  const checkedAt = new Date(stored.checkedAt);
  const ageSeconds = Math.max(0, Math.round((Date.now() - checkedAt.getTime()) / 1000));
  const stale = !Number.isFinite(ageSeconds) || ageSeconds > 150;
  return {
    ...live,
    ...stored,
    status: stale ? 'UNKNOWN' : stored.status,
    source: stale ? 'history-stale' : 'history',
    stale,
    ageSeconds,
    configured: true,
    reachable: !stale && stored.status === 'UP',
    protocol: 'IAX2',
    port: 4569,
    detail: stale ? `La ultima lectura guardada tiene ${ageSeconds} segundos.` : 'Estado obtenido del monitor historico de la troncal.',
    recommendation: stale ? live.recommendation : 'El monitor historico esta actualizando correctamente.',
  };
}

async function systemStatus() {
  const [database, sources, snapshot, monitors, trunk, live] = await Promise.all([
    checkDatabase().catch(() => false),
    databaseSourceStatus(),
    getSystemSnapshot(),
    getMonitorFilesStatus(),
    resolvedTrunkStatus(),
    getLiveCalls(),
  ]);
  const checks = [
    { id: 'api', label: 'API Express', status: 'ok', detail: `v${version}` },
    { id: 'database', label: 'MariaDB', status: database ? 'ok' : 'down', detail: database ? 'Conexion de solo lectura activa' : 'Sin conexion' },
    { id: 'cdr', label: 'CDR', ...sources.cdr },
    { id: 'ivr', label: 'Eventos IVR', ...sources.ivr },
    { id: 'trunk-history', label: 'Historial IAX2', ...sources.trunkHistory },
    { id: 'peers-monitor', label: 'Monitor de peers', ...monitors.peers },
    { id: 'calls-monitor', label: 'Monitor de llamadas', ...monitors.channels },
    { id: 'trunk', label: 'Troncal entre sedes', status: trunk.status === 'UP' ? 'ok' : trunk.status === 'DOWN' ? 'down' : 'warning', detail: trunk.detail, updatedAt: trunk.checkedAt },
    { id: 'live-calls', label: 'Llamadas en curso', status: live.status === 'ok' ? 'ok' : live.status, detail: `${live.total} llamadas activas`, updatedAt: live.updatedAt },
    { id: 'security-snapshot', label: 'Monitor de seguridad', status: snapshot.status, detail: snapshot.detail, updatedAt: snapshot.updatedAt },
  ];
  const failing = checks.filter((item) => !['ok'].includes(item.status));
  return {
    status: !database ? 'down' : failing.length ? 'degraded' : 'ok',
    version,
    checkedAt: new Date().toISOString(),
    checks,
    security: snapshot,
    trunk,
    live,
  };
}

function securityControls(snapshot) {
  const values = snapshot.values ?? {};
  return [
    { id: 'fail2ban', label: 'Fail2ban Asterisk', status: values.fail2ban_asterisk ?? 'unknown', detail: `${values.fail2ban_banned ?? 0} bloqueadas; maxretry=${values.fail2ban_maxretry || '—'}; bantime=${values.fail2ban_bantime || '—'}s` },
    { id: 'firewall', label: 'Firewall', status: values.firewall ?? 'unknown', detail: values.firewall_zone ? `Zona ${values.firewall_zone}; ${values.firewall_ports || 'sin puertos explicitos'}` : 'Zona no detectada' },
    { id: 'anonymous', label: 'SIP anonimo', status: values.anonymous_sip ?? 'unknown', detail: values.anonymous_sip === 'disabled' ? 'Llamadas sin autenticacion rechazadas' : 'Revisar configuracion' },
    { id: 'mariadb', label: 'MariaDB local', status: values.mariadb_local ?? 'unknown', detail: 'El puerto 3306 no debe publicarse a la LAN' },
    { id: 'https', label: 'HTTPS', status: values.https ?? 'unknown', detail: values.https === 'active' ? 'Nginx escucha en 443' : 'TLS no detectado' },
    { id: 'auth', label: 'Acceso al dashboard', status: values.dashboard_auth ?? 'unknown', detail: values.dashboard_auth === 'active' ? 'Autenticacion web habilitada' : 'Habilitacion opcional pendiente' },
    { id: 'passwords', label: 'Politica de contrasenas', status: Number(values.password_min_length) >= 12 ? 'ok' : 'warning', detail: `Longitud minima del sistema: ${values.password_min_length ?? 'sin lectura'}` },
    { id: 'backup', label: 'Ultimo respaldo', status: values.backup_path ? 'ok' : 'unknown', detail: values.backup_path ?? 'Sin lectura' },
  ];
}

app.get('/api/health', asyncRoute(async (_req, res) => {
  const database = await checkDatabase().catch(() => false);
  res.json({ status: database ? 'ok' : 'degraded', database, version, timestamp: new Date().toISOString() });
}));

app.get('/api/system-status', asyncRoute(async (_req, res) => res.json(await systemStatus())));

app.get('/api/security', asyncRoute(async (_req, res) => {
  const snapshot = await getSystemSnapshot();
  res.json({
    ...snapshot,
    controls: securityControls(snapshot),
  });
}));

app.get('/api/voicemail', asyncRoute(async (_req, res) => res.json(await getVoicemailMessages())));

app.get('/api/voicemail/audio/:context/:mailbox/:folder/:message', asyncRoute(async (req, res) => {
  const audio = await resolveVoicemailAudio(req.params);
  res.setHeader('Content-Type', audio.mime);
  res.setHeader('Cache-Control', 'private, no-store, max-age=0');
  res.setHeader('Content-Disposition', `inline; filename="${req.params.message}${audio.mime === 'audio/mpeg' ? '.mp3' : '.wav'}"`);
  res.sendFile(audio.path);
}));

app.get('/api/summary', asyncRoute(async (req, res) => res.json(await getSummary(parseRange(req.query)))));
app.get('/api/departments', asyncRoute(async (req, res) => res.json(await getDepartments(parseRange(req.query)))));
app.get('/api/ring-groups', asyncRoute(async (req, res) => res.json(await getRingGroups(parseRange(req.query)))));
app.get('/api/hourly', asyncRoute(async (req, res) => res.json(await getHourly(parseRange(req.query)))));
app.get('/api/daily', asyncRoute(async (req, res) => res.json(await getDaily(parseRange(req.query)))));
app.get('/api/ivr', asyncRoute(async (req, res) => res.json(await getIvr(parseRange(req.query)))));

app.get('/api/trends', asyncRoute(async (req, res) => {
  const range = parseRange(req.query);
  res.json(await getTrends(range, previousRangeFor(range)));
}));

app.get('/api/trunk', asyncRoute(async (_req, res) => res.json(await resolvedTrunkStatus())));

app.get('/api/trunks', asyncRoute(async (_req, res) => res.json(await getAllIaxPeers())));

app.get('/api/trunk-history', asyncRoute(async (req, res) => {
  const range = parseRange(req.query);
  const trunkName = String(process.env.IAX_TRUNK_NAME ?? 'BODEGA-IAX');
  res.json(await getTrunkHistory(range, trunkName));
}));

app.get('/api/live-calls', asyncRoute(async (_req, res) => res.json(await getLiveCalls())));

app.get('/api/calls', asyncRoute(async (req, res) => {
  const result = await getCalls(parseRange(req.query), req.query);
  delete result.exportItems;
  res.json(result);
}));

app.get('/api/calls/:id', asyncRoute(async (req, res) => res.json(await getCallDetails(req.params.id))));

app.get('/api/recent', asyncRoute(async (req, res) => {
  const result = await getCalls(parseRange(req.query), { limit: 25 });
  res.json({ range: result.range, items: result.items.map((item) => ({
    calldate: item.calldate,
    src: item.src,
    dst: item.dst,
    disposition: item.disposition,
    billsec: item.billsec,
    uniqueid: item.id,
  })) });
}));

app.get('/api/export/calls.csv', asyncRoute(async (req, res) => {
  const result = await getCalls(parseRange(req.query), { ...req.query, maxRows: 5000, limit: 200 });
  const contents = rowsToCsv([
    { key: 'calldate', label: 'Fecha y hora' },
    { key: 'src', label: 'Origen' },
    { key: 'dst', label: 'Destino' },
    { key: 'department', label: 'Departamento' },
    { key: 'disposition', label: 'Estado' },
    { key: 'duration', label: 'Duracion total (s)' },
    { key: 'billsec', label: 'Conversacion (s)' },
    { key: 'direction', label: 'Direccion' },
    { key: 'voicemail', label: 'Voicemail' },
    { key: 'id', label: 'LinkedID' },
  ], result.exportItems);
  csv(res, `llamadas-${result.range.from}-${result.range.to}.csv`, contents);
}));

app.get('/api/export/ivr.csv', asyncRoute(async (req, res) => {
  const report = await getIvr(parseRange(req.query));
  csv(res, `ivr-${report.range.from}-${report.range.to}.csv`, rowsToCsv([
    { key: 'menuId', label: 'Menu' },
    { key: 'optionCode', label: 'Opcion' },
    { key: 'optionLabel', label: 'Etiqueta' },
    { key: 'selections', label: 'Selecciones' },
  ], report.items));
}));

app.get('/api/quality', asyncRoute(async (req, res) => {
  const range = parseRange(req.query);
  const trunk = await resolvedTrunkStatus();
  const history = await getTrunkHistory(range, trunk.trunkName);
  res.json({
    status: trunk.status === 'UP' ? 'partial' : 'warning',
    iaxLatencyMs: trunk.latencyMs,
    averageIaxLatencyMs: history.summary.averageLatencyMs,
    availabilityPercent: history.summary.uptimePercent,
    rtp: {
      available: false,
      jitterMs: null,
      packetLossPercent: null,
      detail: 'Asterisk CDR no contiene jitter ni perdida RTP. Habilite RTCP/CEL para medirlos sin inventar datos.',
    },
  });
}));

app.get('/api/evidence', asyncRoute(async (req, res) => {
  const range = parseRange(req.query);
  const [system, summary, departments, groups, hourly, daily, ivr, trunk, peers, history, live, security, voicemail] = await Promise.all([
    systemStatus(),
    getSummary(range),
    getDepartments(range),
    getRingGroups(range),
    getHourly(range),
    getDaily(range),
    getIvr(range),
    resolvedTrunkStatus(),
    getAllIaxPeers(),
    getTrunkHistory(range, String(process.env.IAX_TRUNK_NAME ?? 'BODEGA-IAX')),
    getLiveCalls(),
    getSystemSnapshot(),
    getVoicemailMessages(),
  ]);
  res.json({
    title: 'Evidencia Dashboard VoIP - Corporacion Litoral',
    generatedAt: new Date().toISOString(),
    version,
    range: { from: range.from, to: range.to },
    system,
    summary,
    departments,
    groups,
    hourly,
    daily,
    ivr,
    trunk,
    peers,
    trunkHistory: history,
    live,
    security,
    voicemail,
    declaration: 'Datos obtenidos en vivo de Issabel/Asterisk. No se incluyen datos simulados.',
  });
}));

app.get('/api/export/evidence.csv', asyncRoute(async (req, res) => {
  const range = parseRange(req.query);
  const [summary, groups, ivr, trunk, live, security] = await Promise.all([
    getSummary(range), getRingGroups(range), getIvr(range), resolvedTrunkStatus(), getLiveCalls(), getSystemSnapshot(),
  ]);
  const securityValues = security.values ?? {};
  const rows = [
    { criterion: 'Total de llamadas', value: summary.total, status: 'OK' },
    { criterion: 'Porcentaje contestadas', value: `${summary.answerRate}%`, status: 'OK' },
    { criterion: 'Duracion promedio', value: `${summary.avgDuration}s`, status: 'OK' },
    ...groups.items.map((item) => ({ criterion: `Respuesta ${item.groupName}`, value: `${item.answerRate}%`, status: 'OK' })),
    { criterion: 'Eventos IVR', value: ivr.items.reduce((sum, item) => sum + item.selections, 0), status: ivr.items.length ? 'OK' : 'PENDIENTE' },
    { criterion: 'Troncal', value: `${trunk.trunkName} ${trunk.peerIp}`, status: trunk.status },
    { criterion: 'Monitor llamadas en curso', value: live.total, status: live.status },
    { criterion: 'Fail2ban Asterisk', value: `${securityValues.fail2ban_banned ?? 0} bloqueadas`, status: securityValues.fail2ban_asterisk ?? 'UNKNOWN' },
    { criterion: 'Firewall', value: `${securityValues.firewall_zone ?? 'sin zona'} ${securityValues.firewall_ports ?? ''}`.trim(), status: securityValues.firewall ?? 'UNKNOWN' },
    { criterion: 'SIP anonimo', value: 'Llamadas invitadas', status: securityValues.anonymous_sip ?? 'UNKNOWN' },
    { criterion: 'Politica de contrasenas', value: `minimo ${securityValues.password_min_length ?? 'sin lectura'}`, status: Number(securityValues.password_min_length) >= 12 ? 'OK' : 'REVISAR' },
    { criterion: 'Autenticacion dashboard', value: 'Acceso web', status: securityValues.dashboard_auth ?? 'UNKNOWN' },
  ];
  csv(res, `evidencia-dashboard-${dateStamp()}.csv`, rowsToCsv([
    { key: 'criterion', label: 'Criterio' },
    { key: 'value', label: 'Valor' },
    { key: 'status', label: 'Estado' },
  ], rows));
}));

app.use((_req, res) => res.status(404).json({ error: 'Ruta no encontrada.' }));

app.use((error, _req, res, _next) => {
  const status = Number(error.status ?? 500);
  if (status >= 500) console.error(error);
  res.status(status).json({ error: status >= 500 ? 'Error al consultar Issabel.' : error.message });
});

const server = app.listen(port, '127.0.0.1', () => {
  console.log(`API VoIP v${version} escuchando en http://127.0.0.1:${port}`);
});

async function shutdown(signal) {
  console.log(`${signal}: cerrando API`);
  server.close(async () => {
    await closeDatabase();
    process.exit(0);
  });
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
