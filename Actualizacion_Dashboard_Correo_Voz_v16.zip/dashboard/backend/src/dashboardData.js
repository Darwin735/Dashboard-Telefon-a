const REQUIRED_DEPARTMENTS = [
  'Recepcion',
  'Ventas',
  'Soporte',
  'Finanzas',
  'Gerencia',
  'Logistica',
  'Bodega remota',
  'Otros',
];

export function completeDepartmentRows(rows = []) {
  const items = new Map(REQUIRED_DEPARTMENTS.map((department) => [
    department,
    { department, calls: 0 },
  ]));
  rows.forEach((row) => {
    const department = String(row.department ?? 'Otros');
    items.set(department, { department, calls: Number(row.calls ?? 0) });
  });
  return [...items.values()];
}
