import { readFile, stat } from 'node:fs/promises';
import { departmentForNumber } from './operations.js';

const DEFAULT_CHANNELS_FILE = '/run/voip-dashboard/channels.concise';
const MAX_SNAPSHOT_AGE_SECONDS = 8;

function durationSeconds(value) {
  const text = String(value ?? '').trim();
  if (/^\d+$/.test(text)) return Number(text);
  const parts = text.split(':').map(Number);
  if (parts.length === 3 && parts.every(Number.isFinite)) {
    return (parts[0] * 3600) + (parts[1] * 60) + parts[2];
  }
  return 0;
}

function dialedExtension(channel) {
  const match = String(channel ?? '').match(/\/(\d{3,6})(?:[-@/]|$)/);
  return match?.[1] ?? '';
}

function numericExtension(value) {
  const match = String(value ?? '').match(/(?:^|[^\d])(\d{3,6})(?:[^\d]|$)/);
  return match?.[1] ?? '';
}

function callStatus(channels) {
  const states = channels.map((channel) => channel.state.toLowerCase());
  if (states.some((state) => state === 'up')) return 'CONNECTED';
  if (states.some((state) => ['ring', 'ringing'].includes(state))) return 'RINGING';
  return 'DIALING';
}

function endpoints(channels) {
  const callers = channels.map((channel) => numericExtension(channel.callerId)).filter(Boolean);
  const dialed = channels.flatMap((channel) => [
    numericExtension(channel.extension),
    dialedExtension(channel.applicationData),
  ]).filter(Boolean);
  const from = callers.find((value) => !dialed.includes(value)) ?? callers[0] ?? dialed[0] ?? '—';
  const to = dialed.find((value) => value !== from)
    ?? callers.find((value) => value !== from)
    ?? '—';
  return { from, to };
}

function direction(from, to, technologies) {
  if (/^2\d{3}$/.test(from) && /^3\d{3}$/.test(to)) return 'PRINCIPAL_A_BODEGA';
  if (/^3\d{3}$/.test(from) && /^2\d{3}$/.test(to)) return 'BODEGA_A_PRINCIPAL';
  if (technologies.includes('IAX2') && /^2\d{3}$/.test(from)) return 'PRINCIPAL_A_BODEGA';
  if (technologies.includes('IAX2') && /^2\d{3}$/.test(to)) return 'BODEGA_A_PRINCIPAL';
  if (technologies.includes('IAX2') && /^3\d{3}$/.test(from)) return 'BODEGA_A_PRINCIPAL';
  if (technologies.includes('IAX2') && /^3\d{3}$/.test(to)) return 'PRINCIPAL_A_BODEGA';
  if (technologies.includes('IAX2')) return 'ENTRE_SEDES';
  return 'INTERNA';
}

export function parseConciseChannels(output) {
  const rows = String(output ?? '')
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => line.includes('!'))
    .map((line) => {
      const fields = line.split('!');
      return {
        channel: fields[0] ?? '',
        context: fields[1] ?? '',
        extension: fields[2] ?? '',
        priority: fields[3] ?? '',
        state: fields[4] ?? '',
        application: fields[5] ?? '',
        applicationData: fields[6] ?? '',
        callerId: fields[7] ?? '',
        accountCode: fields[8] ?? '',
        peerAccount: fields[9] ?? '',
        amaFlag: fields[10] ?? '',
        durationSeconds: durationSeconds(fields[11]),
        bridgeId: fields[12] ?? '',
        uniqueId: fields[13] ?? '',
      };
    })
    .filter((row) => row.channel && row.uniqueId);

  const grouped = new Map();
  rows.forEach((row) => {
    // Los dos canales de una conversacion conectada comparten el BridgeID.
    // Mientras esta timbrando aun no hay puente, por lo que UniqueID evita
    // mezclar llamadas simultaneas.
    const key = row.bridgeId || row.uniqueId || row.channel;
    if (!grouped.has(key)) grouped.set(key, []);
    grouped.get(key).push(row);
  });

  return [...grouped.entries()].map(([id, channels]) => {
    const { from, to } = endpoints(channels);
    const technologies = [...new Set(channels
      .map((channel) => channel.channel.split('/')[0])
      .filter(Boolean))];
    const status = callStatus(channels);
    const callDirection = direction(from, to, technologies);
    return {
      id,
      from,
      to,
      status,
      direction: callDirection,
      intersite: callDirection !== 'INTERNA',
      durationSeconds: Math.max(0, ...channels.map((channel) => channel.durationSeconds)),
      channelCount: channels.length,
      technologies,
      department: departmentForNumber(to),
      waitAlert: status === 'RINGING' && Math.max(0, ...channels.map((channel) => channel.durationSeconds)) >= 20,
    };
  }).sort((a, b) => b.durationSeconds - a.durationSeconds);
}

export async function getLiveCalls() {
  const snapshotFile = process.env.ASTERISK_CHANNELS_FILE ?? DEFAULT_CHANNELS_FILE;
  try {
    const [contents, fileStats] = await Promise.all([
      readFile(snapshotFile, 'utf8'),
      stat(snapshotFile),
    ]);
    const ageSeconds = Math.max(0, Math.round((Date.now() - fileStats.mtimeMs) / 1000));
    const items = parseConciseChannels(contents);
    const stale = ageSeconds > Number(process.env.LIVE_CALLS_MAX_AGE_SECONDS ?? MAX_SNAPSHOT_AGE_SECONDS);
    if (stale) {
      return {
        status: 'stale',
        source: 'asterisk',
        updatedAt: fileStats.mtime.toISOString(),
        ageSeconds,
        total: 0,
        connected: 0,
        ringing: 0,
        intersite: 0,
        items: [],
        detail: 'La lectura de canales esta vencida; no se muestran llamadas antiguas como activas.',
      };
    }
    return {
      status: 'ok',
      source: 'asterisk',
      updatedAt: fileStats.mtime.toISOString(),
      ageSeconds,
      total: items.length,
      connected: items.filter((item) => item.status === 'CONNECTED').length,
      ringing: items.filter((item) => item.status === 'RINGING').length,
      intersite: items.filter((item) => item.intersite).length,
      items,
    };
  } catch (error) {
    return {
      status: 'unavailable',
      source: 'asterisk',
      updatedAt: null,
      ageSeconds: null,
      total: 0,
      connected: 0,
      ringing: 0,
      intersite: 0,
      items: [],
      detail: error.code === 'ENOENT'
        ? 'El monitor de canales activos aun no ha creado su primera lectura.'
        : 'No fue posible leer el monitor de canales activos.',
    };
  }
}
