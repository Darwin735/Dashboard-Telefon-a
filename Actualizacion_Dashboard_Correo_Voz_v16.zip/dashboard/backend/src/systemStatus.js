import { readFile, stat } from 'node:fs/promises';
import { parseKeyValueSnapshot } from './operations.js';

const DEFAULT_STATUS_FILE = '/run/voip-dashboard/system-status.env';

async function fileStatus(path, maxAgeSeconds) {
  try {
    const info = await stat(path);
    const ageSeconds = Math.max(0, Math.round((Date.now() - info.mtimeMs) / 1000));
    return {
      status: ageSeconds <= maxAgeSeconds ? 'ok' : 'stale',
      updatedAt: info.mtime.toISOString(),
      ageSeconds,
    };
  } catch (error) {
    return { status: 'unavailable', updatedAt: null, ageSeconds: null, detail: error.code };
  }
}

export async function getSystemSnapshot() {
  const statusFile = process.env.SYSTEM_STATUS_FILE ?? DEFAULT_STATUS_FILE;
  const maxAge = Number(process.env.SYSTEM_STATUS_MAX_AGE_SECONDS ?? 90);
  try {
    const [contents, info] = await Promise.all([readFile(statusFile, 'utf8'), stat(statusFile)]);
    const ageSeconds = Math.max(0, Math.round((Date.now() - info.mtimeMs) / 1000));
    return {
      status: ageSeconds <= maxAge ? 'ok' : 'stale',
      updatedAt: info.mtime.toISOString(),
      ageSeconds,
      values: parseKeyValueSnapshot(contents),
    };
  } catch (error) {
    return {
      status: 'unavailable',
      updatedAt: null,
      ageSeconds: null,
      values: {},
      detail: error.code === 'ENOENT'
        ? 'El monitor de seguridad aun no ha creado su primera lectura.'
        : 'No fue posible leer el monitor de seguridad.',
    };
  }
}

export async function getMonitorFilesStatus() {
  const channelsFile = process.env.ASTERISK_CHANNELS_FILE ?? '/run/voip-dashboard/channels.concise';
  const peersFile = process.env.ASTERISK_PEERS_FILE ?? '/run/voip-dashboard/iax-peers.txt';
  return {
    channels: await fileStatus(channelsFile, Number(process.env.LIVE_CALLS_MAX_AGE_SECONDS ?? 8)),
    peers: await fileStatus(peersFile, Number(process.env.ASTERISK_PEERS_MAX_AGE_SECONDS ?? 8)),
  };
}
