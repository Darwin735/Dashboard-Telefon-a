import assert from 'node:assert/strict';
import test from 'node:test';
import { parseConciseChannels } from './liveCalls.js';

test('agrupa las piernas de una llamada entre sedes', () => {
  const output = [
    'PJSIP/2000-00000001!from-internal!3001!1!Up!Dial!IAX2/BODEGA-IAX/3001!2000!!!3!12!bridge-123!171000.1',
    'IAX2/BODEGA-IAX-1!from-bodega!3001!1!Up!Dial!PJSIP/3001!2000!!!3!11!bridge-123!171000.2',
  ].join('\n');

  const calls = parseConciseChannels(output);
  assert.equal(calls.length, 1);
  assert.equal(calls[0].from, '2000');
  assert.equal(calls[0].to, '3001');
  assert.equal(calls[0].status, 'CONNECTED');
  assert.equal(calls[0].direction, 'PRINCIPAL_A_BODEGA');
  assert.equal(calls[0].channelCount, 2);
});

test('identifica una llamada que aun esta timbrando', () => {
  const output = 'PJSIP/3001-00000002!from-internal!2000!1!Ringing!Dial!IAX2/PBX_PRINCIPAL/2000!3001!!!3!4!!171100.1';
  const [call] = parseConciseChannels(output);
  assert.equal(call.status, 'RINGING');
  assert.equal(call.direction, 'BODEGA_A_PRINCIPAL');
});

test('no mezcla llamadas simultaneas que aun no tienen puente', () => {
  const output = [
    'PJSIP/2000-a!from-internal!3001!1!Ring!Dial!IAX2/BODEGA-IAX/3001!2000!!!3!2!!171200.1',
    'PJSIP/2001-b!from-internal!3002!1!Ring!Dial!IAX2/BODEGA-IAX/3002!2001!!!3!1!!171200.2',
  ].join('\n');
  const calls = parseConciseChannels(output);
  assert.equal(calls.length, 2);
});

test('reconoce IAX2 entre sedes aunque la ruta transforme el destino', () => {
  const output = [
    'SIP/2001-00000003!from-internal!5050!1!Up!Dial!IAX2/BODEGA-IAX/5050!2001!!!3!5!bridge-5050!171300.1',
    'IAX2/BODEGA-IAX-3!from-trunk!5050!1!Up!Dial!SIP/5050!2001!!!3!5!bridge-5050!171300.2',
  ].join('\n');
  const [call] = parseConciseChannels(output);
  assert.equal(call.to, '5050');
  assert.equal(call.direction, 'PRINCIPAL_A_BODEGA');
  assert.equal(call.intersite, true);
});

test('devuelve una lista vacia cuando no hay canales', () => {
  assert.deepEqual(parseConciseChannels('0 active channels\n0 active calls'), []);
});
