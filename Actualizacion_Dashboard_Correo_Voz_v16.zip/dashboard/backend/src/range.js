const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;
const MAX_RANGE_DAYS = 92;

function dateInHonduras(date = new Date()) {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/Tegucigalpa',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(date);
}

function shiftDate(dateString, deltaDays) {
  const date = new Date(`${dateString}T12:00:00Z`);
  date.setUTCDate(date.getUTCDate() + deltaDays);
  return date.toISOString().slice(0, 10);
}

export function previousRangeFor(range) {
  const start = new Date(`${range.from}T12:00:00Z`);
  const end = new Date(`${range.to}T12:00:00Z`);
  const days = Math.round((end - start) / 86400000) + 1;
  const to = shiftDate(range.from, -1);
  const from = shiftDate(to, -(days - 1));
  return {
    from,
    to,
    sqlFrom: `${from} 00:00:00`,
    sqlTo: `${to} 23:59:59`,
  };
}

export function parseRange(search) {
  const today = dateInHonduras();
  const to = search.to ?? today;
  const from = search.from ?? shiftDate(to, -6);

  if (!DATE_PATTERN.test(from) || !DATE_PATTERN.test(to)) {
    const error = new Error('Las fechas deben usar el formato YYYY-MM-DD.');
    error.status = 400;
    throw error;
  }

  const start = new Date(`${from}T00:00:00Z`);
  const end = new Date(`${to}T00:00:00Z`);
  const days = Math.floor((end - start) / 86400000);

  if (!Number.isFinite(days) || days < 0 || days > MAX_RANGE_DAYS) {
    const error = new Error(`El rango debe estar entre 1 y ${MAX_RANGE_DAYS + 1} dias.`);
    error.status = 400;
    throw error;
  }

  return {
    from,
    to,
    sqlFrom: `${from} 00:00:00`,
    sqlTo: `${to} 23:59:59`,
  };
}
