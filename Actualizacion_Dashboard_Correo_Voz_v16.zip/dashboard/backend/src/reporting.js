import { completeDepartmentRows } from './dashboardData.js';
import { query } from './db.js';
import {
  departmentForNumber,
  directionForCall,
  percentChange,
  summarizeTrunkHistory,
} from './operations.js';

function number(value) {
  return Number(value ?? 0);
}

function technologiesFor(value) {
  return [...new Set(String(value ?? '')
    .split(',')
    .map((channel) => channel.split('/')[0].trim())
    .filter(Boolean))];
}

export async function getSummary(range) {
  const rows = await query(
    `SELECT
       COUNT(*) AS total,
       COALESCE(SUM(answered), 0) AS answered,
       ROUND(100 * COALESCE(SUM(answered), 0) / NULLIF(COUNT(*), 0), 1) AS answerRate,
       ROUND(AVG(CASE WHEN answered = 1 THEN answered_billsec END), 1) AS avgDuration
     FROM (
       SELECT COALESCE(NULLIF(linkedid, ''), uniqueid) AS call_id,
              MAX(disposition = 'ANSWERED') AS answered,
              MAX(CASE WHEN disposition = 'ANSWERED' THEN billsec ELSE 0 END) AS answered_billsec
       FROM cdr
       WHERE calldate BETWEEN ? AND ?
       GROUP BY COALESCE(NULLIF(linkedid, ''), uniqueid)
     ) logical_calls`,
    [range.sqlFrom, range.sqlTo],
  );
  const row = rows[0] ?? {};
  return {
    range: { from: range.from, to: range.to },
    total: number(row.total),
    answered: number(row.answered),
    answerRate: number(row.answerRate),
    avgDuration: number(row.avgDuration),
  };
}

export async function getDepartments(range) {
  const rows = await query(
    `SELECT department, COUNT(DISTINCT call_id) AS calls
     FROM (
       SELECT COALESCE(NULLIF(linkedid, ''), uniqueid) AS call_id,
         CASE
           WHEN dst = '2000' THEN 'Recepcion'
           WHEN (dst BETWEEN '2001' AND '2004') OR dst IN ('6100', '2901') THEN 'Ventas'
           WHEN (dst BETWEEN '2005' AND '2007') OR dst IN ('6200', '2902') THEN 'Soporte'
           WHEN (dst BETWEEN '2008' AND '2009') OR dst = '6300' THEN 'Finanzas'
           WHEN dst = '2010' THEN 'Gerencia'
           WHEN (dst BETWEEN '2011' AND '2012') OR dst = '6400' THEN 'Logistica'
           WHEN dst BETWEEN '3000' AND '3999' THEN 'Bodega remota'
           ELSE 'Otros'
         END AS department
       FROM cdr
       WHERE calldate BETWEEN ? AND ?
     ) classified
     GROUP BY department
     ORDER BY calls DESC`,
    [range.sqlFrom, range.sqlTo],
  );
  return { range: { from: range.from, to: range.to }, items: completeDepartmentRows(rows) };
}

export async function getRingGroups(range) {
  const rows = await query(
    `WITH logical_calls AS (
       SELECT COALESCE(NULLIF(linkedid, ''), uniqueid) AS call_id,
              MAX(disposition = 'ANSWERED') AS answered,
              MAX(dst = '6100') AS touched_sales,
              MAX(dst = '6200') AS touched_support,
              MAX(dst = '2901' OR (lastapp = 'VoiceMail' AND dcontext LIKE '%6100%')) AS sales_voicemail,
              MAX(dst = '2902' OR (lastapp = 'VoiceMail' AND dcontext LIKE '%6200%')) AS support_voicemail,
              MAX(CASE WHEN disposition = 'ANSWERED' THEN billsec ELSE 0 END) AS talk_seconds,
              MAX(duration) AS total_seconds
       FROM cdr
       WHERE calldate BETWEEN ? AND ?
       GROUP BY COALESCE(NULLIF(linkedid, ''), uniqueid)
     ), group_calls AS (
       SELECT 'Ventas' AS groupName, answered, sales_voicemail AS voicemail, talk_seconds, total_seconds
         FROM logical_calls WHERE touched_sales = 1
       UNION ALL
       SELECT 'Soporte' AS groupName, answered, support_voicemail AS voicemail, talk_seconds, total_seconds
         FROM logical_calls WHERE touched_support = 1
     )
     SELECT groupName,
            COUNT(*) AS total,
            COALESCE(SUM(answered), 0) AS answered,
            COUNT(*) - COALESCE(SUM(answered), 0) AS missed,
            COALESCE(SUM(voicemail), 0) AS voicemail,
            ROUND(100 * COALESCE(SUM(answered), 0) / NULLIF(COUNT(*), 0), 1) AS answerRate,
            ROUND(AVG(CASE WHEN answered = 1 THEN GREATEST(total_seconds - talk_seconds, 0) END), 1) AS avgWaitSeconds,
            ROUND(AVG(CASE WHEN answered = 1 THEN talk_seconds END), 1) AS avgTalkSeconds
     FROM group_calls
     GROUP BY groupName
     ORDER BY groupName`,
    [range.sqlFrom, range.sqlTo],
  );
  const base = new Map([
    ['Ventas', { groupName: 'Ventas', total: 0, answered: 0, missed: 0, voicemail: 0, answerRate: 0, avgWaitSeconds: 0, avgTalkSeconds: 0 }],
    ['Soporte', { groupName: 'Soporte', total: 0, answered: 0, missed: 0, voicemail: 0, answerRate: 0, avgWaitSeconds: 0, avgTalkSeconds: 0 }],
  ]);
  rows.forEach((row) => base.set(row.groupName, Object.fromEntries(Object.entries(row)
    .map(([key, value]) => [key, key === 'groupName' ? value : number(value)]))));
  return { range: { from: range.from, to: range.to }, items: [...base.values()] };
}

export async function getHourly(range) {
  const rows = await query(
    `SELECT HOUR(first_calldate) AS hour, COUNT(*) AS calls
     FROM (
       SELECT COALESCE(NULLIF(linkedid, ''), uniqueid) AS call_id, MIN(calldate) AS first_calldate
       FROM cdr WHERE calldate BETWEEN ? AND ?
       GROUP BY COALESCE(NULLIF(linkedid, ''), uniqueid)
     ) logical_calls
     GROUP BY HOUR(first_calldate) ORDER BY hour`,
    [range.sqlFrom, range.sqlTo],
  );
  const values = Array.from({ length: 24 }, (_, hour) => ({ hour, calls: 0 }));
  rows.forEach((row) => { values[number(row.hour)].calls = number(row.calls); });
  return { range: { from: range.from, to: range.to }, items: values };
}

export async function getDaily(range) {
  const rows = await query(
    `SELECT DATE_FORMAT(first_calldate, '%Y-%m-%d') AS day, COUNT(*) AS calls
     FROM (
       SELECT COALESCE(NULLIF(linkedid, ''), uniqueid) AS call_id, MIN(calldate) AS first_calldate
       FROM cdr WHERE calldate BETWEEN ? AND ?
       GROUP BY COALESCE(NULLIF(linkedid, ''), uniqueid)
     ) logical_calls
     GROUP BY DATE(first_calldate) ORDER BY DATE(first_calldate)`,
    [range.sqlFrom, range.sqlTo],
  );
  return { range: { from: range.from, to: range.to }, items: rows.map((row) => ({ day: row.day, calls: number(row.calls) })) };
}

export async function getIvr(range) {
  const rows = await query(
    `SELECT menu_id AS menuId, option_code AS optionCode, option_label AS optionLabel,
            COUNT(*) AS selections
     FROM ivr_events
     WHERE event_time BETWEEN ? AND ?
     GROUP BY menu_id, option_code, option_label
     ORDER BY menu_id, selections DESC`,
    [range.sqlFrom, range.sqlTo],
  );
  return {
    range: { from: range.from, to: range.to },
    items: rows.map((row) => ({ ...row, selections: number(row.selections) })),
  };
}

function disposition(rows) {
  if (rows.some((row) => row.disposition === 'ANSWERED')) return 'ANSWERED';
  if (rows.some((row) => row.disposition === 'BUSY')) return 'BUSY';
  if (rows.some((row) => row.disposition === 'FAILED')) return 'FAILED';
  return 'NO ANSWER';
}

function normalizeCall(row) {
  const technologies = technologiesFor(row.channels);
  const source = row.src || '—';
  const destination = row.dst || '—';
  const direction = directionForCall(source, destination, technologies);
  return {
    id: row.id,
    calldate: row.calldate,
    src: source,
    dst: destination,
    disposition: row.disposition,
    duration: number(row.duration),
    billsec: number(row.billsec),
    waitSeconds: Math.max(0, number(row.duration) - number(row.billsec)),
    department: departmentForNumber(destination),
    direction,
    intersite: direction !== 'INTERNA',
    technologies,
    voicemail: Boolean(number(row.voicemail)),
    groupName: row.touchedSales ? 'Ventas' : row.touchedSupport ? 'Soporte' : null,
  };
}

export async function getCalls(range, filters = {}) {
  const maxRows = Math.min(5000, Math.max(25, number(filters.maxRows) || 5000));
  const rows = await query(
    `SELECT COALESCE(NULLIF(linkedid, ''), uniqueid) AS id,
            MIN(calldate) AS calldate,
            SUBSTRING_INDEX(GROUP_CONCAT(src ORDER BY calldate, uniqueid SEPARATOR ','), ',', 1) AS src,
            COALESCE(
              SUBSTRING_INDEX(GROUP_CONCAT(
                CASE WHEN dst REGEXP '^(20[0-9]{2}|29(01|02)|3[0-9]{3}|6[1-4]00)$' THEN dst END
                ORDER BY calldate DESC, uniqueid DESC SEPARATOR ','
              ), ',', 1),
              SUBSTRING_INDEX(GROUP_CONCAT(dst ORDER BY calldate, uniqueid SEPARATOR ','), ',', 1)
            ) AS dst,
            MAX(duration) AS duration,
            MAX(CASE WHEN disposition = 'ANSWERED' THEN billsec ELSE 0 END) AS billsec,
            MAX(dst = '6100') AS touchedSales,
            MAX(dst = '6200') AS touchedSupport,
            MAX(lastapp = 'VoiceMail' OR dst IN ('2901', '2902')) AS voicemail,
            GROUP_CONCAT(DISTINCT channel SEPARATOR ',') AS channels,
            GROUP_CONCAT(disposition SEPARATOR ',') AS dispositions
     FROM cdr
     WHERE calldate BETWEEN ? AND ?
     GROUP BY COALESCE(NULLIF(linkedid, ''), uniqueid)
     ORDER BY MIN(calldate) DESC
     LIMIT ${maxRows}`,
    [range.sqlFrom, range.sqlTo],
  );
  const normalized = rows.map((row) => normalizeCall({
    ...row,
    disposition: disposition(String(row.dispositions ?? '').split(',').map((value) => ({ disposition: value }))),
  }));
  const search = String(filters.search ?? '').trim().toLowerCase();
  const extension = String(filters.extension ?? '').trim();
  const department = String(filters.department ?? '').trim();
  const status = String(filters.status ?? '').trim();
  const direction = String(filters.direction ?? '').trim();
  const minDuration = Math.max(0, number(filters.minDuration));
  const items = normalized.filter((call) => {
    if (search && !`${call.src} ${call.dst} ${call.department} ${call.id}`.toLowerCase().includes(search)) return false;
    if (extension && call.src !== extension && call.dst !== extension) return false;
    if (department && department !== 'ALL' && call.department !== department) return false;
    if (status && status !== 'ALL' && call.disposition !== status) return false;
    if (direction && direction !== 'ALL' && call.direction !== direction) return false;
    if (call.billsec < minDuration) return false;
    return true;
  });
  const limit = Math.min(200, Math.max(1, number(filters.limit) || 200));
  const offset = Math.max(0, number(filters.offset));
  return {
    range: { from: range.from, to: range.to },
    total: items.length,
    limit,
    offset,
    items: items.slice(offset, offset + limit),
    exportItems: items,
  };
}

export async function getCallDetails(id) {
  if (!/^[A-Za-z0-9_.:-]{1,80}$/.test(String(id))) {
    const error = new Error('Identificador de llamada invalido.');
    error.status = 400;
    throw error;
  }
  const legs = await query(
    `SELECT calldate, src, dst, dcontext, channel, dstchannel, lastapp, lastdata,
            duration, billsec, disposition, uniqueid, linkedid
     FROM cdr
     WHERE COALESCE(NULLIF(linkedid, ''), uniqueid) = ?
     ORDER BY calldate, uniqueid`,
    [id],
  );
  const ivr = await query(
    `SELECT event_time AS eventTime, menu_id AS menuId, option_code AS optionCode, option_label AS optionLabel
     FROM ivr_events WHERE linkedid = ? OR uniqueid = ? ORDER BY event_time`,
    [id, id],
  );
  return { id, legs, ivr };
}

export async function getTrends(range, previousRange) {
  const [current, previous, currentGroups, previousGroups] = await Promise.all([
    getSummary(range),
    getSummary(previousRange),
    getRingGroups(range),
    getRingGroups(previousRange),
  ]);
  const previousByGroup = new Map(previousGroups.items.map((item) => [item.groupName, item]));
  return {
    range: current.range,
    previousRange: previous.range,
    current,
    previous,
    changes: {
      total: percentChange(current.total, previous.total),
      answered: percentChange(current.answered, previous.answered),
      answerRate: Math.round((current.answerRate - previous.answerRate) * 10) / 10,
      avgDuration: percentChange(current.avgDuration, previous.avgDuration),
    },
    groups: currentGroups.items.map((item) => ({
      ...item,
      previousAnswerRate: number(previousByGroup.get(item.groupName)?.answerRate),
      answerRateChange: Math.round((item.answerRate - number(previousByGroup.get(item.groupName)?.answerRate)) * 10) / 10,
    })),
  };
}

export async function getTrunkHistory(range, trunkName) {
  const rows = await query(
    `SELECT trunk_name AS trunkName, peer_ip AS peerIp, status, latency_ms AS latencyMs,
            detail, checked_at AS checkedAt
     FROM trunk_status
     WHERE trunk_name = ? AND checked_at BETWEEN ? AND ?
     ORDER BY checked_at`,
    [trunkName, range.sqlFrom, range.sqlTo],
  );
  const normalized = rows.map((row) => ({ ...row, latencyMs: row.latencyMs == null ? null : number(row.latencyMs) }));
  const maxPoints = 180;
  const stride = Math.max(1, Math.ceil(normalized.length / maxPoints));
  return {
    range: { from: range.from, to: range.to },
    trunkName,
    summary: summarizeTrunkHistory(normalized),
    items: normalized.filter((_item, index) => index % stride === 0 || index === normalized.length - 1),
  };
}
