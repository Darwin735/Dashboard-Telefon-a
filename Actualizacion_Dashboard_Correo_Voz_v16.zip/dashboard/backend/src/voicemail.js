import path from 'node:path';
import { readdir, readFile, realpath, stat } from 'node:fs/promises';

const DEFAULT_ROOT = '/var/spool/asterisk/voicemail';
const DEFAULT_MAILBOXES = '2901:Ventas,2902:Soporte';
const DEFAULT_CONTEXTS = 'default,device';
const FOLDERS = Object.freeze([
  { name: 'INBOX', status: 'NEW' },
  { name: 'Urgent', status: 'URGENT' },
  { name: 'Old', status: 'OLD' },
]);
const SAFE_SEGMENT = /^[A-Za-z0-9_-]+$/;
const SAFE_MESSAGE = /^msg\d+$/;
const AUDIO_TYPES = Object.freeze({ '.wav': 'audio/wav', '.mp3': 'audio/mpeg' });

function splitList(value, fallback) {
  return String(value || fallback).split(',').map((item) => item.trim()).filter(Boolean);
}

export function voicemailConfiguration(env = process.env) {
  const mailboxes = splitList(env.VOICEMAIL_MAILBOXES, DEFAULT_MAILBOXES).map((entry) => {
    const [mailbox, ...labelParts] = entry.split(':');
    const label = labelParts.join(':').trim() || `Buzon ${mailbox}`;
    if (!SAFE_SEGMENT.test(mailbox)) throw new Error(`Buzon de voz no valido: ${mailbox}`);
    return { mailbox, label };
  });
  const contexts = splitList(env.VOICEMAIL_CONTEXTS, DEFAULT_CONTEXTS);
  if (contexts.some((context) => !SAFE_SEGMENT.test(context))) throw new Error('Contexto de correo de voz no valido.');
  return {
    root: path.resolve(String(env.VOICEMAIL_ROOT || DEFAULT_ROOT)),
    contexts,
    mailboxes,
    maxMessages: Math.max(1, Math.min(500, Number(env.VOICEMAIL_MAX_MESSAGES || 100))),
  };
}

export function parseVoicemailMetadata(contents) {
  const values = {};
  for (const rawLine of String(contents).split(/\r?\n/)) {
    const separator = rawLine.indexOf('=');
    if (separator < 1) continue;
    const key = rawLine.slice(0, separator).trim().toLowerCase();
    let value = rawLine.slice(separator + 1).trim();
    if (value.startsWith('"') && value.endsWith('"')) value = value.slice(1, -1);
    values[key] = value;
  }
  return values;
}

function callerParts(callerId) {
  const value = String(callerId || '').trim();
  const match = value.match(/^"?([^"<]*)"?\s*<([^>]*)>$/);
  if (!match) return { callerId: value || 'Desconocido', callerNumber: '' };
  return { callerId: match[1].trim() || match[2].trim() || 'Desconocido', callerNumber: match[2].trim() };
}

function receivedAt(metadata, fileInfo) {
  const unixTime = Number(metadata.origtime);
  if (Number.isFinite(unixTime) && unixTime > 0) return new Date(unixTime * 1000).toISOString();
  return fileInfo.mtime.toISOString();
}

function assertSafePart(value, pattern = SAFE_SEGMENT) {
  const normalized = String(value || '');
  if (!pattern.test(normalized)) {
    const error = new Error('Identificador de correo de voz no valido.');
    error.status = 400;
    throw error;
  }
  return normalized;
}

function isWithin(root, candidate) {
  const relative = path.relative(root, candidate);
  return relative === '' || (!relative.startsWith('..') && !path.isAbsolute(relative));
}

async function accessibleDirectory(rootRealPath, directory) {
  try {
    const resolved = await realpath(directory);
    return isWithin(rootRealPath, resolved) ? resolved : null;
  } catch (_error) {
    return null;
  }
}

async function audioInDirectory(directory, message) {
  const files = await readdir(directory).catch(() => []);
  for (const extension of Object.keys(AUDIO_TYPES)) {
    const matched = files.find((name) => name.toLowerCase() === `${message}${extension}`.toLowerCase());
    if (matched) return { path: path.join(directory, matched), mime: AUDIO_TYPES[extension] };
  }
  return null;
}

async function readMessage({ rootRealPath, directory, context, mailbox, mailboxLabel, folder, status: folderStatus, message }) {
  const metadataPath = path.join(directory, `${message}.txt`);
  const [contents, fileInfo, audio] = await Promise.all([
    readFile(metadataPath, 'utf8'),
    stat(metadataPath),
    audioInDirectory(directory, message),
  ]);
  const metadata = parseVoicemailMetadata(contents);
  const caller = callerParts(metadata.callerid);
  const urgent = folderStatus === 'URGENT' || String(metadata.flag).toLowerCase() === 'urgent';
  const audioUrl = audio
    ? `/api/voicemail/audio/${encodeURIComponent(context)}/${encodeURIComponent(mailbox)}/${encodeURIComponent(folder)}/${encodeURIComponent(message)}`
    : null;
  return {
    id: `${context}:${mailbox}:${folder}:${message}`,
    context,
    mailbox,
    mailboxLabel,
    folder,
    status: urgent ? 'URGENT' : folderStatus,
    message,
    ...caller,
    receivedAt: receivedAt(metadata, fileInfo),
    originalDate: metadata.origdate || null,
    durationSeconds: Math.max(0, Number(metadata.duration || 0)),
    urgent,
    audioAvailable: Boolean(audio),
    audioUrl,
  };
}

export async function getVoicemailMessages(env = process.env) {
  const config = voicemailConfiguration(env);
  let rootRealPath;
  try {
    rootRealPath = await realpath(config.root);
  } catch (error) {
    return {
      status: 'unavailable',
      detail: error.code === 'ENOENT' ? 'Issabel aun no ha creado el directorio de correo de voz.' : 'No fue posible leer el correo de voz de Issabel.',
      updatedAt: new Date().toISOString(),
      totals: { total: 0, new: 0, old: 0, urgent: 0, playable: 0 },
      mailboxes: config.mailboxes.map((item) => ({ ...item, total: 0, new: 0, old: 0, urgent: 0 })),
      items: [],
    };
  }

  const messages = [];
  for (const context of config.contexts) {
    for (const mailbox of config.mailboxes) {
      for (const folder of FOLDERS) {
        const directory = await accessibleDirectory(rootRealPath, path.join(rootRealPath, context, mailbox.mailbox, folder.name));
        if (!directory) continue;
        const files = await readdir(directory).catch(() => []);
        const messageNames = [...new Set(files.filter((name) => /^msg\d+\.txt$/i.test(name)).map((name) => path.parse(name).name))];
        for (const message of messageNames) {
          try {
            messages.push(await readMessage({
              rootRealPath,
              directory,
              context,
              mailbox: mailbox.mailbox,
              mailboxLabel: mailbox.label,
              folder: folder.name,
              status: folder.status,
              message,
            }));
          } catch (_error) {
            // Un mensaje incompleto no debe ocultar el resto del buzon.
          }
        }
      }
    }
  }

  messages.sort((a, b) => new Date(b.receivedAt) - new Date(a.receivedAt));
  const items = messages.slice(0, config.maxMessages);
  const mailboxSummary = config.mailboxes.map((mailbox) => {
    const matching = messages.filter((item) => item.mailbox === mailbox.mailbox);
    return {
      ...mailbox,
      total: matching.length,
      new: matching.filter((item) => item.status === 'NEW').length,
      old: matching.filter((item) => item.status === 'OLD').length,
      urgent: matching.filter((item) => item.urgent).length,
    };
  });
  return {
    status: 'ok',
    detail: items.length ? 'Mensajes leidos directamente del buzon local de Issabel.' : 'No hay mensajes guardados en los buzones configurados.',
    updatedAt: new Date().toISOString(),
    totals: {
      total: messages.length,
      new: messages.filter((item) => item.status === 'NEW').length,
      old: messages.filter((item) => item.status === 'OLD').length,
      urgent: messages.filter((item) => item.urgent).length,
      playable: messages.filter((item) => item.audioAvailable).length,
    },
    mailboxes: mailboxSummary,
    items,
  };
}

export async function resolveVoicemailAudio(params, env = process.env) {
  const config = voicemailConfiguration(env);
  const context = assertSafePart(params.context);
  const mailbox = assertSafePart(params.mailbox);
  const folder = assertSafePart(params.folder);
  const message = assertSafePart(params.message, SAFE_MESSAGE);
  if (!config.contexts.includes(context) || !config.mailboxes.some((item) => item.mailbox === mailbox) || !FOLDERS.some((item) => item.name === folder)) {
    const error = new Error('Buzon de voz no autorizado.');
    error.status = 404;
    throw error;
  }
  let rootRealPath;
  try {
    rootRealPath = await realpath(config.root);
  } catch (_error) {
    const error = new Error('Correo de voz no disponible.');
    error.status = 404;
    throw error;
  }
  const directory = await accessibleDirectory(rootRealPath, path.join(rootRealPath, context, mailbox, folder));
  const audio = directory ? await audioInDirectory(directory, message) : null;
  if (!audio) {
    const error = new Error('El mensaje no tiene audio WAV o MP3 compatible.');
    error.status = 404;
    throw error;
  }
  const audioPath = await realpath(audio.path);
  if (!isWithin(rootRealPath, audioPath)) {
    const error = new Error('Ruta de audio no autorizada.');
    error.status = 404;
    throw error;
  }
  return { path: audioPath, mime: audio.mime };
}
