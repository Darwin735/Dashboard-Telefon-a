import { execFile } from 'node:child_process';
import { readFile, stat } from 'node:fs/promises';
import { networkInterfaces } from 'node:os';
import { promisify } from 'node:util';

const execFileAsync = promisify(execFile);
const CACHE_MS = 5_000;
const DEFAULT_TRUNK_NAME = 'BODEGA-IAX';
const DEFAULT_PEER_IP = '';
const DEFAULT_PEERS_FILE = '/run/voip-dashboard/iax-peers.txt';
const DEFAULT_PEERS_MAX_AGE_SECONDS = 8;
const SAFE_NAME = /^[A-Za-z0-9_.-]{1,80}$/;

let cachedResult = null;
let cachedAt = 0;

function configuredValue(value, fallback) {
  const candidate = String(value ?? fallback).trim();
  return SAFE_NAME.test(candidate) ? candidate : fallback;
}

function singleLine(value) {
  return String(value ?? '').replace(/\s+/g, ' ').trim().slice(0, 220);
}

function configuredPeerIp(value) {
  const candidate = String(value ?? '').trim();
  return candidate.toLowerCase() === 'auto' ? '' : candidate;
}

function isPrivateIpv4(value) {
  const parts = String(value).split('.').map(Number);
  if (parts.length !== 4 || parts.some((part) => !Number.isInteger(part) || part < 0 || part > 255)) return false;
  return parts[0] === 10
    || (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31)
    || (parts[0] === 192 && parts[1] === 168)
    || (parts[0] === 100 && parts[1] >= 64 && parts[1] <= 127);
}

export function selectLocalIp(interfaces, preferredInterface = '') {
  const entries = Object.entries(interfaces ?? {});
  const candidates = entries.flatMap(([name, addresses]) => (addresses ?? [])
    .filter((address) => address.family === 'IPv4' && !address.internal)
    .map((address) => ({ name, address: address.address })));

  const preferred = candidates.find((candidate) => candidate.name === preferredInterface);

  return preferred?.address
    ?? candidates.find((candidate) => isPrivateIpv4(candidate.address))?.address
    ?? candidates[0]?.address
    ?? null;
}

function runtimeMetadata() {
  const configuredLocalIp = String(process.env.PBX_LOCAL_IP ?? '').trim();
  const localIp = configuredLocalIp && configuredLocalIp.toLowerCase() !== 'auto'
    ? configuredLocalIp
    : selectLocalIp(networkInterfaces(), String(process.env.PBX_INTERFACE ?? '').trim());
  const connectionMode = String(process.env.IAX_CONNECTION_MODE ?? 'internal').trim().toLowerCase();
  const registrationSetting = String(process.env.IAX_REGISTRATION_REQUIRED ?? '').trim().toLowerCase();
  const registrationRequired = registrationSetting === 'true'
    ? true
    : registrationSetting === 'false'
      ? false
      : ['dhcp', 'internal', 'vpn'].includes(connectionMode)
        ? false
        : null;
  return { localIp, connectionMode, registrationRequired };
}

export function parseIaxPeerOutput(output, options = {}) {
  const trunkName = configuredValue(options.trunkName, DEFAULT_TRUNK_NAME);
  const fallbackIp = configuredPeerIp(options.peerIp ?? DEFAULT_PEER_IP);
  const text = String(output ?? '');
  const statusText = text.match(/^\s*Status\s*:\s*(.+)$/im)?.[1]?.trim() ?? '';
  const address = (text.match(/^\s*Addr->IP\s*:\s*([0-9a-f:.]+)/im)?.[1] ?? fallbackIp) || null;
  const latency = statusText.match(/\((\d+)\s*ms\)/i);

  if (/unable to find peer|peer .* not found|no such peer/i.test(text)) {
    return {
      trunkName,
      peerIp: fallbackIp,
      status: 'UNKNOWN',
      latencyMs: null,
      configured: false,
      reachable: false,
      source: 'asterisk',
      detail: `Asterisk no encuentra el peer ${trunkName}.`,
      recommendation: 'Comprueba el nombre de la troncal y aplica la configuracion en Issabel.',
    };
  }

  if (/\bOK\b/i.test(statusText)) {
    return {
      trunkName,
      peerIp: address,
      status: 'UP',
      latencyMs: latency ? Number(latency[1]) : null,
      configured: true,
      reachable: true,
      source: 'asterisk',
      detail: 'El peer responde correctamente a las comprobaciones IAX2.',
      recommendation: 'Enlace disponible para llamadas entre las dos sedes.',
    };
  }

  if (/UNREACHABLE|LAGGED|TIMEOUT|UNMONITORED/i.test(statusText)) {
    return {
      trunkName,
      peerIp: address,
      status: 'DOWN',
      latencyMs: null,
      configured: true,
      reachable: false,
      source: 'asterisk',
      detail: `Asterisk informa: ${singleLine(statusText) || 'peer sin respuesta'}.`,
      recommendation: 'Revisa la PBX remota, UDP 4569, el firewall y que qualify=yes este aplicado.',
    };
  }

  return {
    trunkName,
    peerIp: address,
    status: 'UNKNOWN',
    latencyMs: null,
    configured: text.length > 0 ? true : null,
    reachable: false,
    source: 'asterisk',
    detail: statusText ? `Estado no reconocido: ${singleLine(statusText)}.` : 'Asterisk no devolvio el estado del peer.',
    recommendation: 'Ejecuta iax2 show peer BODEGA-IAX para verificar el nombre y el estado.',
  };
}

export function parseIaxPeersOutput(output, options = {}) {
  const trunkName = configuredValue(options.trunkName, DEFAULT_TRUNK_NAME);
  const fallbackIp = configuredPeerIp(options.peerIp ?? DEFAULT_PEER_IP);
  const peers = parseAllIaxPeersOutput(output, { trunkName, peerIp: fallbackIp });

  const related = peers.filter((peer) => peer.name === trunkName || (fallbackIp && peer.address === fallbackIp));
  const selected = related.find((peer) => peer.name === trunkName && peer.state === 'UP')
    ?? related.find((peer) => peer.name === trunkName)
    ?? related.find((peer) => fallbackIp && peer.address === fallbackIp && peer.state === 'UP')
    ?? related.find((peer) => fallbackIp && peer.address === fallbackIp);

  if (!selected) {
    return {
      trunkName,
      peerIp: fallbackIp,
      status: 'UNKNOWN',
      latencyMs: null,
      configured: false,
      reachable: false,
      source: 'asterisk',
      detail: fallbackIp
        ? `Asterisk no muestra el peer ${trunkName} ni otro peer hacia ${fallbackIp}.`
        : `Asterisk no muestra el peer ${trunkName}.`,
      recommendation: 'Comprueba el nombre del peer y aplica la configuracion de la troncal en Issabel.',
    };
  }

  if (selected.state === 'UP') {
    return {
      trunkName,
      peerIp: selected.address || fallbackIp,
      status: 'UP',
      latencyMs: selected.latencyMs,
      configured: true,
      reachable: true,
      source: 'asterisk',
      detail: `Enlace operativo mediante el peer ${selected.name}.`,
      recommendation: 'Enlace disponible para llamadas entre las dos sedes.',
    };
  }

  return {
    trunkName,
    peerIp: selected.address || fallbackIp,
    status: 'DOWN',
    latencyMs: null,
    configured: true,
    reachable: false,
    source: 'asterisk',
    detail: `El peer ${selected.name} esta configurado pero no responde.`,
    recommendation: 'Revisa la PBX remota, UDP 4569, el firewall y qualify=yes.',
  };
}

export function parseAllIaxPeersOutput(output, options = {}) {
  const trunkName = configuredValue(options.trunkName, DEFAULT_TRUNK_NAME);
  const fallbackIp = configuredPeerIp(options.peerIp ?? DEFAULT_PEER_IP);
  const peers = String(output ?? '')
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => line && !/^Name\/Username\b/i.test(line))
    .map((line) => {
      const columns = line.split(/\s+/);
      const peerToken = columns[0] ?? '';
      const name = peerToken.split('/')[0];
      const address = columns.find((value) => /^\d{1,3}(?:\.\d{1,3}){3}$/.test(value)) ?? '';
      const latency = line.match(/\bOK\s*\((\d+)\s*ms\)/i);
      const state = latency
        ? 'UP'
        : /\bUNREACHABLE\b|\bLAGGED\b|\bTIMEOUT\b/i.test(line)
          ? 'DOWN'
          : 'UNKNOWN';
      return { name, address, state, latencyMs: latency ? Number(latency[1]) : null };
    })
    .filter((peer) => peer.name && peer.address);
  const counts = peers.reduce((map, peer) => map.set(peer.address, (map.get(peer.address) ?? 0) + 1), new Map());
  return peers.map((peer) => ({
    ...peer,
    expectedName: peer.name === trunkName,
    expectedAddress: Boolean(fallbackIp) && peer.address === fallbackIp,
    duplicateAddress: (counts.get(peer.address) ?? 0) > 1,
    legacyName: /^IAX2-trunk/i.test(peer.name),
  }));
}

export async function getAllIaxPeers() {
  const trunkName = configuredValue(process.env.IAX_TRUNK_NAME, DEFAULT_TRUNK_NAME);
  const peerIp = configuredPeerIp(process.env.IAX_PEER_IP ?? DEFAULT_PEER_IP);
  const peersFile = String(process.env.ASTERISK_PEERS_FILE ?? DEFAULT_PEERS_FILE).trim();
  try {
    const [contents, info] = await Promise.all([readFile(peersFile, 'utf8'), stat(peersFile)]);
    return {
      status: 'ok',
      updatedAt: info.mtime.toISOString(),
      ageSeconds: Math.max(0, Math.round((Date.now() - info.mtimeMs) / 1000)),
      expected: { trunkName, peerIp },
      items: parseAllIaxPeersOutput(contents, { trunkName, peerIp }),
    };
  } catch (error) {
    return {
      status: 'unavailable',
      updatedAt: null,
      ageSeconds: null,
      expected: { trunkName, peerIp },
      items: [],
      detail: error.code === 'ENOENT' ? 'No existe el snapshot de peers IAX2.' : 'No fue posible leer los peers IAX2.',
    };
  }
}

function cliError(error, options = {}) {
  const trunkName = configuredValue(options.trunkName, DEFAULT_TRUNK_NAME);
  const peerIp = configuredPeerIp(options.peerIp ?? DEFAULT_PEER_IP);
  const diagnostic = singleLine(`${error?.stderr ?? ''} ${error?.stdout ?? ''} ${error?.message ?? ''}`);
  const permissionDenied = /permission denied|eacces|unable to connect to remote asterisk/i.test(diagnostic);

  return {
    trunkName,
    peerIp,
    status: 'UNKNOWN',
    latencyMs: null,
    configured: null,
    reachable: false,
    source: 'asterisk-unavailable',
    detail: permissionDenied
      ? 'La API no tiene permiso para consultar el socket de Asterisk.'
      : 'La API no pudo ejecutar la comprobacion de Asterisk.',
    recommendation: permissionDenied
      ? 'Agrega el servicio voip-api al grupo asterisk y reinicialo.'
      : 'Confirma que Asterisk este activo y que ASTERISK_CLI apunte al ejecutable correcto.',
  };
}

export async function getLiveIaxTrunkStatus({ force = false } = {}) {
  if (!force && cachedResult && Date.now() - cachedAt < CACHE_MS) return cachedResult;

  const trunkName = configuredValue(process.env.IAX_TRUNK_NAME, DEFAULT_TRUNK_NAME);
  const peerIp = configuredPeerIp(process.env.IAX_PEER_IP ?? DEFAULT_PEER_IP);
  const asteriskCli = String(process.env.ASTERISK_CLI ?? '/usr/sbin/asterisk').trim();
  const peersFile = String(process.env.ASTERISK_PEERS_FILE ?? DEFAULT_PEERS_FILE).trim();

  try {
    const [contents, fileStats] = await Promise.all([readFile(peersFile, 'utf8'), stat(peersFile)]);
    const ageSeconds = Math.max(0, Math.round((Date.now() - fileStats.mtimeMs) / 1000));
    const maxAge = Number(process.env.ASTERISK_PEERS_MAX_AGE_SECONDS ?? DEFAULT_PEERS_MAX_AGE_SECONDS);
    if (ageSeconds <= maxAge) {
      cachedResult = {
        ...parseIaxPeersOutput(contents, { trunkName, peerIp }),
        checkedAt: fileStats.mtime.toISOString(),
        ageSeconds,
        stale: false,
        monitor: 'snapshot',
        ...runtimeMetadata(),
        protocol: 'IAX2',
        port: 4569,
      };
      cachedAt = Date.now();
      return cachedResult;
    }
  } catch {
    // En instalaciones anteriores el archivo aun no existe; se intenta el CLI.
  }

  try {
    const { stdout, stderr } = await execFileAsync(
      asteriskCli,
      ['-rx', `iax2 show peer ${trunkName}`],
      {
        timeout: Number(process.env.ASTERISK_TIMEOUT_MS ?? 3_000),
        maxBuffer: 64 * 1024,
        windowsHide: true,
      },
    );
    cachedResult = {
      ...parseIaxPeerOutput(`${stdout}\n${stderr}`, { trunkName, peerIp }),
      checkedAt: new Date().toISOString(),
      ...runtimeMetadata(),
      protocol: 'IAX2',
      port: 4569,
    };
  } catch (error) {
    cachedResult = {
      ...cliError(error, { trunkName, peerIp }),
      checkedAt: new Date().toISOString(),
      ...runtimeMetadata(),
      protocol: 'IAX2',
      port: 4569,
    };
  }

  cachedAt = Date.now();
  return cachedResult;
}
