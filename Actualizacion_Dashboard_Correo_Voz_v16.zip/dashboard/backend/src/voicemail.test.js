import assert from 'node:assert/strict';
import { mkdtemp, mkdir, rm, symlink, writeFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';
import { getVoicemailMessages, parseVoicemailMetadata, resolveVoicemailAudio } from './voicemail.js';

test('interpreta los metadatos de Asterisk sin exponer rutas', () => {
  const values = parseVoicemailMetadata('callerid="Cliente" <99887766>\nduration=18\nflag=Urgent\n');
  assert.equal(values.callerid, '"Cliente" <99887766>');
  assert.equal(values.duration, '18');
  assert.equal(values.flag, 'Urgent');
});

test('lista mensajes nuevos y permite resolver audio WAV', async (t) => {
  const root = await mkdtemp(path.join(os.tmpdir(), 'voicemail-test-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const inbox = path.join(root, 'default', '2901', 'INBOX');
  await mkdir(inbox, { recursive: true });
  await writeFile(path.join(inbox, 'msg0001.txt'), 'callerid="Cliente Norte" <99887766>\norigtime=1786258800\nduration=18\n');
  await writeFile(path.join(inbox, 'msg0001.wav'), Buffer.from('RIFF-test'));
  const env = { VOICEMAIL_ROOT: root, VOICEMAIL_CONTEXTS: 'default', VOICEMAIL_MAILBOXES: '2901:Ventas' };
  const result = await getVoicemailMessages(env);
  assert.equal(result.status, 'ok');
  assert.equal(result.totals.total, 1);
  assert.equal(result.totals.new, 1);
  assert.equal(result.totals.playable, 1);
  assert.equal(result.items[0].callerId, 'Cliente Norte');
  assert.equal(result.items[0].callerNumber, '99887766');
  assert.match(result.items[0].audioUrl, /^\/api\/voicemail\/audio\//);
  const audio = await resolveVoicemailAudio({ context: 'default', mailbox: '2901', folder: 'INBOX', message: 'msg0001' }, env);
  assert.equal(audio.mime, 'audio/wav');
  assert.equal(audio.path, path.join(inbox, 'msg0001.wav'));
});

test('rechaza buzones y rutas que no fueron configurados', async (t) => {
  const root = await mkdtemp(path.join(os.tmpdir(), 'voicemail-test-'));
  t.after(() => rm(root, { recursive: true, force: true }));
  const env = { VOICEMAIL_ROOT: root, VOICEMAIL_CONTEXTS: 'default', VOICEMAIL_MAILBOXES: '2901:Ventas' };
  await assert.rejects(
    resolveVoicemailAudio({ context: '..', mailbox: '2901', folder: 'INBOX', message: 'msg0001' }, env),
    /no valido/,
  );
  await assert.rejects(
    resolveVoicemailAudio({ context: 'default', mailbox: '9999', folder: 'INBOX', message: 'msg0001' }, env),
    /no autorizado/,
  );
});
