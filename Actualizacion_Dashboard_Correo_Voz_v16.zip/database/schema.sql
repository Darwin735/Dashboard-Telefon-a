-- Tablas auxiliares del dashboard en la BD de CDR de Issabel.
-- Ejecutar como administrador MariaDB despues de realizar un respaldo.

USE asteriskcdrdb;

CREATE TABLE IF NOT EXISTS ivr_events (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    event_time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    uniqueid VARCHAR(64) NOT NULL,
    linkedid VARCHAR(64) NULL,
    caller VARCHAR(40) NULL,
    menu_id VARCHAR(16) NOT NULL,
    option_code VARCHAR(20) NOT NULL,
    option_label VARCHAR(80) NOT NULL,
    PRIMARY KEY (id),
    KEY idx_ivr_event_time (event_time),
    KEY idx_ivr_linkedid (linkedid),
    KEY idx_ivr_option (menu_id, option_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS trunk_status (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    trunk_name VARCHAR(80) NOT NULL,
    peer_ip VARCHAR(45) NOT NULL,
    status ENUM('UP', 'DOWN', 'UNKNOWN') NOT NULL DEFAULT 'UNKNOWN',
    latency_ms INT UNSIGNED NULL,
    detail VARCHAR(255) NULL,
    checked_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY idx_trunk_latest (trunk_name, checked_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Cree dos usuarios con claves aleatorias reales. No reutilice las claves de Issabel.
-- Los comandos se dejan comentados para evitar crear cuentas con una clave de ejemplo.
-- CREATE USER 'dashboard_reader'@'127.0.0.1' IDENTIFIED BY 'CLAVE_ALEATORIA_LECTURA';
-- GRANT SELECT ON asteriskcdrdb.cdr TO 'dashboard_reader'@'127.0.0.1';
-- GRANT SELECT ON asteriskcdrdb.ivr_events TO 'dashboard_reader'@'127.0.0.1';
-- GRANT SELECT ON asteriskcdrdb.trunk_status TO 'dashboard_reader'@'127.0.0.1';
-- CREATE USER 'dashboard_writer'@'127.0.0.1' IDENTIFIED BY 'CLAVE_ALEATORIA_ESCRITURA';
-- GRANT INSERT ON asteriskcdrdb.ivr_events TO 'dashboard_writer'@'127.0.0.1';
-- GRANT INSERT ON asteriskcdrdb.trunk_status TO 'dashboard_writer'@'127.0.0.1';
-- FLUSH PRIVILEGES;

-- Validaciones:
-- SHOW GRANTS FOR 'dashboard_reader'@'127.0.0.1';
-- SELECT COUNT(*) FROM cdr;
-- SELECT * FROM ivr_events ORDER BY event_time DESC LIMIT 5;
-- SELECT * FROM trunk_status ORDER BY checked_at DESC LIMIT 5;
