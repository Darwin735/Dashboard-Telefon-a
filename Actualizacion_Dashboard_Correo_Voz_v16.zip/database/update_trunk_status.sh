#!/usr/bin/env bash
set -euo pipefail

# Ejecutar cada minuto mediante cron en la PBX principal.
# El archivo /etc/asterisk/dashboard-writer.cnf debe contener credenciales del
# usuario con INSERT exclusivo sobre trunk_status y permisos 600.

MYSQL_DEFAULTS=${MYSQL_DEFAULTS:-/etc/asterisk/dashboard-writer.cnf}
TRUNK_NAME=${TRUNK_NAME:-BODEGA-IAX}
PEER_IP=${PEER_IP:-auto}

OUTPUT="$(asterisk -rx "iax2 show peer $TRUNK_NAME" 2>&1 || true)"
PEERS_OUTPUT="$(asterisk -rx 'iax2 show peers' 2>&1 || true)"
STATUS=DOWN
LATENCY=NULL
ACTIVE_PEER="$TRUNK_NAME"

DETECTED_IP="$(printf '%s' "$OUTPUT" | sed -nE 's/.*Addr->IP[[:space:]]*:[[:space:]]*([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+).*/\1/p' | head -n 1)"
if [[ "$DETECTED_IP" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
  PEER_IP="$DETECTED_IP"
fi

if printf '%s' "$OUTPUT" | grep -Eiq 'Status[[:space:]]*:[[:space:]]*OK'; then
  STATUS=UP
  VALUE="$(printf '%s' "$OUTPUT" | sed -nE 's/.*Status[[:space:]]*:[[:space:]]*OK[[:space:]]*\(([0-9]+) ms\).*/\1/p' | head -n 1)"
  if [[ "$VALUE" =~ ^[0-9]+$ ]]; then
    LATENCY="$VALUE"
  fi
fi

if [[ "$STATUS" != "UP" ]]; then
  MATCHING_LINE="$(printf '%s\n' "$PEERS_OUTPUT" | awk -v name="$TRUNK_NAME" -v ip="$PEER_IP" '
    {
      split($1, peer, "/")
      if (peer[1] == name && $0 ~ /OK \([0-9]+ ms\)/) { fallback = ""; print; exit }
      if (ip != "auto" && $2 == ip && $0 ~ /OK \([0-9]+ ms\)/) fallback = $0
    }
    END { if (fallback) print fallback }
  ')"
  if [[ -n "$MATCHING_LINE" ]]; then
    STATUS=UP
    ACTIVE_PEER="$(printf '%s' "$MATCHING_LINE" | awk '{print $1}' | cut -d/ -f1)"
    DETECTED_IP="$(printf '%s' "$MATCHING_LINE" | awk '{print $2}')"
    if [[ "$DETECTED_IP" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
      PEER_IP="$DETECTED_IP"
    fi
    VALUE="$(printf '%s' "$MATCHING_LINE" | sed -nE 's/.*OK[[:space:]]*\(([0-9]+) ms\).*/\1/p')"
    if [[ "$VALUE" =~ ^[0-9]+$ ]]; then
      LATENCY="$VALUE"
    fi
  fi
fi

if [[ "$STATUS" == "UP" ]]; then
  DETAIL="Enlace operativo por peer $ACTIVE_PEER hacia $PEER_IP."
else
  DETAIL="$(printf '%s' "$OUTPUT" | tr '\n' ' ' | cut -c1-180)"
fi
DETAIL="$(printf '%s' "$DETAIL" | sed "s/'/''/g" | cut -c1-220)"
mysql --defaults-extra-file="$MYSQL_DEFAULTS" asteriskcdrdb <<SQL
INSERT INTO trunk_status (trunk_name, peer_ip, status, latency_ms, detail)
VALUES ('$TRUNK_NAME', '$PEER_IP', '$STATUS', $LATENCY, '$DETAIL');
SQL
